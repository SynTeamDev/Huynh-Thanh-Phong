import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

class CustomNavbarWidget extends ConsumerStatefulWidget {
  const CustomNavbarWidget({super.key});
  @override
  ConsumerState<CustomNavbarWidget> createState() => _CustomNavbarWidgetState();
}

class _CustomNavbarWidgetState extends ConsumerState<CustomNavbarWidget> {
  final List<_NavItem> items = const [
    _NavItem(
      route: '/cstt',
      label: 'Cuộc sống số',
      icon: 'assets/icons/navcstt1.png',
      iconActive: 'assets/icons/navcstt1.png',
    ),
    _NavItem(
      route: '/home',
      label: 'Trang chủ',
      icon: 'assets/icons/navhome1.png',
      iconActive: 'assets/icons/navhome1.png',
    ),
    _NavItem(
      route: '/map',
      label: 'Bản đồ thông minh',
      icon: 'assets/icons/navmap1.png',
      iconActive: 'assets/icons/navmap1.png',
    ),
  ];

  static const double _barHeight = 70; // cao hơn chút
  static const double _bubbleSize = 60; // bubble to hơn
  static const double _iconSize = 36; // icon to hơn

  @override
  Widget build(BuildContext context) {
    final location = GoRouterState.of(context).uri.toString();
    final currentIndex = items.indexWhere((e) => location.startsWith(e.route));
    final sel = currentIndex < 0 ? 1 : currentIndex;

    final bottomInset = MediaQuery.of(context).padding.bottom;
    final totalHeight = _barHeight + _bubbleSize / 2;

    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.fromLTRB(14, 2, 14, 8 + bottomInset / 2),
        child: SizedBox(
          height: totalHeight,
          child: LayoutBuilder(
            builder: (context, c) {
              final tabW = c.maxWidth / items.length;

              return Stack(
                clipBehavior: Clip.none,

                children: [
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: PhysicalModel(
                      color: Colors.white, // nền trắng luôn
                      elevation: 12,
                      shadowColor: Colors.black.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(18),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: Container(
                          height: _barHeight,
                          color: Colors.white, // trắng tinh
                          child: Row(
                            children: List.generate(items.length, (i) {
                              final selected = i == sel;
                              return Expanded(
                                child: InkWell(
                                  splashColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () {
                                    if (!selected) context.go(items[i].route);
                                    setState(() {});
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                      top: 12,
                                      bottom: 10,
                                    ),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        if (!selected)
                                          Image.asset(
                                            items[i].icon,
                                            height: 28,
                                            width: 28,
                                          )
                                        else
                                          SizedBox(height: 28, width: 28),
                                        Text(
                                          items[i].label,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: selected
                                                ? FontWeight.w700
                                                : FontWeight.w700,
                                            color: selected
                                                ? Color(0xFF3B5BFF)
                                                : Color(0xFF111827),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            }),
                          ),
                        ),
                      ),
                    ),
                  ),

                  // BUBBLE icon khi chọn tab
                  AnimatedPositioned(
                    duration: const Duration(milliseconds: 220),
                    curve: Curves.easeOutCubic,
                    left: (tabW * sel) + (tabW - _bubbleSize) / 2,
                    top: 0,
                    child: _Bubble(
                      size: _bubbleSize,
                      child: Image.asset(
                        items[sel].iconActive,
                        height: _iconSize,
                        width: _iconSize,
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.size, required this.child});
  final double size;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          colors: [Color(0xFF5A78FF), Color(0xFF3B5BFF)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF3B5BFF).withOpacity(0.32),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Center(child: child),
    );
  }
}

class _NavItem {
  final String route;
  final String label;
  final String icon;
  final String iconActive;
  const _NavItem({
    required this.route,
    required this.label,
    required this.icon,
    required this.iconActive,
  });
}
