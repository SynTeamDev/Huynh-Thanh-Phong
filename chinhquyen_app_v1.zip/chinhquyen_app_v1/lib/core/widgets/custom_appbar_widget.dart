import 'package:flutter/material.dart';

class CustomAppBarWidget extends StatelessWidget
    implements PreferredSizeWidget {
  final String? title;
  final List<Widget>? actions;
  final String? subtitleText; // ✅ Thêm dòng phụ bên dưới

  const CustomAppBarWidget({
    super.key,
    this.title,
    this.actions,
    this.subtitleText,
  });

  @override
  Widget build(BuildContext context) {
    return PreferredSize(
      preferredSize: preferredSize,
      child: AppBar(
        backgroundColor: Colors.blue.shade50,
        centerTitle: false,
        iconTheme: const IconThemeData(color: Colors.blue),
        actions: actions,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (title != null)
              Text(
                title!,
                style: const TextStyle(color: Colors.blue, fontSize: 18),
              ),
            if (subtitleText != null)
              Padding(
                padding: const EdgeInsets.only(top: 2.0),
                child: Text(
                  subtitleText!,
                  style: const TextStyle(color: Colors.grey, fontSize: 14),
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(60); // cao hơn để chứa subtitle
}
