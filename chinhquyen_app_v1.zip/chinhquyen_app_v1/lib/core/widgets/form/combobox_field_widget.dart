import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../network/api_provider.dart';
import '../loading_widget.dart';

class ComboboxFieldWidget extends StatelessWidget {
  final String label;
  final String tableName;
  final String? selectedValue;
  final ValueChanged<String?> onChanged;
  final bool isCode;
  final bool hasError;
  final String hint;
  final bool dense; // 👈 mới thêm
  final bool showRequiredAsterisk; // ✅ Thêm biến bật/tắt dấu *

  const ComboboxFieldWidget({
    super.key,
    required this.label,
    required this.tableName,
    required this.selectedValue,
    required this.onChanged,
    this.isCode = true,
    this.hasError = false, // ✅ Thêm cờ
    this.hint = 'Chọn',
    this.dense = false,
    this.showRequiredAsterisk = false, // ✅ Mặc định không hiện *
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (label.isNotEmpty) ...[
          RichText(
            text: TextSpan(
              text: label,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: Colors.black,
              ),
              children: [
                if (showRequiredAsterisk) // ✅ Chỉ hiển thị nếu true
                  const TextSpan(
                    text: ' *',
                    style: TextStyle(color: Colors.red),
                  ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 2),
        Consumer(
          builder: (context, ref, _) {
            final comboboxAsync = ref.watch(comboboxFutureProvider(tableName));
            return comboboxAsync.when(
              loading: () => Container(
                height: dense ? 38 : 48,
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const LoadingWidget(),
              ),
              error: (err, _) => Container(
                height: dense ? 38 : 48,
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  border: Border.all(color: Colors.red),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(child: Text('Lỗi: $err')),
              ),
              data: (items) {
                final itemList = items.map<DropdownMenuItem<String>>((item) {
                  return DropdownMenuItem<String>(
                    value: item['rcode'],
                    child: isCode
                        ? Text(
                            '${item['rcode']} - ${item['rname']}',
                            style: TextStyle(fontSize: dense ? 12 : 13),
                            overflow: TextOverflow.ellipsis,
                          )
                        : Text(
                            item['rname'],
                            style: TextStyle(fontSize: dense ? 12 : 13),
                            overflow: TextOverflow.ellipsis,
                          ),
                  );
                }).toList();

                final isSelectedValid = items.any(
                  (item) => item['rcode'] == selectedValue,
                );
                final fixedSelectedValue = isSelectedValid
                    ? selectedValue
                    : null;

                return Container(
                  height: dense ? 38 : 48,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    //border: Border.all(color: Colors.grey.shade300),
                    border: Border.all(
                      color: hasError
                          ? Colors.red
                          : Colors.grey.shade300, // ✅ Nếu lỗi thì viền đỏ
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: fixedSelectedValue,
                      isExpanded: true,
                      hint: Text(
                        hint,
                        style: TextStyle(fontSize: dense ? 12 : 13),
                      ),
                      icon: const Icon(Icons.arrow_drop_down),
                      dropdownColor: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      onChanged: onChanged,
                      items: itemList,
                      menuMaxHeight: 300,
                    ),
                  ),
                );
              },
            );
          },
        ),
      ],
    );
  }
}

final comboboxFutureProvider =
    FutureProvider.family<List<Map<String, dynamic>>, String>((
      ref,
      table,
    ) async {
      return ref.read(apiServiceProvider).fetchCbb(table: table);
    });

// kiểu int
Future<int?> getDefaultComboboxCode(String table, WidgetRef ref) async {
  final List<Map<String, dynamic>> items = await ref
      .read(apiServiceProvider)
      .fetchCbb(table: table);

  if (items.isEmpty) return null;

  final dynamic r = items.first['rcode'];

  if (r == null) return null;
  if (r is int) return r; // ✅ đã là int
  if (r is num) return r.toInt(); // ✅ là num
  if (r is String) return int.tryParse(r.trim()); // ✅ là String
  return int.tryParse(r.toString()); // ✅ fallback
}

// kiểu String
Future<String?> getDefaultComboboxCodeString(
  String table,
  WidgetRef ref,
) async {
  final items = await ref.read(apiServiceProvider).fetchCbb(table: table);
  if (items.isNotEmpty) {
    return items.first['rcode'];
  }
  return null;
}
