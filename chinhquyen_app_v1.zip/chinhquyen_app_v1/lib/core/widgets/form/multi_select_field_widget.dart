import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../loading_widget.dart';
import 'combobox_field_widget.dart';

class MultiSelectFieldWidget extends ConsumerWidget {
  final String label;
  final String tableName;
  final String? selectedValues; // ex: "SYN0003,SYN0005"
  final ValueChanged<String?> onChanged;

  const MultiSelectFieldWidget({
    super.key,
    required this.label,
    required this.tableName,
    required this.selectedValues,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final codes = (selectedValues ?? '')
        .split(',')
        .where((e) => e.trim().isNotEmpty)
        .toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 4),
        GestureDetector(
          onTap: () async {
            final result = await showDialog<List<String>>(
              context: context,
              builder: (_) => MultiSelectPopup(
                tableName: tableName,
                initialSelected: codes,
              ),
            );

            if (result != null) {
              onChanged(result.join(','));
            }
          },
          child: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.grey[100],
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Wrap(
              spacing: 6,
              runSpacing: 6,
              children: codes.isEmpty
                  ? [
                      Text(
                        'Chọn',
                        style: TextStyle(color: Colors.grey.shade600),
                      ),
                    ]
                  : codes.map((code) {
                      return Chip(
                        label: Text(code, style: const TextStyle(fontSize: 12)),
                        deleteIcon: const Icon(Icons.close, size: 16),
                        onDeleted: () {
                          final newList = [...codes]..remove(code);
                          onChanged(newList.join(','));
                        },
                        backgroundColor: Colors.blue.shade50,
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      );
                    }).toList(),
            ),
          ),
        ),
      ],
    );
  }
}

class MultiSelectPopup extends ConsumerStatefulWidget {
  final String tableName;
  final List<String> initialSelected;

  const MultiSelectPopup({
    super.key,
    required this.tableName,
    required this.initialSelected,
  });

  @override
  ConsumerState<MultiSelectPopup> createState() => _MultiSelectPopupState();
}

class _MultiSelectPopupState extends ConsumerState<MultiSelectPopup> {
  List<String> selected = [];
  String keyword = '';

  @override
  void initState() {
    super.initState();
    selected = [...widget.initialSelected];
  }

  @override
  Widget build(BuildContext context) {
    final asyncItems = ref.watch(comboboxFutureProvider(widget.tableName));

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      backgroundColor: Colors.grey.shade50,
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      child: Container(
        padding: const EdgeInsets.all(12),
        constraints: const BoxConstraints(maxHeight: 500, maxWidth: 320),
        child: Column(
          children: [
            TextField(
              style: const TextStyle(fontSize: 13),
              decoration: InputDecoration(
                hintText: 'Tìm kiếm...',
                prefixIcon: const Icon(Icons.search, size: 18),
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 10,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Colors.grey),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Colors.blue, width: 2),
                ),
              ),
              onChanged: (val) => setState(() => keyword = val.toLowerCase()),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: asyncItems.when(
                loading: () => const LoadingWidget(),
                error: (err, _) => Center(child: Text('Lỗi: $err')),
                data: (items) {
                  final filtered = keyword.isEmpty
                      ? items
                      : items
                            .where(
                              (e) =>
                                  e['rcode'].toLowerCase().contains(keyword) ||
                                  (e['rname']?.toLowerCase().contains(
                                        keyword,
                                      ) ??
                                      false),
                            )
                            .toList();

                  return Scrollbar(
                    radius: const Radius.circular(6),
                    thumbVisibility: true,
                    child: ListView.separated(
                      itemCount: filtered.length,
                      separatorBuilder: (_, __) =>
                          Divider(height: 1, color: Colors.grey.shade300),
                      itemBuilder: (_, i) {
                        final item = filtered[i];
                        final code = item['rcode'];
                        final name = item['rname'];
                        final isChecked = selected.contains(code);

                        return ListTile(
                          dense: true,
                          visualDensity: VisualDensity.compact,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 6,
                          ),
                          title: Text(
                            '$code - $name',
                            style: const TextStyle(fontSize: 13),
                          ),
                          trailing: Checkbox(
                            value: isChecked,
                            activeColor: Colors.blue,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(4),
                            ),
                            onChanged: (_) {
                              setState(() {
                                if (isChecked) {
                                  selected.remove(code);
                                } else {
                                  selected.add(code);
                                }
                              });
                            },
                          ),
                          onTap: () {
                            setState(() {
                              if (isChecked) {
                                selected.remove(code);
                              } else {
                                selected.add(code);
                              }
                            });
                          },
                        );
                      },
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
                onPressed: () => Navigator.pop(context, selected),
                icon: const Icon(Icons.check),
                label: const Text('Xong'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
