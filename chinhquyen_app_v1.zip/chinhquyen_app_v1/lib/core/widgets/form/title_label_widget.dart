import 'package:flutter/material.dart';

class TitleLabelWidget extends StatelessWidget {
  const TitleLabelWidget({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: Theme.of(context).copyWith(
        textSelectionTheme: const TextSelectionThemeData(
          cursorColor: Colors.grey, // 🎯 màu con trỏ
          selectionColor: Colors.grey, // 🎯 màu bôi đen chữ
          selectionHandleColor: Colors.grey, // 🎯 màu cái "chấm" bạn hỏi
        ),
      ),
      child: SelectableText(
        title,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 15,
          color: Colors.blue,
        ),
      ),
    );
  }
}
