import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class PhonePickerWidget extends StatefulWidget {
  final List<String> phoneNumbers;
  final int initialIndex;

  const PhonePickerWidget({
    super.key,
    required this.phoneNumbers,
    this.initialIndex = 0,
  });

  @override
  State<PhonePickerWidget> createState() => _PhonePickerWidgetState();
}

class _PhonePickerWidgetState extends State<PhonePickerWidget> {
  late int selectedIndex;

  @override
  void initState() {
    super.initState();
    selectedIndex = widget.initialIndex;
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 280,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context, null),
                  child: const Text(
                    'Huỷ',
                    style: TextStyle(color: Colors.blue),
                  ),
                ),
                const Text(
                  'Chọn số điện thoại',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                TextButton(
                  onPressed: () {
                    final selectedPhone = widget.phoneNumbers[selectedIndex];
                    Navigator.pop(context, selectedPhone);
                  },
                  child: const Text(
                    'Nhận',
                    style: TextStyle(color: Colors.blue),
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: CupertinoPicker(
              itemExtent: 36,
              scrollController: FixedExtentScrollController(
                initialItem: selectedIndex,
              ),
              onSelectedItemChanged: (index) {
                selectedIndex = index;
              },
              children: widget.phoneNumbers
                  .map((phone) => Center(child: Text(phone)))
                  .toList(),
            ),
          ),
        ],
      ),
    );
  }
}

Future<String?> showPhonePicker({
  required BuildContext context,
  required List<String> phones,
  int initialIndex = 0,
}) {
  return showModalBottomSheet<String>(
    context: context,
    isDismissible: true,
    useRootNavigator: true, //! 👈 THÊM DÒNG NÀY, SỬA ĐÈ LÊN MENU NAVBAR
    enableDrag: true,
    backgroundColor: Colors.white,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (context) =>
        PhonePickerWidget(phoneNumbers: phones, initialIndex: initialIndex),
  );
}
