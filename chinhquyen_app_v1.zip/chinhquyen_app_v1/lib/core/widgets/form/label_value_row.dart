import 'package:flutter/material.dart';

class LabelValueRow extends StatelessWidget {
  const LabelValueRow({
    super.key,
    required this.label,
    required this.value,
    this.color,
    this.icon,
    this.iconColor,
    this.maxHeight = 22,
    this.valueWidget,
    this.labelWidget,
  });

  final String label;
  final String value;
  final Color? color;
  final IconData? icon;
  final Color? iconColor;
  final double maxHeight;
  final Widget? valueWidget;
  final Widget? labelWidget;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 2,
          child:
              labelWidget ??
              Text(
                label,
                overflow: TextOverflow.ellipsis,
                maxLines: 2,
                style: const TextStyle(
                  fontSize: 13,
                  color: Colors.grey,
                  fontWeight: FontWeight.w600,
                ),
              ),
        ),
        const SizedBox(width: 12),
        Expanded(
          flex: 3,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.center, // 👈 thay vì start
            children: [
              Expanded(
                child: Theme(
                  data: Theme.of(context).copyWith(
                    textSelectionTheme: const TextSelectionThemeData(
                      cursorColor: Colors.blue, // 🎯 màu con trỏ
                      selectionColor: Colors.lightBlue, // 🎯 màu bôi đen chữ
                      selectionHandleColor:
                          Colors.blue, // 🎯 màu cái "chấm" bạn hỏi
                    ),
                  ),
                  child: Container(
                    constraints: BoxConstraints(
                      maxHeight: maxHeight,
                    ), // 👈 giới hạn chiều cao
                    alignment: Alignment.centerRight,
                    child:
                        valueWidget ??
                        // SelectableText(
                        //   value,
                        //   style: TextStyle(
                        //     fontSize: 13,
                        //     color: color ?? Colors.black87,
                        //   ),
                        //   maxLines: 2,
                        //   textAlign: TextAlign.right,
                        // ),
                        Text(
                          value,
                          style: TextStyle(
                            fontSize: 13,
                            color: color ?? Colors.black87,
                          ),
                          maxLines: 2,
                          textAlign: TextAlign.right,
                        ),
                  ),
                ),
              ),
              if (icon != null)
                Padding(
                  padding: const EdgeInsets.only(left: 4),
                  child: Icon(
                    icon,
                    color: iconColor ?? Colors.black54,
                    size: 16,
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}
