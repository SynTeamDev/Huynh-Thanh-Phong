import 'package:flutter/material.dart';

import 'phone_picker_widget.dart';

class PhonePickerRow extends StatefulWidget {
  final String label;
  final List<String> phones;
  final int initialIndex;
  final void Function(String phone)? onCall; // 👉 Gọi số bên ngoài truyền vào
  final Widget? labelWidget;

  const PhonePickerRow({
    super.key,
    required this.label,
    required this.phones,
    this.initialIndex = 0,
    this.onCall,
    this.labelWidget,
  });

  @override
  State<PhonePickerRow> createState() => _PhonePickerRowState();
}

class _PhonePickerRowState extends State<PhonePickerRow> {
  late String selectedPhone;

  @override
  void initState() {
    super.initState();
    selectedPhone = widget.phones[widget.initialIndex];
  }

  Future<void> _choosePhone() async {
    final result = await showPhonePicker(
      context: context,
      phones: widget.phones,
      initialIndex: widget.initialIndex,
    );

    if (result != null) {
      setState(() {
        selectedPhone = result;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // Label
        Expanded(
          flex: 2,
          child:
              widget.labelWidget ??
              Text(
                widget.label,
                style: const TextStyle(
                  fontSize: 13,
                  color: Colors.black87,
                  fontWeight: FontWeight.w600,
                ),
              ),
        ),
        const SizedBox(width: 12),

        // Icon và số điện thoại
        Expanded(
          flex: 3,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              GestureDetector(
                onTap: () {
                  if (widget.onCall != null) {
                    widget.onCall!(selectedPhone);
                  }
                },
                child: Container(
                  width: 35,
                  height: 35,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.blue[50],
                  ),
                  child: Icon(Icons.phone, size: 20, color: Colors.blue[700]),
                ),
              ),
              const SizedBox(width: 10),

              GestureDetector(
                onTap: _choosePhone, // 👉 mở picker khi nhấn số
                child: Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        selectedPhone,
                        style: const TextStyle(
                          fontSize: 13,
                          color: Colors.black87,
                          decoration: TextDecoration.underline, // 👉 gạch chân
                        ),
                      ),
                      const Icon(
                        Icons.arrow_drop_down, // 👉 biểu tượng combobox
                        size: 17,
                        color: Colors.black54,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
