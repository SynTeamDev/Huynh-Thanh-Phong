import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class VIDatePickerWidget extends StatefulWidget {
  final DateTime initialDate;
  final String text;
  final int syear;
  final int year2000;

  const VIDatePickerWidget({
    Key? key,
    required this.initialDate,
    required this.text,
    required this.syear,
    required this.year2000,
  }) : super(key: key);

  @override
  State<VIDatePickerWidget> createState() => _VIDatePickerWidgetState();
}

class _VIDatePickerWidgetState extends State<VIDatePickerWidget> {
  late int selectedDay;
  late int selectedMonth;
  late int selectedYear;

  @override
  void initState() {
    super.initState();
    selectedDay = widget.initialDate.day;
    selectedMonth = widget.initialDate.month;
    selectedYear = widget.initialDate.year;
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 320,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context, null),
                  child: const Text(
                    'Huỷ',
                    style: TextStyle(color: Colors.blue),
                  ),
                ),
                Text(
                  widget.text,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.pop(
                      context,
                      DateTime(selectedYear, selectedMonth, selectedDay),
                    );
                  },
                  child: const Text(
                    'Nhận',
                    style: TextStyle(color: Colors.blue),
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: Row(
              children: [
                // Ngày
                Expanded(
                  child: CupertinoPicker(
                    itemExtent: 32,
                    scrollController: FixedExtentScrollController(
                      initialItem: selectedDay - 1,
                    ),
                    onSelectedItemChanged: (index) {
                      selectedDay = index + 1;
                    },
                    children: List.generate(
                      31,
                      (index) => Center(child: Text('${index + 1}')),
                    ),
                  ),
                ),
                // Tháng
                Expanded(
                  child: CupertinoPicker(
                    itemExtent: 32,
                    scrollController: FixedExtentScrollController(
                      initialItem: selectedMonth - 1,
                    ),
                    onSelectedItemChanged: (index) {
                      selectedMonth = index + 1;
                    },
                    children: List.generate(
                      12,
                      (index) => Center(child: Text('${index + 1}')),
                    ),
                  ),
                ),
                // Năm
                Expanded(
                  child: CupertinoPicker(
                    itemExtent: 32,
                    scrollController: FixedExtentScrollController(
                      initialItem: selectedYear - widget.year2000,
                    ),
                    onSelectedItemChanged: (index) {
                      selectedYear = widget.year2000 + index;
                    },
                    children: List.generate(
                      widget.syear,
                      (index) =>
                          Center(child: Text('${widget.year2000 + index}')),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ---- Hàm để gọi dễ dàng
Future<DateTime?> showCustomVietnameseDatePicker({
  required BuildContext context,
  required DateTime initialDate,
  String text = 'Chọn ngày',
  int syear = 50,
  int year2000 = 2000,
}) async {
  return await showModalBottomSheet<DateTime>(
    context: context,
    backgroundColor: Colors.white,
    isDismissible: false,
    enableDrag: false,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder:
        (context) => VIDatePickerWidget(
          initialDate: initialDate,
          text: text,
          syear: syear,
          year2000: year2000,
        ),
  );
}
