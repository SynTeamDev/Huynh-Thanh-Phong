import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../network/api_provider.dart';
import '../loading_widget.dart';

/// ===============================
/// ✅ Cache Global
/// ===============================
final comboboxCacheProvider = Provider<ComboboxCache>((ref) => ComboboxCache());

class ComboboxCache {
  final Map<String, List<Map<String, dynamic>>> _searchCache = {};
  final Map<String, Map<String, dynamic>> _itemCache = {};
  final int maxCacheSize = 50;

  String _searchKey(String table, String keyword) => '$table|$keyword';
  String _itemKey(String table, String rcode) => '$table|$rcode';

  List<Map<String, dynamic>>? getSearch(String table, String keyword) =>
      _searchCache[_searchKey(table, keyword)];
  void setSearch(
    String table,
    String keyword,
    List<Map<String, dynamic>> data,
  ) {
    if (_searchCache.length >= maxCacheSize)
      _searchCache.remove(_searchCache.keys.first);
    _searchCache[_searchKey(table, keyword)] = data;
  }

  Map<String, dynamic>? getItem(String table, String rcode) =>
      _itemCache[_itemKey(table, rcode)];
  void setItem(String table, String rcode, Map<String, dynamic> data) {
    if (_itemCache.length >= maxCacheSize)
      _itemCache.remove(_itemCache.keys.first);
    _itemCache[_itemKey(table, rcode)] = data;
  }
}

/// ===============================
/// ✅ Provider cho Selected Text (1 item)
/// ===============================
final selectedItemProvider =
    FutureProvider.family<Map<String, dynamic>?, String>((ref, param) async {
      final table = param.split('|')[0];
      final rcode = param.split('|')[1];
      final cache = ref.read(comboboxCacheProvider);

      if (rcode.isEmpty) return null;
      final cached = cache.getItem(table, rcode);
      if (cached != null) return cached;

      final data = await ref
          .read(apiServiceProvider)
          .fetchCbb(table: table, keyword: rcode);
      final found = data.firstWhere(
        (e) => e['rcode'] == rcode,
        orElse: () => {},
      );
      if (found.isNotEmpty) cache.setItem(table, rcode, found);
      return found.isNotEmpty ? found : null;
    });

/// ===============================
/// ✅ Provider cho List Search (popup)
/// ===============================
final searchListProvider =
    FutureProvider.family<List<Map<String, dynamic>>, (String, String)>((
      ref,
      params,
    ) async {
      final (table, keyword) = params;
      final cache = ref.read(comboboxCacheProvider);

      final cached = cache.getSearch(table, keyword);
      if (cached != null) return cached;

      final data = await ref
          .read(apiServiceProvider)
          .fetchCbb(table: table, keyword: keyword);
      cache.setSearch(table, keyword, data);
      return data;
    });

/// ===============================
/// ✅ Widget: Field Display + OnTap popup
/// ===============================
class PopupSearchFieldWidget extends ConsumerWidget {
  final String label;
  final String tableName;
  final String? selectedValue;
  final bool isCode;
  final bool hasError;
  final ValueChanged<String?> onChanged;

  const PopupSearchFieldWidget({
    super.key,
    required this.label,
    required this.tableName,
    required this.selectedValue,
    required this.onChanged,
    this.isCode = true,
    this.hasError = false,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedAsync = ref.watch(
      selectedItemProvider('$tableName|${selectedValue ?? ''}'),
    );

    String displayText = 'Chọn';
    if (selectedAsync.hasValue && selectedAsync.value != null) {
      final item = selectedAsync.value!;
      displayText = isCode
          ? '${item['rcode']} - ${item['rname']}'
          : item['rname'];
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 2),
        GestureDetector(
          onTap: () async {
            final selected = await showDialog<Map<String, dynamic>>(
              context: context,
              builder: (_) => PopupSearchWidget(
                tableName: tableName,
                selectedValue: selectedValue,
                isCode: isCode,
              ),
            );
            if (selected != null) onChanged(selected['rcode']);
          },
          child: Container(
            height: 48,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: Colors.grey[100],
              border: Border.all(
                color: hasError ? Colors.red : Colors.grey.shade300,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: [
                Expanded(
                  child: selectedAsync.isLoading
                      ? const LoadingWidget()
                      : Text(
                          displayText,
                          style: TextStyle(
                            fontSize: 13,
                            color: (displayText == 'Chọn')
                                ? Colors.grey
                                : Colors.black,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                ),
                const Icon(Icons.arrow_drop_down),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

/// ===============================
/// ✅ Widget: Popup Search + Debounce
/// ===============================
class PopupSearchWidget extends ConsumerStatefulWidget {
  final String tableName;
  final String? selectedValue;
  final bool isCode;

  const PopupSearchWidget({
    super.key,
    required this.tableName,
    this.selectedValue,
    this.isCode = true,
  });

  @override
  ConsumerState<PopupSearchWidget> createState() => _PopupSearchWidgetState();
}

class _PopupSearchWidgetState extends ConsumerState<PopupSearchWidget> {
  String _searchKeyword = '';
  Timer? _debounce;

  void _onSearchChanged(String keyword) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 300), () {
      setState(() => _searchKeyword = keyword);
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final listAsync = ref.watch(
      searchListProvider((widget.tableName, _searchKeyword)),
    );

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      backgroundColor: Colors.grey.shade50,
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      child: Container(
        constraints: const BoxConstraints(maxHeight: 400, maxWidth: 300),
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Theme(
              data: Theme.of(context).copyWith(
                textSelectionTheme: const TextSelectionThemeData(
                  cursorColor: Colors.blue, // Màu con trỏ
                  selectionColor: Colors.lightBlue, // Màu bôi đen
                  selectionHandleColor: Colors.blue, // Màu dấu kéo
                ),
              ),
              child: TextField(
                style: const TextStyle(fontSize: 13),
                decoration: InputDecoration(
                  hintText: 'Tìm kiếm...',
                  prefixIcon: const Icon(Icons.search, size: 18),
                  isDense: true,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 8,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(
                      color: Colors.grey,
                    ), // ✅ Viền xám khi bình thường
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(
                      color: Colors.blue,
                      width: 2,
                    ), // ✅ Viền xanh đậm khi focus
                  ),
                ),
                onChanged: _onSearchChanged,
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: listAsync.when(
                loading: () => const LoadingWidget(),
                error: (err, _) => Center(
                  child: Text(
                    'Lỗi: $err',
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
                data: (items) => items.isEmpty
                    ? const Center(
                        child: Text(
                          'Không tìm thấy dữ liệu.',
                          style: TextStyle(fontSize: 12),
                        ),
                      )
                    : Scrollbar(
                        radius: const Radius.circular(6),
                        thumbVisibility: true,
                        child: ListView.separated(
                          itemCount: items.length,
                          separatorBuilder: (_, __) =>
                              Divider(height: 1, color: Colors.grey.shade300),
                          itemBuilder: (context, index) {
                            final item = items[index];
                            final isSelected =
                                item['rcode'] == widget.selectedValue;

                            return InkWell(
                              borderRadius: BorderRadius.circular(4),
                              onTap: () => Navigator.of(context).pop(item),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 8,
                                ),
                                decoration: BoxDecoration(
                                  color: isSelected
                                      ? Colors.blue.shade50
                                      : Colors.transparent,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Text(
                                  widget.isCode
                                      ? '${item['rcode']} - ${item['rname']}'
                                      : item['rname'],
                                  style: const TextStyle(
                                    fontSize: 13,
                                    color: Colors.black87,
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
