import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../utils/currency_helper.dart';
import '../../utils/upper_case_helper.dart';

class InputFieldWidget extends StatelessWidget {
  final String? label;
  final TextEditingController controller;
  final String hintText;
  final TextInputType keyboardType;
  final bool readOnly;
  final int? maxLength;
  final VoidCallback? onTap;
  final ValueChanged<String>? onChanged;
  final bool isCurrency; // ✅ Thêm cờ định dạng tiền
  final FocusNode? focusNode;
  final bool enableClear;
  // Tuỳ chỉnh thêm như area text
  final double? height;
  final int? maxLines;
  final int? minLines;
  final bool capitalizeFirstLetter;
  final bool showRequiredAsterisk; // ✅ Thêm biến bật/tắt dấu *

  const InputFieldWidget({
    super.key,
    this.label,
    required this.controller,
    this.hintText = 'Nhập',
    this.keyboardType = TextInputType.text,
    this.readOnly = false,
    this.maxLength,
    this.onTap,
    this.onChanged,
    this.isCurrency = false, // ✅ Mặc định là không định dạng
    this.focusNode,
    this.enableClear = true,
    this.height,
    this.maxLines,
    this.minLines,
    this.capitalizeFirstLetter = false,
    this.showRequiredAsterisk = false, // ✅ Mặc định không hiện *
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (label != null && label!.isNotEmpty) ...[
          RichText(
            text: TextSpan(
              text: label!,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: Colors.black,
              ),
              children: [
                if (showRequiredAsterisk) // ✅ Chỉ hiển thị nếu true
                  const TextSpan(
                    text: ' *',
                    style: TextStyle(color: Colors.red),
                  ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 2),
        Container(
          height: height ?? 48,
          decoration: BoxDecoration(
            color: Colors.grey[100],
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Theme(
            data: Theme.of(context).copyWith(
              textSelectionTheme: const TextSelectionThemeData(
                cursorColor: Colors.blue, // Màu con trỏ
                selectionColor: Colors.lightBlue, // Màu bôi đen
                selectionHandleColor: Colors.blue, // Màu dấu kéo
              ),
            ),
            child: TextField(
              focusNode: focusNode,
              controller: controller,
              readOnly: readOnly,
              onTap: onTap,
              onChanged: (value) {
                // ✅ Xử lý format khi người dùng nhập số tiền
                if (isCurrency) {
                  String raw = value.replaceAll('.', '').replaceAll(',', '');
                  if (raw.isEmpty) return;

                  final number = int.tryParse(raw);
                  if (number != null) {
                    controller.value = TextEditingValue(
                      text: currencyFormatter.format(number),
                      selection: TextSelection.collapsed(
                        offset: currencyFormatter.format(number).length,
                      ),
                    );
                  }
                }

                if (onChanged != null) {
                  onChanged!(value);
                }
              },
              keyboardType: keyboardType,
              maxLength: maxLength,
              maxLengthEnforcement: MaxLengthEnforcement.enforced,
              textAlignVertical: TextAlignVertical.center, // Căn giữa
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: hintText,
                counterText: "",
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 14,
                ),
                suffixIcon: enableClear && controller.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, size: 18),
                        onPressed: () {
                          controller.clear();
                          if (onChanged != null) {
                            onChanged!('');
                          }
                        },
                      )
                    : null,
              ),
              style: const TextStyle(fontSize: 13),
              maxLines: maxLines ?? 1,
              minLines: minLines,
              inputFormatters: [
                if (capitalizeFirstLetter) CapitalizeFirstLetterFormatter(),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
