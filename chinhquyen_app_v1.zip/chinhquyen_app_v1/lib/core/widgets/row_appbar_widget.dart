import 'package:flutter/material.dart';

class RowAppbarWidget extends StatelessWidget {
  const RowAppbarWidget({
    super.key,
    this.text,
    this.iconColor = Colors.blue, // 👈 màu mặc định
    this.actions, // 👈 danh sách action bên phải
  });

  final String? text;
  final Color iconColor; // 👈 nhận màu icon từ bên ngoài
  final List<Widget>? actions;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        IconButton(
          icon: Icon(Icons.arrow_back, color: iconColor),
          onPressed: () => Navigator.pop(context),
        ),
        Expanded(
          child: Text(
            text ?? '',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: iconColor,
            ),
          ),
        ),
        if (actions != null)
          IconTheme(
            // đảm bảo icon trong actions dùng cùng màu
            data: IconThemeData(color: iconColor),
            child: Row(mainAxisSize: MainAxisSize.min, children: actions!),
          ),
      ],
    );
  }
}
