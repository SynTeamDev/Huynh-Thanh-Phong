import 'package:flutter/material.dart';
import 'package:another_flushbar/flushbar.dart';
import '../utils/delay_btn_helper.dart';

void showTopSnackbarFlushbar(BuildContext context, String message) {
  Flushbar(
    flushbarPosition: FlushbarPosition.TOP,
    //duration: const Duration(seconds: 1),
    duration: const Duration(
      milliseconds: 1100,
    ), // Giảm thời gian hiển thị xuống 1.1 giây
    backgroundColor: Colors.blue,
    padding: EdgeInsets.zero,
    margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
    borderRadius: BorderRadius.circular(12),
    messageText: Container(
      height: 100,
      decoration: BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/icons/bgsnank.png'),
          fit: BoxFit.cover,
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      alignment: Alignment.centerLeft,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Text(
        message,
        style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),
      ),
    ),
  ).show(context);
}

void showSnack(BuildContext context, String text) {
  if (!GlobalButtonDisableHelper.isDisabled) {
    GlobalButtonDisableHelper.disableTemporarily();
    showTopSnackbarFlushbar(context, text);
  }
}
