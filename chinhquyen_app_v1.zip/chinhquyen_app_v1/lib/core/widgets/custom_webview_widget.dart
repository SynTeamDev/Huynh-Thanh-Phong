import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../shared/webview_controller.dart';
import 'custom_appbar_widget.dart';
import 'loading_widget.dart';

class CustomWebViewWidget extends StatefulWidget {
  final String url;
  final String? title; // Nếu muốn hiện AppBar

  const CustomWebViewWidget({super.key, required this.url, this.title});

  @override
  State<CustomWebViewWidget> createState() => _CustomWebViewWidgetState();
}

class _CustomWebViewWidgetState extends State<CustomWebViewWidget> {
  late final WebViewController _controller;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _controller = CustomWebViewController.create(
      widget.url,
      (loading) => setState(() => isLoading = loading),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade50,
      appBar: widget.title != null
          ? CustomAppBarWidget(title: widget.title!)
          : null,
      body: SafeArea(
        child: Stack(
          children: [
            WebViewWidget(controller: _controller),
            if (isLoading) const LoadingWidget(),
          ],
        ),
      ),
    );
  }
}
