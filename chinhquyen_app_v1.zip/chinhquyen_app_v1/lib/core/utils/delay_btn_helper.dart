import 'dart:async';

class GlobalButtonDisableHelper {
  static bool _isDisabled = false;

  static bool get isDisabled => _isDisabled;

  static void disableTemporarily({int seconds = 2}) {
    if (_isDisabled) return;

    _isDisabled = true;
    Timer(Duration(seconds: seconds), () {
      _isDisabled = false;
    });
  }
}
