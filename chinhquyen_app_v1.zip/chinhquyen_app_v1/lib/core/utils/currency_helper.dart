import 'package:intl/intl.dart';

final currencyFormatter = NumberFormat('#,##0', 'vi_VN'); // Định dạng: 1.000.000