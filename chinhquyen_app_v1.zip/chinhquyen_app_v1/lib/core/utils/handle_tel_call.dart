import 'package:url_launcher/url_launcher.dart';

Future<void> handleTelCall(String phone) async {
  // chuẩn hoá: giữ lại số và dấu +
  final cleaned = phone.replaceAll(RegExp(r'[^\d+]'), '');
  if (cleaned.isEmpty) return;

  final uri = Uri(scheme: 'tel', path: cleaned);

  try {
    // mở màn hình gọi (dialer) với số đã điền
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok) {
      // tuỳ bạn xử lý thêm, ví dụ show SnackBar
      // debugPrint('Không mở được màn hình gọi');
    }
  } catch (e) {
    // debugPrint('Lỗi gọi điện: $e');
  }
}