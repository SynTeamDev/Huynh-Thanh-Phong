import 'dart:convert';

void prettyPrintJson(dynamic jsonData) {
  const chunkSize = 800; // số ký tự in mỗi lần
  final encoder = JsonEncoder.withIndent('  ');
  final prettyString = encoder.convert(jsonData);
  
  print('\x1B[32m[RESPONSE]\x1B[0m');
  for (var i = 0; i < prettyString.length; i += chunkSize) {
    final end = (i + chunkSize < prettyString.length)
        ? i + chunkSize
        : prettyString.length;
    print(prettyString.substring(i, end));
  }
}
