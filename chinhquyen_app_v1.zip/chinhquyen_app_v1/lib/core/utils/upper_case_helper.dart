import 'package:flutter/services.dart';

//! In hoa toàn bộ
class UpperCaseTextFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final upperText = newValue.text.toUpperCase();
    return newValue.copyWith(
      text: upperText,
      selection: TextSelection.collapsed(offset: upperText.length),
    );
  }
}

//! In hoa 1 chữ cái đầu
class CapitalizeFirstLetterFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final text = newValue.text;
    // Match ký tự đầu của từ, bao gồm tiếng Việt
    final capitalized = text.replaceAllMapped(
      RegExp(r'(^|\s)([a-zA-ZÀ-Ỹà-ỹ])', unicode: true),
      (match) => '${match.group(1) ?? ''}${match.group(2)!.toUpperCase()}',
    );
    return newValue.copyWith(
      text: capitalized,
      selection: TextSelection.collapsed(offset: capitalized.length),
    );
  }
}
