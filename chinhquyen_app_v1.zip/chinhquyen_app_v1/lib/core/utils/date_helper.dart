import 'package:intl/intl.dart';

String formatDate(String? rawDate) {
  try {
    final parsedDate = DateTime.parse(rawDate ?? '');
    return DateFormat('dd/MM/yyyy').format(parsedDate);
  } catch (_) {
    return '';
  }
}

String formatDateTime(String? rawDate) {
  try {
    final parsedDate = DateTime.parse(rawDate ?? '');
    return DateFormat('dd/MM/yyyy HH:mm').format(parsedDate);
  } catch (_) {
    return '';
  }
}

String formatDuration(Duration duration) {
  String twoDigits(int n) => n.toString().padLeft(2, '0');
  final hours = twoDigits(duration.inHours);
  final minutes = twoDigits(duration.inMinutes.remainder(60));
  final seconds = twoDigits(duration.inSeconds.remainder(60));
  return "$hours:$minutes:$seconds";
}

bool isSameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

DateTime? parseDate(dynamic v) {
  if (v == null) return null;
  if (v is DateTime) return v;
  if (v is String) {
    try {
      return DateTime.parse(v);
    } catch (_) {}
  }
  return null;
}
