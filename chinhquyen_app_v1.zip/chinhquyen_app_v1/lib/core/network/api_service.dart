import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:dio/dio.dart';
import 'package:intl/intl.dart';
import 'package:mime/mime.dart';
import 'package:path/path.dart' as p;

import '../../config/env.dart';
import '../../features/home-khampha-tracuu-map/presentation/widgets/home-khampha/dv_hanh_chinh_cong/models/dv_hanh_chinh_cong_model.dart';
import '../../features/home-khampha-tracuu-map/presentation/widgets/home-khampha/phan_anh_gop_y/models/phan_anh_gop_y_model.dart';
import '../../features/home-khampha-tracuu-map/presentation/widgets/home-khampha/quan_ly_cuoc_hop/models/quan_ly_cuoc_hop_model.dart';
import '../shared/enum.dart';
import '../shared/menu/menu_model.dart';
import '../utils/pretty_print_json.dart';

class ApiService {
  final Dio _dio;

  ApiService(this._dio) {
    _dio.options.baseUrl = Env.baseUrl;
    _dio.options.connectTimeout = const Duration(seconds: 10);
    _dio.options.receiveTimeout = const Duration(seconds: 10);
  }

  // Hàm kiểm tra đăng nhập
  Future<LoginEnum> checkLogin(String username, String password) async {
    try {
      final response = await _dio.get(
        '/api/procApp_ISWIFTSystemGetHash/$username',
      );

      if (response.statusCode == 200) {
        final serverHash = response.data?.toString().trim();

        if (serverHash == null || serverHash.isEmpty) {
          return LoginEnum.userNotFound;
        }

        print(
          '\x1B[33m[GET]\x1B[0m /api/procApp_ISWIFTSystemGetHash/$username',
        );
        prettyPrintJson(response.data);

        // Hash password nhập vào
        final bytes = utf8.encode(password);
        final digest = md5.convert(bytes);
        final passwordHash = digest.toString();

        return passwordHash == serverHash
            ? LoginEnum.success
            : LoginEnum.wrongPassword;
      } else {
        return LoginEnum.error;
      }
    } catch (e) {
      print('procApp_ISWIFTSystemGetHash | Login error: $e');
      return LoginEnum.error;
    }
  }

  //user info
  Future<Response> getUserInfo({String? username}) async {
    final response = await _dio.get(
      '/api/procApp_userinfo',
      queryParameters: {'username': username},
    );

    print('\x1B[33m[GET]\x1B[0m /api/procApp_userinfo?username=$username');
    prettyPrintJson(response.data);

    return response;
  }

  // Menu - admin
  Future<List<MenuModel>> fetchMenuAdmin(String locale) async {
    try {
      final response = await _dio.get('/api/procApp_menu/1');

      print('\x1B[33m[GET]\x1B[0m /api/procApp_menu/1');
      prettyPrintJson(response.data);

      if (response.statusCode == 200) {
        final List<dynamic> data = response.data;
        return data.map((item) => MenuModel.fromJson(item, locale)).toList();
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi fetchMenuAdmin: $e');
      return [];
    }
  }

  // Menu - user
  Future<List<MenuModel>> fetchMenuUser(String locale) async {
    try {
      final response = await _dio.get('/api/procApp_menu/2');

      print('\x1B[33m[GET]\x1B[0m /api/procApp_menu/2');
      prettyPrintJson(response.data);

      if (response.statusCode == 200) {
        final List<dynamic> data = response.data;
        return data.map((item) => MenuModel.fromJson(item, locale)).toList();
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi fetchMenuUser: $e');
      return [];
    }
  }

  // Menu - Tra cứu
  Future<List<MenuModel>> fetchMenuTraCuu(String locale) async {
    try {
      final response = await _dio.get('/api/procApp_menu/3');

      print('\x1B[33m[GET]\x1B[0m /api/procApp_menu/3');
      prettyPrintJson(response.data);

      if (response.statusCode == 200) {
        final List<dynamic> data = response.data;
        return data.map((item) => MenuModel.fromJson(item, locale)).toList();
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi fetchMenuTraCuu: $e');
      return [];
    }
  }

  // GET: Combobox api
  Future<List<Map<String, dynamic>>> fetchCbb({
    required String table,
    String keyword = '',
  }) async {
    try {
      final response = await _dio.get(
        '/api/procApp_GetCombobox',
        queryParameters: {'table': table, 'keyword': keyword},
      );

      print('\x1B[33m[GET]\x1B[0m /api/procApp_GetCombobox');
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('procApp_GetCombobox | Lỗi khi load fetchCbb: $e');
      return [];
    }
  }

  // GET: lấy DS canbo
  Future<List<Map<String, dynamic>>> fetchDSCANBO({
    int? pageIndex,
    String? noi_congtac,
    String? status,
    DateTime? ngay_ct1,
    DateTime? ngay_ct2,
  }) async {
    try {
      final response = await _dio.get(
        '/api/procApp_dmcanbo/canbo',
        queryParameters: {
          'pageIndex': pageIndex,
          'noi_congtac': noi_congtac,
          'status': status,
          'ngay_ct1': ngay_ct1?.toIso8601String(),
          'ngay_ct2': ngay_ct2?.toIso8601String(),
        },
      );

      print('\x1B[33m[GET]\x1B[0m /api/procApp_dmcanbo/canbo');
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi chạy fetchDSCANBO: $e');
      return [];
    }
  }

  // GET: lấy DS nhavanhoa
  Future<List<Map<String, dynamic>>> fetchDSNhaVanHoa({
    int? pageIndex,
    String? ten_location,
    DateTime? ngay_ct1,
    DateTime? ngay_ct2,
  }) async {
    try {
      final response = await _dio.get(
        '/api/procApp_tracuuthongtin/nhavanhoa',
        queryParameters: {
          'pageIndex': pageIndex,
          'ten_location': ten_location,
          'ngay_ct1': ngay_ct1?.toIso8601String(),
          'ngay_ct2': ngay_ct2?.toIso8601String(),
        },
      );

      print('\x1B[33m[GET]\x1B[0m /api/procApp_tracuuthongtin/nhavanhoa');
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi chạy fetchDSNhaVanHoa: $e');
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> fetchDSTramYTe({
    int? pageIndex,
    String? ten_location,
    DateTime? ngay_ct1,
    DateTime? ngay_ct2,
  }) async {
    try {
      final response = await _dio.get(
        '/api/procApp_tracuuthongtin/tramyte',
        queryParameters: {
          'pageIndex': pageIndex,
          'ten_location': ten_location,
          'ngay_ct1': ngay_ct1?.toIso8601String(),
          'ngay_ct2': ngay_ct2?.toIso8601String(),
        },
      );

      print('\x1B[33m[GET]\x1B[0m /api/procApp_tracuuthongtin/tramyte');
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi chạy fetchDSTramYTe: $e');
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> fetchDSTruongHoc({
    int? pageIndex,
    String? ten_location,
    DateTime? ngay_ct1,
    DateTime? ngay_ct2,
  }) async {
    try {
      final response = await _dio.get(
        '/api/procApp_tracuuthongtin/truonghoc',
        queryParameters: {
          'pageIndex': pageIndex,
          'ten_location': ten_location,
          'ngay_ct1': ngay_ct1?.toIso8601String(),
          'ngay_ct2': ngay_ct2?.toIso8601String(),
        },
      );

      print('\x1B[33m[GET]\x1B[0m /api/procApp_tracuuthongtin/truonghoc');
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi chạy fetchDSTruongHoc: $e');
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> fetchDSCongDong({
    int? pageIndex,
    String? ten_location,
    DateTime? ngay_ct1,
    DateTime? ngay_ct2,
  }) async {
    try {
      final response = await _dio.get(
        '/api/procApp_tracuuthongtin/congdong',
        queryParameters: {
          'pageIndex': pageIndex,
          'ten_location': ten_location,
          'ngay_ct1': ngay_ct1?.toIso8601String(),
          'ngay_ct2': ngay_ct2?.toIso8601String(),
        },
      );

      print('\x1B[33m[GET]\x1B[0m /api/procApp_tracuuthongtin/congdong');
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi chạy fetchDSCongDong: $e');
      return [];
    }
  }

  // GET: quan_ly_cuoc_hop và xài được cho Filter
  Future<List<Map<String, dynamic>>> fetchQLCuocHop({
    int? pageIndex,
    required DateTime? ngay_ct1,
    required DateTime? ngay_ct2,
    required String? ma_lcuochop,
    required String? dia_chi,
    required String? status,
  }) async {
    try {
      final response = await _dio.get(
        '/api/procApp_qlcuochop',

        queryParameters: {
          'pageIndex': pageIndex,
          'ngay_ct1': ngay_ct1?.toIso8601String(),
          'ngay_ct2': ngay_ct2?.toIso8601String(),
          'ma_lcuochop': ma_lcuochop,
          'dia_chi': dia_chi,
          'status': status,
        },
      );

      print('\x1B[33m[GET]\x1B[0m /api/procApp_qlcuochop');
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi load fetchQLCuocHop: $e');
      return [];
    }
  }

  // POST: insert quan_ly_cuoc_hop
  Future<bool> insertQLCuocHop(QuanLyCuocHopModel data) async {
    try {
      final response = await _dio.post(
        '/api/procApp_qlcuochop/insert',
        data: data.toJson(),
      );

      print('\x1B[33m[POST]\x1B[0m /api/procApp_qlcuochop/insert');
      prettyPrintJson(response.data);

      if (response.statusCode == 200) {
        print('✅ Insert thành công: ${response.data}');
        return true;
      } else {
        print('❌ Insert thất bại: ${response.statusCode}');
        return false;
      }
    } catch (e) {
      print('🚫 Lỗi khi gọi insertQLCuocHop: $e');
      return false;
    }
  }

  Future<Map<String, dynamic>> fetchLichCuocHop({
    required int pageIndex,
    required String username_current,
    required int year,
    required int month,
    DateTime? date, // <-- optional
  }) async {
    try {
      final qp = <String, dynamic>{
        'pageIndex': pageIndex,
        'username_current': username_current,
        'year': year,
        'month': month,
        if (date != null) 'date': DateFormat('yyyy-MM-dd').format(date), // 👈
      };

      final resp = await _dio.get(
        '/api/procApp_qlcuochop/lichcuochop',
        queryParameters: qp,
      );

      print('\x1B[33m[GET]\x1B[0m /api/procApp_qlcuochop/lichcuochop');
      prettyPrintJson(resp.data);

      if (resp.statusCode == 200 && resp.data is Map) {
        final data = resp.data as Map;
        final items = List<Map<String, dynamic>>.from(
          data['items'] ?? const [],
        );
        final days = (data['days'] as List? ?? const [])
            .map((e) => int.tryParse(e.toString()) ?? 0)
            .where((e) => e > 0)
            .toList();
        return {'items': items, 'days': days};
      }
      return {'items': <Map<String, dynamic>>[], 'days': <int>[]};
    } catch (e) {
      print('Lỗi fetchLichCuocHop: $e');
      return {'items': <Map<String, dynamic>>[], 'days': <int>[]};
    }
  }

  Future<List<Map<String, dynamic>>> fetchDSTKDiaDiem({
    int? pageIndex,
    String? ma_lhhd,
    String? ten_location,
    DateTime? ngay_ct1,
    DateTime? ngay_ct2,
  }) async {
    try {
      final response = await _dio.get(
        '/api/procApp_timkiemdiadiem',
        queryParameters: {
          'pageIndex': pageIndex,
          'ma_lhhd': ma_lhhd,
          'ten_location': ten_location,
          'ngay_ct1': ngay_ct1?.toIso8601String(),
          'ngay_ct2': ngay_ct2?.toIso8601String(),
        },
      );

      print('\x1B[33m[GET]\x1B[0m /api/procApp_timkiemdiadiem');
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi chạy fetchDSTKDiaDiem: $e');
      return [];
    }
  }

  // GET: phan_anh_gop_y và xài được cho Filter
  Future<List<Map<String, dynamic>>> fetchPhanAnh({int? pageIndex}) async {
    try {
      final response = await _dio.get(
        '/api/procApp_dmpagopy',

        queryParameters: {'pageIndex': pageIndex},
      );

      print('\x1B[33m[GET]\x1B[0m /api/procApp_dmpagopy');
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi load fetchPhanAnh: $e');
      return [];
    }
  }

  // POST: insert phan_anh_gop_y
  Future<bool> insertPhanAnh(PhanAnhGopYModel data) async {
    try {
      final response = await _dio.post(
        '/api/procApp_dmpagopy/insert',
        data: data.toJson(),
      );

      print('\x1B[33m[POST]\x1B[0m /api/procApp_dmpagopy/insert');
      prettyPrintJson(response.data);

      if (response.statusCode == 200) {
        print('✅ Insert thành công: ${response.data}');
        return true;
      } else {
        print('❌ Insert thất bại: ${response.statusCode}');
        return false;
      }
    } catch (e) {
      print('🚫 Lỗi khi gọi insertPhanAnh: $e');
      return false;
    }
  }

  /// Upload 1 file -> trả về URL public từ backend
  Future<String?> uploadFile(File file) async {
    try {
      final fileName = p.basename(file.path);
      final mime = lookupMimeType(file.path) ?? 'application/octet-stream';

      final form = FormData.fromMap({
        'file': await MultipartFile.fromFile(
          file.path,
          filename: fileName,
          contentType: DioMediaType.parse(mime),
        ),
      });

      final res = await _dio.post(
        '/api/Upload/single',
        data: form,
        onSendProgress: (sent, total) {
          if (total != -1) {
            final percent = (sent / total * 100).toStringAsFixed(0);
            print('⬆️ Upload single: $percent%');
          }
        },
      );

      if (res.statusCode == 200) {
        // backend trả { url, name, size, ext }
        return (res.data is Map<String, dynamic>)
            ? (res.data['url'] as String?)
            : (res.data['url']?.toString());
      }
      return null;
    } catch (e) {
      print('❌ uploadFile error: $e');
      return null;
    }
  }

  /// Upload nhiều file -> trả về danh sách URL
  Future<List<String>> uploadMultiFiles(List<File> files) async {
    try {
      final parts = <MultipartFile>[];
      for (final f in files) {
        final fileName = p.basename(f.path);
        final mime = lookupMimeType(f.path) ?? 'application/octet-stream';
        parts.add(
          await MultipartFile.fromFile(
            f.path,
            filename: fileName,
            contentType: DioMediaType.parse(mime),
          ),
        );
      }

      final form = FormData.fromMap({'files': parts});

      final res = await _dio.post(
        '/api/Upload/multi',
        data: form,
        onSendProgress: (sent, total) {
          if (total != -1) {
            final percent = (sent / total * 100).toStringAsFixed(0);
            print('⬆️ Upload multi: $percent%');
          }
        },
      );

      if (res.statusCode == 200) {
        // backend trả List<{url, name, size, ext}>
        final data = res.data;
        if (data is List) {
          return data
              .map(
                (e) => (e is Map<String, dynamic>)
                    ? (e['url'] as String)
                    : e['url'].toString(),
              )
              .toList();
        }
      }
      return [];
    } catch (e) {
      print('❌ uploadMultiFiles error: $e');
      return [];
    }
  }

  // GET: dv_hanh_chinh_cong và xài được cho Filter
  Future<List<Map<String, dynamic>>> fetchDVHanhChinhCong({
    int? pageIndex,
    required DateTime? ngay_ct1,
    required DateTime? ngay_ct2,
    required String? ma_hccong,
  }) async {
    try {
      final response = await _dio.get(
        '/api/procApp_dvhanhchinhcong',

        queryParameters: {
          'pageIndex': pageIndex,
          'ngay_ct1': ngay_ct1?.toIso8601String(),
          'ngay_ct2': ngay_ct2?.toIso8601String(),
          'ma_hccong': ma_hccong,
        },
      );

      print('\x1B[33m[GET]\x1B[0m /api/procApp_dvhanhchinhcong');
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi load fetchDVHanhChinhCong: $e');
      return [];
    }
  }

  // POST: insert dv_hanh_chinh_cong
  Future<bool> insertDVHanhChinhCong(DVHanhChinhCongModel data) async {
    try {
      final response = await _dio.post(
        '/api/procApp_dvhanhchinhcong/insert',
        data: data.toJson(),
      );

      print('\x1B[33m[POST]\x1B[0m /api/procApp_dvhanhchinhcong/insert');
      prettyPrintJson(response.data);

      if (response.statusCode == 200) {
        print('✅ Insert thành công: ${response.data}');
        return true;
      } else {
        print('❌ Insert thất bại: ${response.statusCode}');
        return false;
      }
    } catch (e) {
      print('🚫 Lỗi khi gọi insertDVHanhChinhCong: $e');
      return false;
    }
  }

  Future<List<Map<String, dynamic>>> fetch_st_QueryHCCONG({
    required String? ma_hccong,
  }) async {
    try {
      final response = await _dio.get(
        '/api/st_QueryHCCONG',

        queryParameters: {'ma_hccong': ma_hccong},
      );

      print('\x1B[33m[GET]\x1B[0m /api/st_QueryHCCONG');
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi load fetch_st_QueryHCCONG: $e');
      return [];
    }
  }

  // GET: dv_hanh_chinh_cong và xài được cho Filter
  Future<List<Map<String, dynamic>>> fetchDanhBaCoQuan({
    int? pageIndex,
    required DateTime? ngay_ct1,
    required DateTime? ngay_ct2,
    required String? ma_loai,
    required String? ma_ttp,
    required String? ma_phuongxa,
  }) async {
    try {
      final response = await _dio.get(
        '/api/procApp_danhbacoquan/danhbacoquan',

        queryParameters: {
          'pageIndex': pageIndex,
          'ngay_ct1': ngay_ct1?.toIso8601String(),
          'ngay_ct2': ngay_ct2?.toIso8601String(),
          'ma_loai': ma_loai,
          'ma_ttp': ma_ttp,
          'ma_phuongxa': ma_phuongxa,
        },
      );

      print('\x1B[33m[GET]\x1B[0m /api/procApp_danhbacoquan/danhbacoquan');
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi load fetchDanhBaCoQuan: $e');
      return [];
    }
  }

  // GET: lấy đoạn chat
  Future<List<Map<String, dynamic>>> fetchDoanChat({int? pageIndex}) async {
    try {
      final response = await _dio.get(
        '/api/procApp_chatMessages/doanchat',
        queryParameters: {'pageIndex': pageIndex},
      );

      print('\x1B[33m[GET]\x1B[0m /api/procApp_chatMessages/doanchat');
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('fetchDoanChat | Lỗi khi load fetchDoanChat: $e');
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> fetchNhomChat({
    int? pageIndex,
    required int? userId,
  }) async {
    try {
      final response = await _dio.get(
        '/api/procApp_chatMessages/nhomchat',
        queryParameters: {'pageIndex': pageIndex, 'UserId': userId},
      );

      print('\x1B[33m[GET]\x1B[0m /api/procApp_chatMessages/nhomchat');
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('fetchNhomChat | Lỗi khi load fetchNhomChat: $e');
      return [];
    }
  }

  Future<void> createGroupChat({
    required String groupName,
    required int createdBy,
    required List<int> userIds,
  }) async {
    try {
      final response = await _dio.post(
        '/api/procApp_chatMessages/creategroup',
        data: {
          'groupName': groupName,
          'createdBy': createdBy,
          'userIds': userIds,
        },
      );

      print('\x1B[33m[POST]\x1B[0m /api/procApp_chatMessages/creategroup');
      prettyPrintJson(response.data);

      if (response.statusCode == 200) {
        final groupId = response.data['groupId'];
        print("✅ Tạo nhóm thành công với ID: $groupId");
      }
    } catch (e) {
      print("❌ Lỗi tạo nhóm: $e");
    }
  }

  Future<List<Map<String, dynamic>>> fetchChatMessageContent({
    int? pageIndex,
    required String? sender,
    required String? receiver,
  }) async {
    try {
      final response = await _dio.get(
        '/api/procApp_chatMessages/chat-1:1-content',

        queryParameters: {
          'pageIndex': pageIndex,
          'Sender': sender,
          'Receiver': receiver,
        },
      );

      print('\x1B[33m[GET]\x1B[0m /api/procApp_chatMessages/chat-1:1-content');
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi load fetchChatMessageContent: $e');
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> fetchLastMessageContent({
    required String? sender,
    required String? receiver,
  }) async {
    try {
      final response = await _dio.get(
        '/api/procApp_chatMessages/last-message-content',

        queryParameters: {'Sender': sender, 'Receiver': receiver},
      );

      print(
        '\x1B[33m[GET]\x1B[0m /api/procApp_chatMessages/last-message-content',
      );
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi load fetchLastMessageContent: $e');
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> fetchGroupChatMessageContent({
    int? pageIndex,
    required String? groupId,
  }) async {
    try {
      final response = await _dio.get(
        '/api/procApp_chatMessages/chat-group-content',

        queryParameters: {'pageIndex': pageIndex, 'GroupId': groupId},
      );

      print(
        '\x1B[33m[GET]\x1B[0m /api/procApp_chatMessages/chat-group-content',
      );
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi load fetchGroupChatMessageContent: $e');
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> fetchGroupLastMessageContent({
    required String? groupId,
  }) async {
    try {
      final response = await _dio.get(
        '/api/procApp_chatMessages/last-message-group',

        queryParameters: {'GroupId': groupId},
      );

      print(
        '\x1B[33m[GET]\x1B[0m /api/procApp_chatMessages/last-message-group',
      );
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi load fetchGroupLastMessageContent: $e');
      return [];
    }
  }

  //! type = 1 là guong sang, type = 2 là tin chính trị
  Future<List<Map<String, dynamic>>> fetchDmTamGuongSang({
    int? type,
    int? pageIndex,
  }) async {
    try {
      final response = await _dio.get(
        '/api/procApp_dmtamguongsang/tam_guong_sang',

        queryParameters: {'type': type, 'pageIndex': pageIndex},
      );

      print('\x1B[33m[GET]\x1B[0m /api/procApp_dmtamguongsang/tam_guong_sang');
      prettyPrintJson(response.data);

      if (response.statusCode == 200 && response.data is List) {
        return List<Map<String, dynamic>>.from(response.data);
      } else {
        return [];
      }
    } catch (e) {
      print('Lỗi khi load fetchDmTamGuongSang: $e');
      return [];
    }
  }
}

//! 1 file dmttin
extension DmttinUpload on ApiService {
  Future<Map<String, dynamic>?> uploadDmttinFile({
    required File file,
    required int userId,
    void Function(int sent, int total)? onProgress,
  }) async {
    final name = p.basename(file.path);
    final mime = lookupMimeType(file.path) ?? 'application/octet-stream';

    final form = FormData.fromMap({
      'userId': userId,
      'file': await MultipartFile.fromFile(
        file.path,
        filename: name,
        contentType: DioMediaType.parse(mime),
      ),
    });

    final res = await _dio.post(
      '/api/procApp_dmpagopy/upload',
      data: form,
      onSendProgress: onProgress,
    );

    if (res.statusCode == 200 && res.data is Map) {
      return Map<String, dynamic>.from(res.data);
    }
    return null;
  }
}

//! nhiều file (tuần tự) dmttin
extension MultiUpload on ApiService {
  Future<List<Map<String, dynamic>>> uploadDmttinFiles({
    required List<File> files,
    required int userId,
    void Function(int index, int sent, int total)? onProgress,
  }) async {
    final results = <Map<String, dynamic>>[];
    for (var i = 0; i < files.length; i++) {
      final r = await uploadDmttinFile(
        file: files[i],
        userId: userId,
        onProgress: (s, t) => onProgress?.call(i, s, t),
      );
      if (r == null) return []; // thất bại -> trả rỗng để xử lý chung
      results.add(r);
    }
    return results;
  }
}
