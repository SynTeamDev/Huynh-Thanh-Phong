import 'package:signalr_core/signalr_core.dart';

import '../../config/env.dart';

// Typing listeners (mới)
typedef TypingListener = void Function(String senderUserId, bool isTyping);


class ChatService {
  late HubConnection _connection;
  final List<void Function(String sender, String message)> _listeners = [];



  //! dành cho group chat
  final List<
    void Function(
      String senderId,
      int groupId,
      String message,
      String senderName,
    )
  >
  _groupListeners = []; //!

  // Typing listeners (mới)
  final List<TypingListener> _typingListeners = [];

  void addTypingListener(TypingListener cb) {
    _typingListeners.removeWhere((e) => e == cb);
    _typingListeners.add(cb);
  }

  void removeTypingListener(TypingListener cb) {
    _typingListeners.remove(cb);
  }

  String? _userId;

  Future<void> connect({required String userId}) async {
    // Nếu đã khởi tạo rồi → kiểm tra trạng thái
    if (_userId == userId &&
        _connection.state == HubConnectionState.connected) {
      print("⚠️ Đã kết nối rồi với userId=$userId");
      return;
    }
    _listeners.clear(); // clear listener cũ
    // Nếu chưa có _connection hoặc đã disconnect thì tạo mới
    _connection = HubConnectionBuilder()
        .withUrl(
          '${Env.baseUrl}/chatHub?userId=$userId',
          HttpConnectionOptions(transport: HttpTransportType.webSockets),
        )
        .build();
    _connection.onclose((error) {
      print('❌ Mất kết nối: $error');
    });
    _connection.on('ReceiveMessage', (args) {
      final sender = args?[0] as String;
      final message = args?[1] as String;
      print('📥 Nhận được từ $sender: $message');
      for (final listener in _listeners) {
        listener(sender, message);
      }
    });
    //! dành cho group chat
    _connection.on('ReceiveGroupMessage', (args) {
      final senderId = args?[0] as String;
      final groupId = args?[1] as int;
      final message = args?[2] as String;
      final senderName = args?[3] as String; // ✅ lấy nickname

      for (final listener in _groupListeners) {
        listener(senderId, groupId, message, senderName);
      }
    }); //!

    // 🔔 Lắng nghe typing
    _connection.on('OnTyping', (args) {
      final sender = (args?[0] ?? '').toString();
      final isTyping = args?[1] == true;
      for (final l in _typingListeners) l(sender, isTyping);
    });



    await _connection.start();
    _userId = userId;
    print('✅ Kết nối ChatHub thành công với userId=$userId');
  }

  void addListener(void Function(String sender, String message) callback) {
    _listeners.add(callback);
  }

  Future<void> sendMessage(
    String sender,
    String receiver,
    String message,
  ) async {
    print("📤 Gửi từ $sender đến $receiver: $message");
    print("🔌 Trạng thái kết nối: ${_connection.state}");
    await _connection.invoke('SendMessage', args: [sender, receiver, message]);
  }

  // 🚀 Gửi tín hiệu typing
  Future<void> sendTyping(
    String fromUserId,
    String toUserId,
    bool isTyping,
  ) async {
    await _connection.invoke('Typing', args: [fromUserId, toUserId, isTyping]);
  }

  //! dành cho group chat
  HubConnection get connection => _connection;

  void addGroupListener(
    void Function(String sender, int groupId, String message, String senderName)
    callback,
  ) {
    _groupListeners.removeWhere((e) => e == callback); // Xóa nếu đã tồn tại
    _groupListeners.add(callback);
  }

  Future<void> sendGroupMessage(
    String sender,
    int groupId,
    String message,
  ) async {
    print("📤 [Group $groupId] $sender: $message");
    await _connection.invoke(
      'SendGroupMessage',
      args: [sender, groupId, message],
    );
  }

  void removeGroupListener(
    void Function(String sender, int groupId, String message, String senderName)
    callback,
  ) {
    _groupListeners.remove(callback);
  }
  //!

  Future<void> disconnect() async {
    await _connection.stop();
    _listeners.clear();
  }


}
