import 'package:flutter/material.dart';
import 'package:chinhquyen_app/core/widgets/loading_widget.dart';

import 'app_target.dart';

class OpenExternalAppPage extends StatefulWidget {
  const OpenExternalAppPage({super.key, required this.app});
  final ExternalApp app;

  @override
  State<OpenExternalAppPage> createState() => _OpenExternalAppPageState();
}

class _OpenExternalAppPageState extends State<OpenExternalAppPage> {
  @override
  void initState() {
    super.initState();
    // gọi sau frame đầu để tránh edge case
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await Launcher.openApp(widget.app);
      if (!mounted) return;
      if (Navigator.canPop(context)) Navigator.pop(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade50,
      body: LoadingWidget(),
    );
  }
}
