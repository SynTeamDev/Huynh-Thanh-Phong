import 'dart:async';
import 'dart:io';
import 'package:url_launcher/url_launcher.dart';

class AppTarget {
  final String scheme; // ví dụ: 'momo://' hoặc 'ahamove://'
  final Uri storeUrlAndroid; // link Google Play
  final Uri? storeUrliOS; // (nếu có) link App Store
  final Uri? fallbackWeb; // tuỳ chọn

  const AppTarget({
    required this.scheme,
    required this.storeUrlAndroid,
    this.storeUrliOS,
    this.fallbackWeb,
  });
}

enum ExternalApp {
  momo,
  ahamove,
  vnptSmartCA,
  zaloPay,
  vnPay,
  viettelPay,
  vietinBankiPay,
  vnptPay,
  viettel,
  mobifone,
  myVnPT,
}

class Launcher {
  static final _momo = AppTarget(
    scheme: 'momo://app',
    storeUrlAndroid: Uri.parse(
      'https://play.google.com/store/apps/details?id=com.mservice.momotransfer&hl=vi',
    ),
  );

  static final _ahamove = AppTarget(
    scheme: 'ahamove://',
    storeUrlAndroid: Uri.parse(
      'https://play.google.com/store/apps/details?id=com.ahamove.user&hl=vi',
    ),
  );

  static final _vnptSmartCA = AppTarget(
    scheme: 'vnptSmartCA://',
    storeUrlAndroid: Uri.parse(
      'https://play.google.com/store/apps/details?id=com.vnptit.vnpt_kyso_v2&hl=vi',
    ),
  );

  static final _zaloPay = AppTarget(
    scheme: 'zaloPay://',
    storeUrlAndroid: Uri.parse(
      'https://play.google.com/store/apps/details?id=vn.com.vng.zalopay&hl=vi',
    ),
  );

  static final _vnPay = AppTarget(
    scheme: 'vnPay://',
    storeUrlAndroid: Uri.parse(
      'https://play.google.com/store/apps/details?id=vnpay.smartacccount&hl=vi',
    ),
  );

  static final _viettelPay = AppTarget(
    scheme: 'viettelPay://',
    storeUrlAndroid: Uri.parse(
      'https://play.google.com/store/apps/details?id=com.bplus.bankplusbccs&hl=vi',
    ),
  );

  static final _vietinBankiPay = AppTarget(
    scheme: 'vietinBankiPay://',
    storeUrlAndroid: Uri.parse(
      'https://play.google.com/store/apps/details?id=com.vietinbank.ipay&hl=vi',
    ),
  );

  static final _vnptPay = AppTarget(
    scheme: 'vnptPay://',
    storeUrlAndroid: Uri.parse(
      'https://play.google.com/store/apps/details?id=vnptpay.vnptmedia.vnpt.com.vnptpay&hl=vi',
    ),
  );

  static final _viettel = AppTarget(
    scheme: 'viettel://',
    storeUrlAndroid: Uri.parse(
      'https://play.google.com/store/apps/details?id=com.vttm.vietteldiscovery&hl=vi',
    ),
  );

  static final _mobifone = AppTarget(
    scheme: 'mobifone://',
    storeUrlAndroid: Uri.parse(
      'https://play.google.com/store/apps/details?id=vms.com.vn.mymobifone&hl=vi',
    ),
  );

  static final _myVnPT = AppTarget(
    scheme: 'myVnPT://',
    storeUrlAndroid: Uri.parse(
      'https://play.google.com/store/apps/details?id=com.vnp.myvinaphone&hl=vi',
    ),
  );

  static AppTarget _targetOf(ExternalApp app) {
    switch (app) {
      case ExternalApp.momo:
        return _momo;
      case ExternalApp.ahamove:
        return _ahamove;
      case ExternalApp.vnptSmartCA:
        return _vnptSmartCA;
      case ExternalApp.zaloPay:
        return _zaloPay;
      case ExternalApp.vnPay:
        return _vnPay;
      case ExternalApp.viettelPay:
        return _viettelPay;
      case ExternalApp.vietinBankiPay:
        return _vietinBankiPay;
      case ExternalApp.vnptPay:
        return _vnptPay;
      case ExternalApp.viettel:
        return _viettel;
      case ExternalApp.mobifone:
        return _mobifone;
      case ExternalApp.myVnPT:
        return _myVnPT;
    }
  }

  static Future<void> openApp(ExternalApp app) async {
    final target = _targetOf(app);
    final schemeUri = Uri.parse(target.scheme);

    try {
      final canOpen = await canLaunchUrl(schemeUri);
      if (canOpen) {
        final ok = await launchUrl(
          schemeUri,
          mode: LaunchMode.externalApplication,
        ).timeout(const Duration(seconds: 2), onTimeout: () => false);

        if (ok == true) return;
      }

      // Không mở được app → mở store
      final storeUrl = Platform.isIOS
          ? (target.storeUrliOS ?? target.fallbackWeb ?? target.storeUrlAndroid)
          : target.storeUrlAndroid;

      final storeOpened = await launchUrl(
        storeUrl,
        mode: LaunchMode.externalApplication,
      );

      if (!storeOpened && target.fallbackWeb != null) {
        await launchUrl(
          target.fallbackWeb!,
          mode: LaunchMode.externalApplication,
        );
      }
    } catch (_) {
      if (target.fallbackWeb != null) {
        await launchUrl(
          target.fallbackWeb!,
          mode: LaunchMode.externalApplication,
        );
      }
    }
  }
}
