import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../config/env.dart';

class MenuModel {
  final String id;
  final String labelVi;
  final String labelEn;
  final String groupNameVi;
  final String groupNameEn;
  final bool isClass; // cột isclass (1/0)
  final String iconUrl; // build từ imgUrl + Env.baseUrl
  final String url; // nếu là link ngoài
  final bool requireLogin; // cần đăng nhập mới cho vào
  final bool enabled; // bật/tắt chức năng
  final void Function(BuildContext) onTap;

  MenuModel({
    required this.id,
    required this.labelVi,
    required this.labelEn,
    required this.groupNameVi,
    required this.groupNameEn,
    required this.isClass,
    required this.iconUrl,
    required this.url,
    required this.requireLogin,
    required this.enabled,
    required this.onTap,
  });

  factory MenuModel.fromJson(Map<String, dynamic> json, String locale) {
    final isClass = json['isclass'] == 1 || json['isclass'] == true;
    final id = (json['id'] ?? '').toString();
    final labelVi = (json['label'] ?? '').toString();
    final labelEn = (json['label2'] ?? '').toString();
    final groupNameVi = (json['groupName'] ?? '').toString();
    final groupNameEn = (json['groupName2'] ?? '').toString();
    final url = (json['url'] ?? '').toString();
    final requireLogin =
        json['requireLogin'] == 1 || json['requireLogin'] == true;
    final enabled =
        !(json['enabled'] == 0 || json['enabled'] == false); // default: true

    // imgUrl trong DB là kiểu "/images/xxx.png"
    final rawImg = (json['imgUrl'] ?? '').toString();
    final iconUrl = rawImg.startsWith('http')
        ? rawImg
        : '${Env.baseUrl}${rawImg.startsWith('/') ? '' : '/'}$rawImg';

    final title = (locale.toLowerCase() == 'vi' ? labelVi : labelEn);

    return MenuModel(
      id: id,
      labelVi: labelVi,
      labelEn: labelEn,
      groupNameVi: groupNameVi,
      groupNameEn: groupNameEn,
      isClass: isClass,
      iconUrl: iconUrl,
      url: url,
      requireLogin: requireLogin,
      enabled: enabled,
      onTap: (context) {
        if (isClass) {
          context.push('/screen/$id?title=${Uri.encodeComponent(title)}');
        } else {
          context.push(
            '/webview?title=${Uri.encodeComponent(title)}'
            '&url=${Uri.encodeComponent(url)}',
          );
        }
      },
    );
  }
}
