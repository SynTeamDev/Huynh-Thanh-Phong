// grid_menu_widget.dart
import 'package:chinhquyen_app/core/widgets/loading_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:go_router/go_router.dart';

import '../../../features/auth/presentation/providers/profile_provider.dart';

import '../../widgets/custom_snackbar_widget.dart';
import 'menu_model.dart';

class GridMenuWidget extends ConsumerWidget {
  const GridMenuWidget({super.key, required this.items});
  final List<MenuModel> items;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.75,
      ),
      itemBuilder: (context, index) {
        final it = items[index];

        return InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () {
            // 1) Tắt chức năng -> báo đang phát triển
            if (!it.enabled) {
              showSnack(context, 'Đang được phát triển!');
              return;
            }

            // 2) Yêu cầu đăng nhập -> kiểm tra profile
            final profile = ref.read(profileProvider).value;
            if (it.requireLogin && profile == null) {
              // showSnack( context, 'Vui lòng đăng nhập để sử dụng tính năng này!', );
              // tuỳ bạn có muốn điều hướng luôn không:
              context.push('/login');
              return;
            }

            // 3) Cho vào tính năng
            it.onTap(context);
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.blue.shade100),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: CachedNetworkImage(
                    imageUrl: it.iconUrl,
                    width: 46,
                    height: 46,
                    fit: BoxFit.cover,
                    placeholder: (_, __) => const SizedBox(
                      width: 20,
                      height: 20,
                      child: LoadingWidget(),
                    ),
                    errorWidget: (_, __, ___) =>
                        const Icon(Icons.image_not_supported),
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                it.labelVi, // hoặc label theo locale
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        );
      },
    );
  }
}
