// menu_providers.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../network/api_provider.dart';
import 'menu_model.dart';

/// Lấy menu USER theo locale
final menuUserProvider = FutureProvider.family<List<MenuModel>, String>((
  ref,
  locale,
) async {
  final api = ref.read(apiServiceProvider);
  return api.fetchMenuUser(locale);
});

/// Nếu cần ADMIN:
final menuAdminProvider = FutureProvider.family<List<MenuModel>, String>((
  ref,
  locale,
) async {
  final api = ref.read(apiServiceProvider);
  return api.fetchMenuAdmin(locale);
});

/// Lấy menu Tracuu theo locale
final menuTracuuProvider = FutureProvider.family<List<MenuModel>, String>((
  ref,
  locale,
) async {
  final api = ref.read(apiServiceProvider);
  return api.fetchMenuTraCuu(locale);
});
