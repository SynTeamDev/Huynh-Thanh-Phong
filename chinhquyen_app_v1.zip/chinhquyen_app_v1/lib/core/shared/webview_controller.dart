import 'package:webview_flutter/webview_flutter.dart';

class CustomWebViewController {
  static WebViewController create(String initialUrl, Function(bool) onLoadingStateChange) {
    return WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (url) => onLoadingStateChange(true),
          onPageFinished: (url) => onLoadingStateChange(false),
          onWebResourceError: (error) {
            print("WebView Error: ${error.description}");
          },
        ),
      )
      ..loadRequest(Uri.parse(initialUrl));
  }
}
