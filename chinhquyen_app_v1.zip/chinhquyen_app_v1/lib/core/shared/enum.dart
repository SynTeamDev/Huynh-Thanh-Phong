// dữ liệu nào cố định thì dùng enum
enum LoginEnum { success, wrongPassword, userNotFound, error }

