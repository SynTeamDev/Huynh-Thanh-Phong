import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../widgets/form/date_field_widget.dart';
import '../widgets/form/filter_header.dart';
import '../widgets/form/vi_date_picker_widget.dart';

abstract class BaseFilter<T> extends ConsumerStatefulWidget {
  final DateTime initialFromDate;
  final DateTime initialToDate;
  final bool showDateFields; // Thêm tham số để quyết định hiển thị ngày tháng

  const BaseFilter({
    super.key,
    required this.initialFromDate,
    required this.initialToDate,
    this.showDateFields = true, // Mặc định là hiển thị
  });

  Future<T?> show(BuildContext context) async {
    return await showModalBottomSheet<T>(
      context: context,
      isScrollControlled: true,
      useRootNavigator: true, //! 👈 THÊM DÒNG NÀY, SỬA ĐÈ LÊN MENU NAVBAR
      isDismissible: false,
      enableDrag: false,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => this,
    );
  }
}

abstract class BaseFilterState<T, W extends BaseFilter<T>>
    extends ConsumerState<W> {
  late DateTime fromDate;
  late DateTime toDate;

  @override
  void initState() {
    super.initState();
    fromDate = widget.initialFromDate;
    toDate = widget.initialToDate;
  }

  Future<void> pickDate({required bool isFrom}) async {
    final picked = await showCustomVietnameseDatePicker(
      context: context,
      initialDate: isFrom ? fromDate : toDate,
    );
    if (picked != null) {
      setState(() {
        if (isFrom) {
          fromDate = picked;
        } else {
          toDate = picked;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 16,
        right: 16,
        top: 10,
      ),
      child: CustomScrollView(
        shrinkWrap: true,
        slivers: [
          SliverPersistentHeader(
            pinned: true,
            delegate: StickyHeaderDelegate(
              child: Container(
                color: Colors.white,
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.close, size: 20),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const Text(
                      'Điều kiện lọc',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SliverList(
            delegate: SliverChildListDelegate([
              const SizedBox(height: 5),
              // Chỉ hiển thị phần ngày tháng nếu showDateFields là true
              if (widget.showDateFields) ...[
                Row(
                  children: [
                    Expanded(
                      child: DateFieldWidget(
                        label: 'Từ ngày',
                        date: fromDate,
                        onTap: () => pickDate(isFrom: true),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: DateFieldWidget(
                        label: 'Đến ngày',
                        date: toDate,
                        onTap: () => pickDate(isFrom: false),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 5),
              ],
              ...buildFilterFields(),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context, getFilterResult()),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text(
                    'Nhận',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ]),
          ),
        ],
      ),
    );
  }

  // Lớp con phải triển khai phương thức này để cung cấp các trường nhập liệu
  List<Widget> buildFilterFields();

  // Lớp con phải triển khai phương thức này để trả về kết quả filter
  T getFilterResult();
}
