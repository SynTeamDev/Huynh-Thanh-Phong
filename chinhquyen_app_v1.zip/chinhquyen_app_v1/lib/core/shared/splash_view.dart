// lib/features/splash/splash_view.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class SplashView extends StatefulWidget {
  const SplashView({super.key});

  @override
  State<SplashView> createState() => _SplashViewState();
}

class _SplashViewState extends State<SplashView>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ac;

  @override
  void initState() {
    super.initState();

    _ac = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 650),
    )..forward();

    // Delay nhẹ rồi điều hướng
    Future.delayed(const Duration(milliseconds: 800), () {
      if (mounted) context.go('/home');
    });
  }

  @override
  void dispose() {
    _ac.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image(
            image: AssetImage('assets/images_v1/splash/splash_e.png'),
            fit: BoxFit.cover,
          ),
        ],
      ),
    );
  }
}
