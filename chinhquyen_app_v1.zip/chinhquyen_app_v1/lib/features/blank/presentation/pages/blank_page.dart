import 'package:chinhquyen_app/core/widgets/custom_appbar_widget.dart';
import 'package:flutter/material.dart';


class BlankPage extends StatelessWidget {
  const BlankPage({super.key, this.title = ''});
  final String title;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBarWidget(title: title),
      body: Center(child: Text("Đang được phát triển!")),
    );
  }
}
