import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:collection/collection.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/shared/menu/menu_model.dart';
import '../../../../core/shared/menu/menu_provider.dart';
import '../../../../core/utils/handle_tel_call.dart';
import '../../../../core/widgets/loading_widget.dart';
import 'guong_sang/local_heroes_card.dart';
import 'shortcut_grid_widget.dart';

class Cstt1Page extends StatelessWidget {
  const Cstt1Page({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff5f6f7),

      body: Stack(
        children: [
          // mảng nền xanh bo tròn phía đáy
          Positioned(
            left: -80,
            right: -80,
            bottom: -140,
            child: Container(
              height: 320,
              decoration: const BoxDecoration(
                color: Color(0xff1aa05b),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(140),
                  topRight: Radius.circular(140),
                ),
              ),
            ),
          ),

          // nội dung
          SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 24),
            child: Column(
              children: [
                LocalHeroesCard(), // 👈 THÊM MỚI (đặt trên)
                const SizedBox(height: 12),
                _SportsFacilitiesCard(),
                SizedBox(height: 12),
                _ReservationServicesCard(),
                SizedBox(height: 12),
                _IndependencePalaceCard(), // NEW
                SizedBox(height: 12),
                _WarMuseumCard(), // NEW
                SizedBox(height: 12),
                _DichVuSoCard(), // NEW
                SizedBox(height: 12),

                _CampingPicnicCard(), // <-- NEW 1
                SizedBox(height: 12),
                _EduSimpleCard(), // <-- NEW 2
                SizedBox(height: 12),

                _WasteServiceCard(), // <--- NEW
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// =======================
/// Card: 예약가능한 체육시설
/// =======================
/// =======================
/// Card: 예약가능한 체육시설 (không có miếng xanh)
/// =======================
class _SportsFacilitiesCard extends ConsumerWidget {
  const _SportsFacilitiesCard({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final menuAsync = ref.watch(menuUserProvider('vi'));

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 12,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: menuAsync.when(
        loading: () =>
            const Padding(padding: EdgeInsets.all(16), child: LoadingWidget()),
        error: (e, _) => Padding(
          padding: const EdgeInsets.all(16),
          child: Text('Không tải được menu: $e'),
        ),
        data: (all) {
          // gom nhóm theo groupNameVi và lấy nhóm "Công dân số"
          final grouped = groupBy(all, (m) => m.groupNameVi.trim());
          final congDanSo = (grouped['Công dân số'] ?? <MenuModel>[]);
          final citizenTopItems = congDanSo.take(8).toList();

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // --- header: giảm khoảng cách dưới & làm nút gọn ---
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  16,
                  12,
                  12,
                  0,
                ), // ↓ bỏ khoảng trống dưới
                child: Row(
                  children: [
                    const Text(
                      'Chức năng công dân số',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const Spacer(),
                    TextButton.icon(
                      onPressed: () => context.push('/khampha'),
                      icon: const Icon(
                        Icons.apps_outlined,
                        size: 16,
                        color: Color(0xFF2563EB),
                      ),
                      label: const Text(
                        'Khám phá',
                        style: TextStyle(
                          color: Color(0xFF2563EB),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 0,
                        ),
                        minimumSize: Size.zero,
                        tapTargetSize:
                            MaterialTapTargetSize.shrinkWrap, // 👈 nút thấp lại
                        visualDensity: const VisualDensity(
                          horizontal: -4,
                          vertical: -4,
                        ),
                        shape: const StadiumBorder(),
                      ),
                    ),
                  ],
                ),
              ),
              // grid menu API (tối đa 11 item)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 16),
                child: CitizenShortcutGrid(items: citizenTopItems),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// =======================
/// Card: Dịch vụ đặt chỗ (bảng 2×2)
/// =======================
/// =======================
/// Card: 예약 서비스 (bảng 2×2) – không có miếng xanh
/// =======================
class _ReservationServicesCard extends StatelessWidget {
  const _ReservationServicesCard({super.key});

  @override
  Widget build(BuildContext context) {
    // Danh sách dịch vụ + icon + handler
    final items = <_ServiceItem>[
      _ServiceItem(
        title: 'Đặt phòng khách sạn',
        icon: Icons.hotel,
        backgroundPath: 'assets/images_v1/dich_vu/dat_khach_san.png',
        onTap: () {
          // TODO: điều hướng trang khách sạn
          // context.pushNamed('hotelBooking');
          debugPrint('Tap: Đặt phòng khách sạn');
        },
      ),
      _ServiceItem(
        title: 'Đặt sân bóng đá',
        icon: Icons.sports_soccer,
        backgroundPath: 'assets/images_v1/dich_vu/dat_san_bong.png',
        onTap: () => debugPrint('Tap: Đặt sân bóng đá'),
      ),
      _ServiceItem(
        title: 'Đặt sân Tennis',
        icon: Icons.sports_tennis,
        backgroundPath: 'assets/images_v1/dich_vu/dat_san_tennis.png',
        onTap: () => debugPrint('Tap: Đặt sân Tennis'),
      ),
      _ServiceItem(
        title: 'Đặt sân cầu lông',
        // Không có badminton chính thức, dùng volleyball thay thế nhẹ
        icon: Icons.sports_volleyball,
        backgroundPath: 'assets/images_v1/dich_vu/dat_san_cau_long.png',
        onTap: () => debugPrint('Tap: Đặt sân cầu lông'),
      ),
      _ServiceItem(
        title: 'Đặt sân Pickleball',
        // Pickleball gần tennis → tái dùng biểu tượng tennis
        icon: Icons.sports_tennis,
        backgroundPath: 'assets/images_v1/dich_vu/dat_san_pickleball.png',
        onTap: () => debugPrint('Tap: Đặt sân Pickleball'),
      ),
      _ServiceItem(
        title: 'Đặt nhà hàng, dịch vụ ăn uống',
        icon: Icons.restaurant,
        backgroundPath: 'assets/images_v1/dich_vu/dat_nha_hang.png',
        onTap: () => debugPrint('Tap: Đặt nhà hàng'),
      ),
      _ServiceItem(
        title: 'Đặt villship',
        // Tạm dùng icon villa (có trong Material Icons)
        icon: Icons.villa,
        backgroundPath: 'assets/images_v1/dich_vu/dat_villship.png',
        onTap: () => debugPrint('Tap: Đặt villship'),
      ),
    ];

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 12,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(4, 4, 4, 0),
              child: Text(
                'Dịch vụ đặt chỗ',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
              ),
            ),

            // Danh sách dọc (1 hàng / item)
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (_, i) => _ServiceTile(item: items[i]),
            ),
          ],
        ),
      ),
    );
  }
}

class _ServiceItem {
  final String title;
  final IconData icon;
  final String backgroundPath;
  final VoidCallback onTap;

  const _ServiceItem({
    required this.title,
    required this.icon,
    required this.onTap,
    required this.backgroundPath,
  });
}

class _ServiceTile extends StatelessWidget {
  const _ServiceTile({super.key, required this.item});
  final _ServiceItem item;

  @override
  Widget build(BuildContext context) {
    const double h = 48;
    const double iconBox = 40;

    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: item.onTap,
        borderRadius: BorderRadius.circular(12),
        child: Ink(
          height: h,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFEEF0F3)),
            image: DecorationImage(
              image: AssetImage(item.backgroundPath),
              fit: BoxFit.cover,
              colorFilter: ColorFilter.mode(
                Colors.black.withOpacity(0.05), // lớp phủ nhẹ cho dễ đọc
                BlendMode.darken,
              ),
            ),
          ),
          child: Row(
            children: [
              const SizedBox(width: 6),
              Container(
                width: iconBox,
                height: iconBox,
                decoration: BoxDecoration(
                  color: const Color(0xFFEFF6FF),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Icon(
                  item.icon,
                  size: 20,
                  color: const Color(0xFF2563EB),
                ),
              ),
              Expanded(
                child: Center(
                  child: Text(
                    item.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                      shadows: [
                        Shadow(
                          offset: Offset(0, 1),
                          blurRadius: 2,
                          color: Color(0xFF111827),
                        ),
                      ],
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
              const SizedBox(width: 6),
              const SizedBox(width: iconBox),
              const SizedBox(width: 6),
            ],
          ),
        ),
      ),
    );
  }
}

// ======= Card 1: Vườn Thực Vật Quốc Gia Sejong =======
class _IndependencePalaceCard extends StatelessWidget {
  const _IndependencePalaceCard({super.key});

  @override
  Widget build(BuildContext context) {
    return _ReservationLinkCard(
      imageUrl: 'assets/images_v1/banner_v1_1.jpg',
      title: 'Dinh Độc Lập',
      primaryText: 'Đặt vé tham quan',
      secondaryText: 'Đặt tour hướng dẫn',
    );
  }
}

// ======= Card 2: Lưu Trữ Tổng Thống =======
class _WarMuseumCard extends StatelessWidget {
  const _WarMuseumCard({super.key});

  @override
  Widget build(BuildContext context) {
    return _ReservationLinkCard(
      imageUrl: 'assets/images_v1/baotang_chungtich.jpg',
      title: 'Bảo Tàng Chứng Tích Chiến Tranh',
      primaryText: 'Đặt lịch tham quan',
      secondaryText: 'Đăng ký hướng dẫn viên',
    );
  }
}

/// Thẻ nhỏ tái sử dụng: ảnh/logo bên trái + 2 nút viền bên phải
class _ReservationLinkCard extends StatelessWidget {
  final String imageUrl;
  final String title;
  final String primaryText;
  final String secondaryText;

  const _ReservationLinkCard({
    super.key,
    required this.imageUrl,
    required this.title,
    required this.primaryText,
    required this.secondaryText,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 12,
            offset: Offset(0, 3),
          ),
        ],
      ),
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          // ảnh/logo bên trái
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: SizedBox(
              width: 100,
              height: 64,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.asset(imageUrl, fit: BoxFit.cover),
                  // làm mờ nhẹ để chữ/logo nổi bật (nếu thay bằng asset)
                  Container(color: Colors.white.withOpacity(0.05)),
                ],
              ),
            ),
          ),
          const SizedBox(width: 12),
          // 2 nút bên phải
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 13,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                _OutlinedPill(
                  text: primaryText,
                  color: const Color(0xff6d28d9),
                ),
                const SizedBox(height: 8),
                _OutlinedPill(
                  text: secondaryText,
                  color: const Color(0xff16a34a),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _OutlinedPill extends StatelessWidget {
  final String text;
  final Color color;
  const _OutlinedPill({super.key, required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 38,
      width: double.infinity, // <- nút full-width để có chỗ ellipsis
      child: OutlinedButton(
        onPressed: () {},
        style: OutlinedButton.styleFrom(
          alignment: Alignment.centerLeft, // căn trái nội dung
          side: BorderSide(color: color, width: 1.6),
          foregroundColor: color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 14),
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          minimumSize: const Size.fromHeight(38),
        ),
        child: Row(
          children: [
            Expanded(
              // <- KHẮC PHỤC tràn: Text bị ràng buộc bề ngang
              child: Text(
                text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                softWrap: false,
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
            const SizedBox(width: 8),
            const Icon(Icons.arrow_forward_ios, size: 14),
          ],
        ),
      ),
    );
  }
}

// ======= Card 3: 시설대관 + lưới ảnh =======
class _DichVuSoCard extends ConsumerWidget {
  const _DichVuSoCard({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final menuAsync = ref.watch(menuUserProvider('vi'));

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 12,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: menuAsync.when(
        loading: () =>
            const Padding(padding: EdgeInsets.all(16), child: LoadingWidget()),
        error: (e, _) => Padding(
          padding: const EdgeInsets.all(16),
          child: Text('Không tải được menu: $e'),
        ),
        data: (all) {
          // gom nhóm theo groupNameVi và lấy nhóm "Công dân số"
          final grouped = groupBy(all, (m) => m.groupNameVi.trim());
          final dvSo = (grouped['Dịch vụ số'] ?? <MenuModel>[]);
          final citizenTopItems = dvSo.take(8).toList();

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // --- header: giảm khoảng cách dưới & làm nút gọn ---
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  16,
                  12,
                  12,
                  0,
                ), // ↓ bỏ khoảng trống dưới
                child: Row(
                  children: [
                    const Text(
                      'Dịch vụ số',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const Spacer(),
                    TextButton.icon(
                      onPressed: () => context.push('/khampha'),
                      icon: const Icon(
                        Icons.apps_outlined,
                        size: 16,
                        color: Color(0xFF2563EB),
                      ),
                      label: const Text(
                        'Khám phá',
                        style: TextStyle(
                          color: Color(0xFF2563EB),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 0,
                        ),
                        minimumSize: Size.zero,
                        tapTargetSize:
                            MaterialTapTargetSize.shrinkWrap, // 👈 nút thấp lại
                        visualDensity: const VisualDensity(
                          horizontal: -4,
                          vertical: -4,
                        ),
                        shape: const StadiumBorder(),
                      ),
                    ),
                  ],
                ),
              ),
              // grid menu API (tối đa 11 item)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 16),
                child: CitizenShortcutGrid(items: citizenTopItems),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// =======================
/// Card: 캠핑장 / 바비큐·피크닉
/// =======================
class _CampingPicnicCard extends StatelessWidget {
  const _CampingPicnicCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 12,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            _RichTitle(
              normal: 'Hòa mình vào thiên nhiên tại ',
              bold: 'khu cắm trại',
            ),
            _TwoCols(
              images: [
                ('Cần Giờ – Rừng ngập mặn', 'assets/images_v1/can_gio.jpg'),
                ('Vàm Sát – Cần Giờ', 'assets/images_v1/vam_sat.jpg'),
              ],
            ),
            SizedBox(height: 16),
            _RichTitle(normal: 'Cùng gia đình, bạn bè ', bold: 'BBQ · Picnic'),
            _TwoCols(
              images: [
                (
                  'Bình Quới – Thanh Đa',
                  'assets/images_v1/binh_quoi_thanh_da.jpg',
                ),
                (
                  'Văn Thánh – Bình Thạnh',
                  'assets/images_v1/van_thanh_thanh_da.jpg',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _TwoCols extends StatelessWidget {
  final List<(String, String)> images;
  const _TwoCols({super.key, required this.images});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      itemCount: images.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        // TĂNG CHIỀU CAO Ô: giảm tỉ lệ width/height
        childAspectRatio: 16 / 12, // trước là 16/11 gây thiếu vài px
      ),
      itemBuilder: (_, i) {
        final (title, url) = images[i];
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Ảnh co giãn theo chiều cao còn lại của ô
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.asset(
                  url,
                  fit: BoxFit.cover,
                  filterQuality: FilterQuality.medium,
                ),
              ),
            ),
            const SizedBox(height: 6),
            // Đặt chiều cao cố định cho 1 dòng text để tránh tràn
            SizedBox(
              height: 20,
              child: Center(
                child: Text(
                  title,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _RichTitle extends StatelessWidget {
  final String normal;
  final String bold;
  const _RichTitle({super.key, required this.normal, required this.bold});

  @override
  Widget build(BuildContext context) {
    return Text.rich(
      TextSpan(
        children: [
          TextSpan(
            text: normal,
            style: const TextStyle(fontSize: 14, color: Colors.black87),
          ),
          TextSpan(
            text: bold,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w900,
              color: Colors.green,
            ),
          ),
        ],
      ),
    );
  }
}

/// =======================
/// Card: 알차고 유익한 교육 (list đơn giản)
/// =======================
class _EduSimpleCard extends StatelessWidget {
  const _EduSimpleCard({super.key});

  @override
  Widget build(BuildContext context) {
    final rows = const [
      ('Đăng ký trải nghiệm & hoạt động sau giờ học', 'Nhà Thiếu nhi'),
      ('Học tập suốt đời, cập nhật kỹ năng', 'Giáo dục thường xuyên'),
      ('Cùng tham gia tại khu dân cư', 'TT học tập cộng đồng'),
      ('Giáo dục gắn với văn hóa', 'NVH Thanh niên'),
      ('Khóa tin học cơ bản miễn phí', 'Tin học công dân'),
    ];

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 12,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text(
              'Chương trình giáo dục bổ ích tại TP.HCM',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
            ),
          ),
          ...rows.map((e) => _EduRow(left: e.$1, right: e.$2)).toList(),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}

class _EduRow extends StatelessWidget {
  final String left;
  final String right;
  const _EduRow({super.key, required this.left, required this.right});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Divider(height: 1, thickness: 1, color: Color(0xfff0f2f5)),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
          child: Row(
            crossAxisAlignment:
                CrossAxisAlignment.start, // top-align khi có xuống dòng
            children: [
              // Cột trái: cho phép wrap vô hạn
              Expanded(
                flex: 6,
                child: Text(
                  left,
                  style: const TextStyle(
                    color: Colors.black87,
                    fontSize: 13,
                    height: 1.25, // line-height dễ đọc hơn
                  ),
                  softWrap: true,
                ),
              ),
              const SizedBox(width: 12),
              // Cột phải: cho phép wrap + canh phải
              Expanded(
                flex: 4,
                child: Text(
                  right,
                  textAlign: TextAlign.right,
                  style: const TextStyle(
                    color: Color(0xff22c55e),
                    fontWeight: FontWeight.w800,
                    height: 1.25,
                  ),
                  softWrap: true,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

/// =======================
/// Card: 대형 폐기물/폐가전 (link + call)
/// =======================
class _WasteServiceCard extends StatelessWidget {
  const _WasteServiceCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 12,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          _LinkCallRow(
            left: 'Gọi công an khẩn cấp',
            linkText: '113',
            onLinkTap: () => handleTelCall('113'),
            onCallTap: () => handleTelCall('113'),
          ),
          const Divider(height: 1, thickness: 1, color: Color(0xffeef0f3)),
          _LinkCallRow(
            left: 'Gọi cứu hoả khẩn cấp',
            linkText: '114',
            onLinkTap: () => handleTelCall('114'),
            onCallTap: () => handleTelCall('114'),
          ),
          const Divider(height: 1, thickness: 1, color: Color(0xffeef0f3)),
          _LinkCallRow(
            left: 'Gọi cấp cứu khẩn cấp',
            linkText: '115',
            onLinkTap: () => handleTelCall('115'),
            onCallTap: () => handleTelCall('115'),
          ),

          // --- Link "Gọi cán bộ hỗ trợ" ở góc dưới bên phải ---
          const Divider(height: 1, thickness: 1, color: Color(0xffeef0f3)),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 12, 12),
            child: Row(
              children: [
                const Spacer(),
                InkWell(
                  onTap: () {
                    // Cách 2 (nếu bạn dùng GoRouter):
                    context.push('/hotro');
                  },
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Text(
                        'Gọi cán bộ hỗ trợ',
                        style: TextStyle(
                          color: Color(0xff4b6bfb),
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      SizedBox(width: 6),
                      Icon(
                        Icons.arrow_forward_ios,
                        size: 14,
                        color: Color(0xff4b6bfb),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LinkCallRow extends StatelessWidget {
  final String left;
  final String linkText;
  final VoidCallback? onLinkTap;
  final VoidCallback? onCallTap;

  const _LinkCallRow({
    super.key,
    required this.left,
    required this.linkText,
    this.onLinkTap,
    this.onCallTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 12, 12),
      child: Row(
        children: [
          // tiêu đề bên trái
          Expanded(
            child: Text(
              left,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          // link xanh
          InkWell(
            onTap: onLinkTap,
            child: Text(
              linkText,
              style: const TextStyle(
                color: Color(0xff4b6bfb),
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          const SizedBox(width: 10),
          // nút gọi tròn xanh
          InkWell(
            onTap: onCallTap,
            child: Container(
              width: 32,
              height: 32,
              decoration: const BoxDecoration(
                color: Color(0xff22c55e),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.call, size: 18, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}
