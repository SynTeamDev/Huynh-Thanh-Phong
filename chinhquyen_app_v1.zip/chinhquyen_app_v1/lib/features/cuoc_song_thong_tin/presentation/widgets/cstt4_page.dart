import 'package:flutter/material.dart';

class Cstt4Page extends StatelessWidget {
  const Cstt4Page({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff5f6f7),

      body: Stack(
        children: [
          // mảng nền xanh bo tròn phía đáy
          Positioned(
            left: -80,
            right: -80,
            bottom: -140,
            child: Container(
              height: 320,
              decoration: const BoxDecoration(
                color: Color(0xff1aa05b),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(140),
                  topRight: Radius.circular(140),
                ),
              ),
            ),
          ),

          SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            child: Column(
              children: const [
                _EduSectionCard(), // Card 1 (đang có)
                SizedBox(height: 12),
                _CultureLifeCard(), // Card 2 (mới, tách riêng)
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// =======================
/// Card “알차고 유익한 교육”
/// =======================
class _EduSectionCard extends StatelessWidget {
  const _EduSectionCard({super.key});

  @override
  Widget build(BuildContext context) {
    final rows = const [
      ('Đăng ký trải nghiệm & hoạt động sau giờ học', 'Nhà Thiếu nhi'),
      ('Học tập suốt đời, cập nhật kỹ năng', 'Giáo dục thường xuyên'),
      ('Cùng tham gia tại khu dân cư', 'TT học tập cộng đồng'),
      ('Văn hoá đọc & triển lãm', 'Thư viện KHTH'),
      ('Sân chơi, sự kiện thanh niên', 'NVH Thanh niên'),
    ];

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 12,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text(
              'Giáo dục & văn hoá TP.HCM',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
            ),
          ),

          // List rows
          ...rows.map((e) => _EduRow(left: e.$1, right: e.$2)).toList(),

          const SizedBox(height: 8),

          // Banner minh hoạ
          _EduBanner(),

          const SizedBox(height: 12),

          // Card kêu gọi đóng góp tri thức/tài năng
          _DonateCard(),

          const SizedBox(height: 12),

          // Buttons
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Row(
              children: [
                Expanded(
                  child: _PillButton.filled(
                    label: 'Không gian trải nghiệm giáo dục',
                    icon: Icons.school,
                    color: const Color(0xff22c55e),
                    onPressed: () {},
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _PillButton.outlined(
                    label: 'Bản đồ tài nguyên giáo dục',
                    icon: Icons.map,
                    color: const Color(0xff7c3aed),
                    onPressed: () {},
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PillButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onPressed;
  final bool filled;

  const _PillButton._({
    super.key,
    required this.label,
    required this.icon,
    required this.color,
    required this.onPressed,
    required this.filled,
  });

  factory _PillButton.filled({
    Key? key,
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onPressed,
  }) => _PillButton._(
    key: key,
    label: label,
    icon: icon,
    color: color,
    onPressed: onPressed,
    filled: true,
  );

  factory _PillButton.outlined({
    Key? key,
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onPressed,
  }) => _PillButton._(
    key: key,
    label: label,
    icon: icon,
    color: color,
    onPressed: onPressed,
    filled: false,
  );

  @override
  Widget build(BuildContext context) {
    final bg = filled ? color : Colors.transparent;
    final fg = filled ? Colors.white : color;

    return SizedBox(
      height: 48,
      child: TextButton(
        onPressed: onPressed,
        style: TextButton.styleFrom(
          backgroundColor: bg,
          foregroundColor: fg,
          side: filled ? BorderSide.none : BorderSide(color: color, width: 1.6),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12),
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          minimumSize: const Size(0, 48),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 18),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                label,
                textAlign: TextAlign.center,
                maxLines: 2, // tối đa 2 dòng, không bể
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EduRow extends StatelessWidget {
  final String left;
  final String right;
  const _EduRow({super.key, required this.left, required this.right});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Divider(height: 1, thickness: 1, color: Color(0xfff0f2f5)),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Cột trái — cho phép xuống dòng
              Expanded(
                flex: 6,
                child: Text(
                  left,
                  style: const TextStyle(
                    color: Colors.black87,
                    fontSize: 13,
                    height: 1.25,
                  ),
                  softWrap: true,
                ),
              ),
              const SizedBox(width: 12),
              // Cột phải — wrap + canh phải, tránh tràn
              Expanded(
                flex: 4,
                child: Text(
                  right,
                  textAlign: TextAlign.right,
                  style: const TextStyle(
                    color: Color(0xff22c55e),
                    fontWeight: FontWeight.w800,
                    height: 1.25,
                  ),
                  softWrap: true,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _EduBanner extends StatelessWidget {
  const _EduBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Container(
          height: 120,
          decoration: BoxDecoration(
            border: Border.all(color: const Color(0xffe8eaef)),
          ),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Ảnh asset
              Image.asset(
                'assets/images/banner3.png',
                fit: BoxFit.cover,
                filterQuality: FilterQuality.medium,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DonateCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xff92400e), // nâu cam
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'Chia sẻ tri thức / tài năng cùng cộng đồng!',
                    style: TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'Đóng góp tri thức · tài năng →',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.favorite, color: Colors.redAccent, size: 28),
          ],
        ),
      ),
    );
  }
}

/// =======================
/// Khối “세종에서의 문화생활!”
/// =======================
/// =======================
/// Card “세종에서의 문화생활!” (tách riêng)
/// =======================
class _CultureLifeCard extends StatelessWidget {
  const _CultureLifeCard({super.key});

  final _items = const [
    ('Thư viện KHTH', 'assets/images_v1/t_thuvien.webp'),
    ('Nhà hát Thành phố', 'assets/images_v1/banner_v1_5.jpg'),
    ('NVH Thanh niên', 'assets/images_v1/t_nhavanhoa.webp'),
    ('Bảo tàng Chứng tích', 'assets/images_v1/baotang_chungtich.jpg'),
    ('Bảo tàng Mỹ thuật', 'assets/images_v1/t_baotangmt.jpg'),
    ('Dinh Độc Lập', 'assets/images_v1/banner_v1_1.jpg'),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 10,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text(
              'Văn hoá tại TP.HCM',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
            ),
          ),

          // --- Thay style 2 nút cho đẹp & chuẩn padding
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.calendar_today_outlined, size: 18),
                    label: const Text(
                      'Lịch sự kiện VH',
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 12,
                      ),
                      minimumSize: const Size(0, 44),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      side: const BorderSide(
                        color: Color(0xffe8eaef),
                        width: 1.3,
                      ),
                      foregroundColor: const Color(0xff7c3aed),
                      backgroundColor: Colors.white,
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.map_outlined, size: 18),
                    label: const Text(
                      'Bản đồ sự kiện',
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 12,
                      ),
                      minimumSize: const Size(0, 44),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      side: const BorderSide(
                        color: Color(0xffe8eaef),
                        width: 1.3,
                      ),
                      foregroundColor: const Color(0xff7c3aed),
                      backgroundColor: Colors.white,
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Subtitle
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: Text(
              'Văn hoá Sài Gòn',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
            ),
          ),

          // Grid 3 x 2
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: GridView.builder(
              itemCount: _items.length,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: .78, // <-- trước là .86
              ),
              itemBuilder: (_, i) {
                final (title, url) = _items[i];
                return _CultureTile(title: title, imageUrl: url);
              },
            ),
          ),

          // Promo banner
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Container(
                height: 84,
                decoration: const BoxDecoration(color: Color(0xfff3e3d2)),
                child: Row(
                  children: const [
                    SizedBox(width: 16),
                    Icon(Icons.music_note, color: Colors.black38),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Cùng vui ở TP.HCM\nSự kiện cộng đồng quanh bạn!',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: Colors.black87,
                          height: 1.2,
                        ),
                      ),
                    ),
                    SizedBox(width: 12),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// --- Thay _CultureTile: cho title 2 dòng + canh giữa + chiều cao cố định gọn gàng
class _CultureTile extends StatelessWidget {
  final String title;
  final String imageUrl;
  const _CultureTile({super.key, required this.title, required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: AspectRatio(
            aspectRatio: 16 / 10,
            child: Image.asset(imageUrl, fit: BoxFit.cover),
          ),
        ),
        const SizedBox(height: 6),
        // Chiều cao ~2 dòng ở cỡ 12pt với height 1.2
        SizedBox(
          height: 32,
          child: Text(
            title,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              height: 1.2,
            ),
          ),
        ),
      ],
    );
  }
}
