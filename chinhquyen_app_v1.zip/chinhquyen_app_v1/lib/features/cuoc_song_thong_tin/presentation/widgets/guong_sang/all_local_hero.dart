// features/local_heroes/all_local_hero.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../../config/env.dart';
import '../../../../../core/widgets/custom_appbar_widget.dart';
import '../../providers/general_provider.dart'; // nơi có tamguongsangListProvider

class AllLocalHeroPage extends ConsumerWidget {
  const AllLocalHeroPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final list = ref.watch(tamguongsangListProvider);
    final notifier = ref.read(tamguongsangListProvider.notifier);

    return Scaffold(
      appBar: const CustomAppBarWidget(title: 'Tất cả gương sáng'),
      backgroundColor: Colors.white,
      body: NotificationListener<ScrollNotification>(
        onNotification: (n) {
          if (n.metrics.pixels >= n.metrics.maxScrollExtent - 200) {
            notifier.fetchTamGuongSangList(); // Lazy load
          }
          return false;
        },
        child: RefreshIndicator(
          onRefresh: () async => notifier.fetchTamGuongSangList(),
          color: const Color(0xFF2563EB),
          child: ListView.separated(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 20),
            separatorBuilder: (_, __) => const SizedBox(height: 16),
            itemCount: list.length,
            itemBuilder: (context, i) {
              final h = list[i];
              return _HeroItem(
                id: h['id'].toString(),
                title: h['tieu_de'] ?? '',
                subtitle: h['mo_ta'] ?? '',
                imageUrl: '${Env.baseUrl}${h['image_url'] ?? ''}',
                hoTen: h['ho_ten'] ?? '',
                diaDiem: h['dia_diem_chip'] ?? '',
              );
            },
          ),
        ),
      ),
    );
  }
}

class _HeroItem extends StatelessWidget {
  const _HeroItem({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.imageUrl,
    required this.hoTen,
    required this.diaDiem,
  });

  final String id;
  final String title;
  final String subtitle;
  final String imageUrl;
  final String hoTen;
  final String diaDiem;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        context.pushNamed(
          'heroDetail',
          pathParameters: {'id': id},
          queryParameters: {'title': title},
        );
      },
      borderRadius: BorderRadius.circular(12),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: const [
            BoxShadow(
              color: Color(0x11000000),
              blurRadius: 4,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Ảnh full width
            ClipRRect(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(12),
                topRight: Radius.circular(12),
              ),
              child: Image.network(
                imageUrl,
                width: double.infinity,
                height: 180,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => Container(
                  height: 180,
                  color: const Color(0xFFF3F4F6),
                  alignment: Alignment.center,
                  child: const Icon(Icons.broken_image_outlined),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // tiêu đề
                  Text(
                    title,
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 15,
                      color: Color(0xFF111827),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 13, color: Colors.black54),
                  ),
                  const SizedBox(height: 8),
                  // Họ tên + địa điểm
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          hoTen,
                          style: const TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF2563EB),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Icon(
                        Icons.location_on,
                        size: 13,
                        color: Color(0xFF6B7280),
                      ),
                      const SizedBox(width: 2),
                      Flexible(
                        child: Text(
                          diaDiem,
                          style: const TextStyle(
                            fontSize: 12,
                            color: Color(0xFF6B7280),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
