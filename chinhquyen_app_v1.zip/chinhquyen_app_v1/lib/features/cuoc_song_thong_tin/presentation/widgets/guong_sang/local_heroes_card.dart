import 'package:chinhquyen_app/core/widgets/loading_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../../config/env.dart';
import '../../../models/hero_model.dart';
import '../../providers/general_provider.dart';

class LocalHeroesCard extends ConsumerStatefulWidget {
  const LocalHeroesCard({super.key});

  @override
  ConsumerState<LocalHeroesCard> createState() => _LocalHeroesCardState();
}

class _LocalHeroesCardState extends ConsumerState<LocalHeroesCard> {
  final _scrollCtrl = ScrollController();

  @override
  void initState() {
    super.initState();
    // Lazy-load: khi gần chạm cuối danh sách ngang thì gọi trang tiếp
    _scrollCtrl.addListener(() {
      if (!_scrollCtrl.hasClients) return;
      final pos = _scrollCtrl.position;
      if (pos.pixels >= pos.maxScrollExtent - 200) {
        ref.read(tamguongsangListProvider.notifier).fetchTamGuongSangList();
      }
    });
  }

  @override
  void dispose() {
    _scrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // lấy list JSON từ provider
    final apiList = ref.watch(tamguongsangListProvider);
    // map sang model UI (giữ UI logic cũ)
    final items = apiList.map(HeroModel.fromApi).toList();

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [
          BoxShadow(
            color: Color(0x11000000),
            blurRadius: 16,
            offset: Offset(0, 5),
          ),
        ],
      ),
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ==== HEADER (y hệt bạn, chỉ chống tràn) ====
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    '🌟 Tấm gương sáng địa phương',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF1E3A8A),
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () => context.pushNamed('allLocalHero'),
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 0,
                    ),
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    visualDensity: const VisualDensity(
                      horizontal: -4,
                      vertical: -4,
                    ),
                    foregroundColor: const Color(0xFF2563EB),
                  ),
                  child: const Text(
                    'Xem tất cả',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
          ),

          // ==== DANH SÁCH NGANG (giữ nguyên kích thước/spacing) ====
          if (items.isEmpty)
            // trạng thái load ban đầu
            SizedBox(
              height: 120,
              child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    SizedBox(height: 18, width: 18, child: LoadingWidget()),
                    SizedBox(width: 10),
                    Text('Đang tải gương sáng…'),
                  ],
                ),
              ),
            )
          else
            SizedBox(
              height: 270, // giữ nguyên
              child: ListView.separated(
                controller: _scrollCtrl,
                scrollDirection: Axis.horizontal,
                itemCount: items.length,
                separatorBuilder: (_, __) => const SizedBox(width: 14),
                itemBuilder: (context, i) {
                  final h = items[i];
                  return SizedBox(width: 300, child: _HeroTile(h: h));
                },
              ),
            ),
        ],
      ),
    );
  }
}

class _HeroTile extends StatelessWidget {
  const _HeroTile({required this.h});
  final HeroModel h;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () {
        context.pushNamed(
          'heroDetail',
          pathParameters: {'id': h.id},
          queryParameters: {'title': h.title}, // tuỳ chọn
        );
      },
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: const Color(0xFFF9FAFB),
          boxShadow: const [
            BoxShadow(
              color: Color(0x0C000000),
              blurRadius: 8,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ==== ẢNH + CHIP ====
            ClipRRect(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
              child: Stack(
                children: [
                  // ⬅️ CHỈNH: tăng aspectRatio để GIẢM chiều cao ảnh
                  AspectRatio(
                    aspectRatio:
                        16 / 8, // trước là 16/9 → ảnh cao ~169px; giờ ~150px
                    child: Image.network(
                      '${Env.baseUrl}${h.imageUrl}',
                      fit: BoxFit.contain,
                    ),
                  ),
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [
                            Colors.black.withOpacity(0.4),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 10,
                    bottom: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFF10B981),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.location_on,
                            size: 14,
                            color: Colors.white,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            h.placeChip,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 12.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ==== NỘI DUNG ====
            Padding(
              // ⬅️ CHỈNH: padding gọn lại để tiết kiệm chiều cao
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    h.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 14.5, // ⬅️ hạ 15 → 14.5
                      color: Color(0xFF111827),
                      height: 1.25,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    h.subtitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.black54,
                      fontSize: 12.5, // ⬅️ hạ 13 → 12.5
                      height: 1.35,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton.icon(
                      onPressed: () {
                        context.pushNamed(
                          'heroDetail',
                          pathParameters: {'id': h.id},
                          queryParameters: {'title': h.title}, // tuỳ chọn
                        );
                      },
                      icon: const Icon(
                        Icons.arrow_forward_ios_rounded,
                        size: 13,
                        color: Color(0xFF2563EB),
                      ), // ⬅️ nhỏ 1px
                      label: const Text(
                        'Xem chi tiết',
                        style: TextStyle(
                          color: Color(0xFF2563EB),
                          fontWeight: FontWeight.w700,
                          fontSize: 12.5, // ⬅️ gọn lại
                        ),
                      ),
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 0,
                        ),
                        minimumSize: Size.zero,
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        visualDensity: const VisualDensity(
                          horizontal: -4,
                          vertical: -4,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
