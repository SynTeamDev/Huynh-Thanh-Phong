import 'package:flutter/material.dart';

import '../../../../core/utils/handle_tel_call.dart';

class Cstt5Page extends StatelessWidget {
  const Cstt5Page({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff5f6f7),

      body: Stack(
        children: [
          // mảng nền xanh bo tròn phía đáy
          Positioned(
            left: -80,
            right: -80,
            bottom: -140,
            child: Container(
              height: 320,
              decoration: const BoxDecoration(
                color: Color(0xff1aa05b),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(140),
                  topRight: Radius.circular(140),
                ),
              ),
            ),
          ),
          const _CsttBody(),
        ],
      ),
    );
  }
}

// --- trong _CsttBody: thêm widget mới ---
class _CsttBody extends StatelessWidget {
  const _CsttBody();

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          _FeatureChipsRow(),
          SizedBox(height: 12),
          _CommunitySectionCard(),
          SizedBox(height: 12),
          _CivilServiceCard(), // <--- khối mới
        ],
      ),
    );
  }
}

/// =======================
/// Hàng thẻ tính năng trên
/// =======================
class _FeatureChipsRow extends StatelessWidget {
  const _FeatureChipsRow();

  @override
  Widget build(BuildContext context) {
    final items = <_FeatureItem>[
      _FeatureItem(
        'Xe buýt TP.HCM',
        Icons.directions_bus_filled,
        color: const Color(0xff22c55e),
      ),
      _FeatureItem(
        'Tra cứu tổng hợp',
        Icons.search,
        color: const Color(0xff3b82f6),
      ),
      _FeatureItem(
        'Khu vui chơi',
        Icons.celebration_outlined,
        color: const Color(0xfff59e0b),
      ),
      _FeatureItem(
        'Phản ánh',
        Icons.assignment_outlined,
        color: const Color(0xff8b5cf6),
      ),
    ];

    return SizedBox(
      height: 64,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 2),
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final it = items[i];
          return _FeatureChip(
            indexBadge: (i + 1).toString(),
            label: it.label,
            icon: it.icon,
            color: it.color,
            onTap: it.onTap,
          );
        },
      ),
    );
  }
}

class _FeatureItem {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;
  const _FeatureItem(
    this.label,
    this.icon, {
    this.color = const Color(0xff23c16b),
    this.onTap,
  });
}

class _FeatureChip extends StatelessWidget {
  final String indexBadge;
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;

  const _FeatureChip({
    super.key,
    required this.indexBadge,
    required this.label,
    required this.icon,
    required this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xffe8eaef)),
      ),
      elevation: 1, // bóng nhẹ
      shadowColor: const Color(0x15000000),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap, // truyền callback để điều hướng
        child: ConstrainedBox(
          constraints: const BoxConstraints(minHeight: 44),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Badge số thứ tự
                Container(
                  width: 22,
                  height: 22,
                  alignment: Alignment.center,
                  margin: const EdgeInsets.only(right: 8),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [color, color.withOpacity(.75)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x14000000),
                        blurRadius: 4,
                        offset: Offset(0, 1),
                      ),
                    ],
                  ),
                  child: Text(
                    indexBadge,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                Icon(icon, size: 20, color: color),
                const SizedBox(width: 6),
                // Giới hạn để không tràn ngang
                ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 160),
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// =======================
/// Card “cộng đồng” phía dưới
/// =======================
/// =======================
/// Card “cộng đồng” phía dưới
/// =======================
class _CommunitySectionCard extends StatelessWidget {
  const _CommunitySectionCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 10,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          // Tiêu đề card
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 4),
            child: Row(
              children: [
                Text(
                  'Cộng đồng kết nối',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                ),
              ],
            ),
          ),
          // 3 nút tròn
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: const [
                _CircleAction(icon: Icons.place, label: 'Chia sẻ\nđịa điểm'),
                _CircleAction(
                  icon: Icons.volunteer_activism,
                  label: 'Chia sẻ\nkỹ năng',
                ),
                _CircleAction(icon: Icons.checkroom, label: 'Chia sẻ\nđồ dùng'),
              ],
            ),
          ),
          const Divider(height: 1),
          // Dòng giới thiệu + CTA
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    'Địa điểm nơi hỗ trợ bạn',
                    style: TextStyle(
                      color: Colors.black54,
                      fontSize: 13,
                      height: 1.2,
                    ),
                  ),
                ),
                Text(
                  'Khu phố >',
                  style: TextStyle(
                    color: Colors.green.shade600,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          // Ô cửa hàng
          const Padding(
            padding: EdgeInsets.fromLTRB(12, 0, 12, 16),
            child: _StoreTile(),
          ),
        ],
      ),
    );
  }
}

class _CircleAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;

  const _CircleAction({
    super.key,
    required this.icon,
    required this.label,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(29),
          child: Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              color: const Color(0xfff3f6ff),
              shape: BoxShape.circle,
              border: Border.all(color: const Color(0xffe5e9f2)),
            ),
            child: Icon(icon, size: 28, color: const Color(0xff4b6bfb)),
          ),
        ),
        const SizedBox(height: 8),
        // Cho phép 2 dòng + giữ chiều cao ổn định
        SizedBox(
          width: 92, // rộng hơn 1 chút để chữ dễ xuống dòng
          height: 32, // đủ cho 2 dòng cỡ 12pt (height 1.2)
          child: Text(
            label,
            textAlign: TextAlign.center,
            maxLines: 2,
            softWrap: true,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              height: 1.2,
            ),
          ),
        ),
      ],
    );
  }
}

/// =======================
/// Store tile (ảnh + info)
/// =======================
class _StoreTile extends StatelessWidget {
  const _StoreTile();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xffe8eaef)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Ảnh đại diện (asset)
          ClipRRect(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(14),
              topRight: Radius.circular(14),
            ),
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: Image.asset(
                'assets/images/banner4.png',
                fit: BoxFit.cover,
                filterQuality: FilterQuality.medium,
              ),
            ),
          ),

          // Hàng like / bình luận
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
            child: Row(
              children: const [
                Icon(Icons.thumb_up_alt_outlined, size: 18, color: Colors.black54),
                SizedBox(width: 4),
                Text('1', style: TextStyle(fontSize: 12, color: Colors.black54)),
                SizedBox(width: 12),
                Icon(Icons.mode_comment_outlined, size: 18, color: Colors.black54),
                SizedBox(width: 4),
                Text('0', style: TextStyle(fontSize: 12, color: Colors.black54)),
                Spacer(),
              ],
            ),
          ),

          // Tiêu đề + tag xanh
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 2, 12, 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Expanded(
                  child: Text(
                    'UBND phường Cầu Ông Lãnh – Quận 1',
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 15,
                      height: 1.2,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: const Color(0xff22c55e),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Text(
                    'Dịch vụ công', // hoặc 'Một cửa'
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


/// =======================
/// Khối “생활 속 민원” (theo ảnh)
/// =======================
class _CivilServiceCard extends StatelessWidget {
  const _CivilServiceCard({super.key});

  static const double _leftCardHeight = 120;
  static const double _rightTileHeight = 56;
  static const double _rightGap = 8;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 10,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // header
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Row(
              children: [
                Text(
                  'Dịch vụ công trong đời sống',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                ),
              ],
            ),
          ),

          // vùng trên: card trái + 2 ô phải (cân chiều cao)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Row(
              children: [
                // Card minh hoạ bên trái
                Expanded(
                  flex: 11,
                  child: Container(
                    height: _leftCardHeight,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      gradient: const LinearGradient(
                        colors: [Color(0xffe8f6ff), Color(0xffffffff)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      border: Border.all(color: Color(0xffe8eaef)),
                    ),
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      children: [
                        Container(
                          width: 56,
                          height: 56,
                          decoration: const BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.edit_note,
                            size: 34,
                            color: Color(0xff2f6cf6),
                          ),
                        ),
                        const SizedBox(width: 10),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Cổng góp ý',
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                  height: 1.2,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                'Gửi phản ánh',
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: Color(0xff2f6cf6),
                                  fontWeight: FontWeight.w700,
                                  height: 1.2,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.person, color: Colors.black38),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 12),

                // Cột 2 ô bên phải (2x56 + 8 = 120)
                Expanded(
                  flex: 9,
                  child: Column(
                    children: [
                      // Ô 1022
                      SizedBox(
                        height: _rightTileHeight,
                        child: Container(
                          decoration: BoxDecoration(
                            color: const Color(0xfff7fbff),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: const Color(0xffe8eaef)),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 8,
                          ),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: const [
                                    Text(
                                      'Kết nối hỗ trợ cộng đồng',
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.black54,
                                        height: 1.2,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              InkWell(
                                onTap: () => handleTelCall('1022'),
                                borderRadius: BorderRadius.circular(18),
                                child: Container(
                                  width: 36,
                                  height: 36,
                                  decoration: const BoxDecoration(
                                    color: Color(0xff22c55e),
                                    shape: BoxShape.circle,
                                  ),
                                  child: const Icon(
                                    Icons.call,
                                    color: Colors.white,
                                    size: 18,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: _rightGap),

                      // Ô "Khám phá dịch vụ công"
                      SizedBox(
                        height: _rightTileHeight,
                        child: OutlinedButton(
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: Color(0xffe8eaef)),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                            backgroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 8,
                            ),
                            alignment: Alignment.center,
                          ),
                          onPressed: () {},
                          child: const Text(
                            'Khám phá dịch vụ công',
                            textAlign: TextAlign.center,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: Colors.black87,
                              height: 1.2,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
