import 'package:chinhquyen_app/core/widgets/loading_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../config/env.dart';
import '../../../../../core/utils/date_helper.dart';
import '../../../../../core/widgets/custom_appbar_widget.dart';
import '../../providers/general_provider.dart';

class PolitiDetailLocalHeroes extends ConsumerStatefulWidget {
  const PolitiDetailLocalHeroes({super.key, this.id = '', this.title = ''});
  final String id;
  final String title;

  @override
  ConsumerState<PolitiDetailLocalHeroes> createState() =>
      _PolitiDetailLocalHeroesState();
}

class _PolitiDetailLocalHeroesState
    extends ConsumerState<PolitiDetailLocalHeroes> {
  Future<void> _refresh() async {
    await ref.refresh(chinhtriDetailProvider(widget.id).future);
  }

  @override
  Widget build(BuildContext context) {
    final st = ref.watch(chinhtriDetailProvider(widget.id));

    return Scaffold(
      appBar: CustomAppBarWidget(
        title: widget.title.isNotEmpty ? widget.title : 'Chi tiết',
      ),
      backgroundColor: Colors.white,
      body: st.when(
        loading: () => const _DetailSkeleton(),
        error: (e, _) => Center(child: Text('Lỗi tải dữ liệu: $e')),
        data: (d) => RefreshIndicator(
          onRefresh: _refresh,
          color: const Color(0xFF2563EB),
          child: CustomScrollView(
            physics: const AlwaysScrollableScrollPhysics(), // ⬅️ thêm dòng này
            slivers: [
              // Header
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Chip địa điểm + họ tên
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFF10B981),
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Row(
                              children: [
                                const Icon(
                                  Icons.location_on,
                                  size: 14,
                                  color: Colors.white,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  d.diaDiemChip,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 12.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          Flexible(
                            child: Text(
                              d.hoTen,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF374151),
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 6),
                      // text địa điểm + thời gian đăng (ngang hàng)
                      Row(
                        children: [
                          Text(
                            d.diaDiemChip,
                            style: const TextStyle(
                              fontSize: 12.5,
                              color: Color(0xFF374151),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Icon(
                            Icons.access_time,
                            size: 13,
                            color: Color(0xFF6B7280),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            formatDateTime(d.datetime0), // ⬅️ helper định dạng
                            style: const TextStyle(
                              fontSize: 12,
                              color: Color(0xFF6B7280),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        d.tieuDe,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          height: 1.15,
                          color: Color(0xFF111827),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        d.moTa,
                        style: const TextStyle(
                          height: 1.35,
                          color: Colors.black87,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Ảnh + caption/mô tả  ✅ KHÔNG dùng SliverList.separated
              SliverList(
                delegate: SliverChildBuilderDelegate((context, i) {
                  final it = d.images[i];
                  final t = it.title; // tránh dùng ! trực tiếp
                  final desc = it.desc;

                  return Padding(
                    padding: const EdgeInsets.only(
                      bottom: 16,
                    ), // đóng vai trò "separator"
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _HeroImage(url: _fullUrl(it.url)),

                        if (t != null && t.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: Text(
                              t,
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                                color: Color(0xFF111827),
                              ),
                            ),
                          ),
                        ],

                        if (desc != null && desc.isNotEmpty) ...[
                          const SizedBox(height: 6),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: Text(
                              desc,
                              textAlign: TextAlign.start,
                              style: const TextStyle(
                                height: 1.45,
                                color: Colors.black87,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  );
                }, childCount: d.images.length),
              ),
              const SliverToBoxAdapter(child: SizedBox(height: 16)),
              const SliverToBoxAdapter(child: Text('Nguồn: thanhnien.vn')),
            ],
          ),
        ),
      ),
    );
  }
}

/* ==== helpers ==== */
String _fullUrl(String url) {
  if (url.startsWith('http://') || url.startsWith('https://')) return url;
  return '${Env.baseUrl}$url';
}

/// Ảnh full-width, giữ tỷ lệ gốc, không bị crop "mất gốc"
class _HeroImage extends StatelessWidget {
  const _HeroImage({required this.url});
  final String url;

  @override
  Widget build(BuildContext context) {
    return Image.network(
      url,
      fit: BoxFit.fitWidth, // full chiều ngang
      alignment: Alignment.topCenter, // tránh mất phần đầu ảnh
      width: double.infinity,
      loadingBuilder: (ctx, child, ev) {
        if (ev == null) return child;
        return const SizedBox(height: 220, child: LoadingWidget());
      },
      errorBuilder: (ctx, err, st) => Container(
        width: double.infinity,
        height: 180,
        color: const Color(0xFFF3F4F6),
        alignment: Alignment.center,
        child: const Icon(Icons.broken_image_outlined),
      ),
    );
  }
}

class _DetailSkeleton extends StatelessWidget {
  const _DetailSkeleton();

  @override
  Widget build(BuildContext context) {
    Widget box(double h, {EdgeInsets? m}) => Container(
      height: h,
      margin: m ?? EdgeInsets.zero,
      decoration: BoxDecoration(
        color: const Color(0xFFE5E7EB),
        borderRadius: BorderRadius.circular(10),
      ),
    );

    return ListView(
      children: [
        const SizedBox(height: 12),
        box(16, m: const EdgeInsets.symmetric(horizontal: 16)),
        const SizedBox(height: 8),
        box(28, m: const EdgeInsets.symmetric(horizontal: 16)),
        const SizedBox(height: 8),
        box(80, m: const EdgeInsets.symmetric(horizontal: 16)),
        const SizedBox(height: 12),
        box(220),
        const SizedBox(height: 10),
        box(18, m: const EdgeInsets.symmetric(horizontal: 16)),
        const SizedBox(height: 6),
        box(60, m: const EdgeInsets.symmetric(horizontal: 16)),
      ],
    );
  }
}

/* ===== Model detail gọn ===== */
class TgsImage {
  final String url;
  final String? title; // t_image_urlX
  final String? desc; // m_image_urlX
  const TgsImage({required this.url, this.title, this.desc});
}

class TgsDetail {
  final String id;
  final String hoTen;
  final String diaDiemChip;
  final String tieuDe;
  final String moTa;
  final String datetime0; // ⬅️ thêm
  final List<TgsImage> images;

  const TgsDetail({
    required this.id,
    required this.hoTen,
    required this.diaDiemChip,
    required this.tieuDe,
    required this.moTa,
    required this.datetime0, // ⬅️ thêm
    required this.images,
  });

  factory TgsDetail.fromMap(Map<String, dynamic> m) {
    String _s(dynamic v) => (v ?? '').toString().trim();

    final imgs = <TgsImage>[];
    for (final i in ['', '1', '2']) {
      final u = _s(m['image_url$i']);
      if (u.isEmpty) continue;
      imgs.add(
        TgsImage(
          url: u,
          title: _s(m['t_image_url$i']),
          desc: _s(m['m_image_url$i']),
        ),
      );
    }

    return TgsDetail(
      id: _s(m['id']),
      hoTen: _s(m['ho_ten']),
      diaDiemChip: _s(m['dia_diem_chip']),
      tieuDe: _s(m['tieu_de']),
      moTa: _s(m['mo_ta']),
      datetime0: _s(m['datetime0']), // ⬅️ thêm
      images: imgs,
    );
  }
}

/* ===== Provider detail: tự tìm trong list, nếu chưa có thì load thêm trang ===== */
final chinhtriDetailProvider = FutureProvider.family<TgsDetail, String>((
  ref,
  id,
) async {
  final notifier = ref.read(chinhtriListProvider.notifier);
  final map = await notifier.getById(id);
  if (map == null) {
    throw Exception('Không tìm thấy bản ghi id=$id');
  }
  return TgsDetail.fromMap(map);
});
