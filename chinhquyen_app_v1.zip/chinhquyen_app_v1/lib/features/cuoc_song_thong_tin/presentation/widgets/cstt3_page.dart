import 'package:flutter/material.dart';

class Cstt3Page extends StatelessWidget {
  const Cstt3Page({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff5f6f7),
      body: Stack(
        children: [
          // mảng nền xanh bo tròn phía đáy
          Positioned(
            left: -80,
            right: -80,
            bottom: -140,
            child: Container(
              height: 320,
              decoration: const BoxDecoration(
                color: Color(0xff1aa05b),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(140),
                  topRight: Radius.circular(140),
                ),
              ),
            ),
          ),

          // nội dung
          SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                _BannerPlacesCard(),
                SizedBox(height: 12),

                _TrailHeroBanner(), // Banner 1 (mới)
                SizedBox(height: 12),
                _CampingPicnicCard(), // Banner 2/Card (mới)
                SizedBox(height: 12),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// =======================
/// Banner “세종시 여기저기 관광명소”
class _BannerPlacesCard extends StatelessWidget {
  const _BannerPlacesCard({super.key});

  @override
  Widget build(BuildContext context) {
    // Danh sách gợi ý TP.HCM
    final items = const [
      ('Nhà thờ Đức Bà', 'assets/images_v1/dulich/nha_tho.jpg'),
      ('Bưu điện Trung tâm', 'assets/images_v1/dulich/buudien.jpg'),
      ('Phố đi bộ Nguyễn Huệ', 'assets/images_v1/dulich/nguyenhue.jpg'),
      ('Chợ Bến Thành', 'assets/images_v1/dulich/chobenthanh.webp'),
    ];

    // TÍNH CHIỀU CAO LIST CHO VỪA TILE
    const double tileWidth = 240.0;
    const double aspect = 16 / 9; // ảnh 16:9
    const double textSection = 42.0; // padding + line-height cho tiêu đề
    const double listHeight = 180;

    return Container(
      margin: const EdgeInsets.only(top: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [
          BoxShadow(
            color: Color(0x14000000),
            blurRadius: 14,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Các điểm tham quan nổi bật ở TP.HCM',
              style: TextStyle(fontSize: 13, color: Colors.black54),
            ),
            const SizedBox(height: 4),
            const Text(
              'Gợi ý nơi nên đi',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 12),

            SizedBox(
              height: listHeight, // <-- quan trọng
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: items.length,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (context, i) {
                  final (title, url) = items[i];
                  return _PlaceTile(title: title, imageUrl: url);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlaceTile extends StatelessWidget {
  final String title;
  final String imageUrl;
  const _PlaceTile({super.key, required this.title, required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 240,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xffeef0f3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Ảnh
          ClipRRect(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(14),
              topRight: Radius.circular(14),
            ),
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: Image.asset(imageUrl, fit: BoxFit.cover),
            ),
          ),
          // Tên
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
            child: Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );
  }
}

class _TrailHeroBanner extends StatelessWidget {
  const _TrailHeroBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: SizedBox(
        height: 120,
        width: double.infinity,
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Ảnh nền demo — thay Image.asset nếu có
            Image.asset(
              'assets/images_v1/dulich/nguyenhue2.jpg',
              fit: BoxFit.cover,
            ),
            // chữ
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
              child: Align(
                alignment: Alignment.topLeft,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text(
                      'Thành phố đáng sống',
                      style: TextStyle(color: Colors.white, fontSize: 12),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Tuyến dạo bộ – Nguyễn Huệ',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

//!!!!!!!!
class _CampingPicnicCard extends StatelessWidget {
  const _CampingPicnicCard({super.key});

  @override
  Widget build(BuildContext context) {
    // Kỳ quan & thiên nhiên nổi bật
    final wonders = const <(String, String)>[
      ('Vịnh Hạ Long (Quảng Ninh)', 'assets/images_v1/dulich/b_vinhhalong.jpg'),
      ('Sa Pa – Fansipan (Lào Cai)', 'assets/images_v1/dulich/b_sapa.png'),
      ('Ninh Bình – Tràng An', 'assets/images_v1/dulich/b_ninhbinh.webp'),
      ('Hà Giang – Mã Pì Lèng', 'assets/images_v1/dulich/b_hagiang.jpg'),
    ];

    // Di sản & biển đảo nổi tiếng
    final heritageIslands = const <(String, String)>[
      ('Hội An – Phố cổ', 'assets/images_v1/dulich/b_hoian.jpg'),
      ('Huế – Đại Nội', 'assets/images_v1/dulich/b_huedaihoi.jpg'),
      ('Phú Quốc – Bãi Sao', 'assets/images_v1/dulich/b_baisaophuquoc.webp'),
      ('Đà Nẵng – Bà Nà Hills', 'assets/images_v1/dulich/b_banahills.jpg'),
    ];

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x14000000),
            blurRadius: 12,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // tiêu đề 1 (đổi nội dung)
            const _RichTitle(
              normal: 'Kỳ quan & thiên nhiên ',
              bold: 'nên check-in',
            ),

            _TwoCols(images: wonders),

            const SizedBox(height: 16),

            // tiêu đề 2 (đổi nội dung)
            const _RichTitle(
              normal: 'Di sản văn hóa & ',
              bold: 'biển đảo nổi tiếng',
            ),

            _TwoCols(images: heritageIslands),
          ],
        ),
      ),
    );
  }
}

class _TwoCols extends StatelessWidget {
  final List<(String, String)> images;
  const _TwoCols({super.key, required this.images});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      itemCount: images.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        // đủ chỗ cho ảnh + text (an toàn trên màn nhỏ)
        childAspectRatio: 16 / 12,
      ),
      itemBuilder: (_, i) {
        final (title, url) = images[i];
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.asset(
                  url,
                  fit: BoxFit.cover,
                  filterQuality: FilterQuality.medium,
                ),
              ),
            ),
            const SizedBox(height: 6),
            SizedBox(
              height: 20,
              child: Center(
                child: Text(
                  title,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _RichTitle extends StatelessWidget {
  final String normal;
  final String bold;
  const _RichTitle({super.key, required this.normal, required this.bold});

  @override
  Widget build(BuildContext context) {
    return Text.rich(
      TextSpan(
        children: [
          TextSpan(
            text: normal,
            style: const TextStyle(fontSize: 14, color: Colors.black87),
          ),
          TextSpan(
            text: bold,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w900,
              color: Colors.green,
            ),
          ),
        ],
      ),
    );
  }
}
