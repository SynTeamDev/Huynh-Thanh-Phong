import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:collection/collection.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/shared/menu/menu_model.dart';
import '../../../../core/shared/menu/menu_provider.dart';
import '../../../../core/widgets/loading_widget.dart';
import 'shortcut_grid_widget.dart';
import 'tin_chinh_tri_xh/politi_local_heroes_card.dart';

class Cstt2Page extends StatelessWidget {
  const Cstt2Page({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xfff5f6f7),

      body: Stack(
        children: [
          // mảng nền xanh bo tròn phía đáy
          Positioned(
            left: -80,
            right: -80,
            bottom: -140,
            child: Container(
              height: 320,
              decoration: const BoxDecoration(
                color: Color(0xff1aa05b),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(140),
                  topRight: Radius.circular(140),
                ),
              ),
            ),
          ),
          SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 24),
            child: Column(
              children: [
                PolitiLocalHeroesCard(),
                SizedBox(height: 12),
                _CQSoCard(), // <--- khối mới
                SizedBox(height: 12),
                _SmartCityCard(),
                SizedBox(height: 12),
                _ProDigitalLibraryCard(),
                SizedBox(height: 12),
                _DigitalArchiveCard(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// =======================
/// Card “스마트도시 세종”
/// =======================
class _SmartCityCard extends StatelessWidget {
  const _SmartCityCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 12,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Đô thị thông minh TP.HCM',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            const Text(
              'Đô thị thông minh TP.HCM là gì?',
              style: TextStyle(fontSize: 13, color: Colors.black54),
            ),
            const SizedBox(height: 12),

            // Banner
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.network(
                      'https://images.unsplash.com/photo-1505765050516-f72dcac9c60e?q=80&w=1600&auto=format&fit=crop',
                      fit: BoxFit.cover,
                    ),
                    Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Color(0x00111122), Color(0x80111122)],
                        ),
                      ),
                    ),
                    // RÀNG BUỘC BỀ NGANG: thêm right: 12
                    Positioned(
                      left: 12,
                      right: 12,
                      bottom: 12,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          _TagChip(text: 'TP.HCM'),
                          SizedBox(height: 6),
                          Text(
                            'Trung tâm Điều hành Đô thị Thông minh (IOC)',
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              shadows: [
                                Shadow(blurRadius: 2, color: Colors.black54),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 12),

            // "Bộ não" + link
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Bộ não của đô thị thông minh TP.HCM',
                        style: TextStyle(fontSize: 13, color: Colors.black54),
                      ),
                      SizedBox(height: 2),
                      Text(
                        'Trung tâm Điều hành ĐTTM (IOC)',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                // RÀNG BUỘC LINK + ELLIPSIS
                Flexible(
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: () {
                        // Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ThamQuanIOCPage()));
                        // hoặc: context.push('/tham-quan-ioc');
                      },
                      style: TextButton.styleFrom(
                        padding: EdgeInsets.zero,
                        minimumSize: const Size(0, 0),
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                      child: const Text(
                        'Đăng ký tham quan',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: Color(0xff5b8cff),
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            // Buttons
            Row(
              children: const [
                Expanded(child: _GhostButton(label: 'Thư viện ảnh')),
                SizedBox(width: 10),
                Expanded(child: _GhostButton(label: 'Tin tức báo chí')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _TagChip extends StatelessWidget {
  final String text;
  const _TagChip({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xff22c55e),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w800,
          fontSize: 11,
        ),
      ),
    );
  }
}

class _GhostButton extends StatelessWidget {
  final String label;
  const _GhostButton({super.key, required this.label});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: OutlinedButton(
        onPressed: () {},
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(
            horizontal: 12,
          ), // giảm padding mặc định
          backgroundColor: const Color(0xfff3f4f6),
          side: const BorderSide(color: Color(0xffeceff3)),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          minimumSize: const Size(0, 44), // tránh ép min width gây tràn
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Flexible(
              // ràng buộc độ rộng của text
              child: Text(
                label,
                maxLines: 1,
                softWrap: false,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontWeight: FontWeight.w700,
                  color: Colors.black87,
                ),
              ),
            ),
            const SizedBox(width: 6),
            const Icon(Icons.arrow_forward, size: 18, color: Colors.black54),
          ],
        ),
      ),
    );
  }
}

/// =======================
/// Card “세종생활 더하기 앱”
/// =======================
class _CQSoCard extends ConsumerWidget {
  const _CQSoCard({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final menuAsync = ref.watch(menuUserProvider('vi'));

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 12,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: menuAsync.when(
        loading: () =>
            const Padding(padding: EdgeInsets.all(16), child: LoadingWidget()),
        error: (e, _) => Padding(
          padding: const EdgeInsets.all(16),
          child: Text('Không tải được menu: $e'),
        ),
        data: (all) {
          // gom nhóm theo groupNameVi và lấy nhóm "Công dân số"
          final grouped = groupBy(all, (m) => m.groupNameVi.trim());
          final dvSo = (grouped['Chính quyền số'] ?? <MenuModel>[]);
          final citizenTopItems = dvSo.take(11).toList();

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // --- header: giảm khoảng cách dưới & làm nút gọn ---
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  16,
                  12,
                  12,
                  0,
                ), // ↓ bỏ khoảng trống dưới
                child: Row(
                  children: [
                    const Text(
                      'Chính quyền số',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const Spacer(),
                    TextButton.icon(
                      onPressed: () => context.push('/khampha'),
                      icon: const Icon(
                        Icons.apps_outlined,
                        size: 16,
                        color: Color(0xFF2563EB),
                      ),
                      label: const Text(
                        'Khám phá',
                        style: TextStyle(
                          color: Color(0xFF2563EB),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 0,
                        ),
                        minimumSize: Size.zero,
                        tapTargetSize:
                            MaterialTapTargetSize.shrinkWrap, // 👈 nút thấp lại
                        visualDensity: const VisualDensity(
                          horizontal: -4,
                          vertical: -4,
                        ),
                        shape: const StadiumBorder(),
                      ),
                    ),
                  ],
                ),
              ),
              // grid menu API (tối đa 11 item)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 16),
                child: CitizenShortcutGrid(items: citizenTopItems),
              ),
            ],
          );
        },
      ),
    );
  }
}

//! --- CARD: Thư viện số tài liệu chuyên môn ---
class _ProDigitalLibraryCard extends StatelessWidget {
  const _ProDigitalLibraryCard({super.key});

  static const _primary = Color(0xff1aa05b);

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;

    final topics = const [
      "Quy trình nghiệp vụ",
      "Biểu mẫu chuẩn",
      "Tiêu chuẩn ISO",
      "Quyết định/Quy chế",
      "Hướng dẫn nội bộ",
      "Báo cáo định kỳ",
    ];

    final docs = const [
      _DocItem(
        title: "Quy trình phê duyệt chi phí",
        ext: "PDF",
        size: "2.3 MB",
        updated: "12/10/2025",
      ),
      _DocItem(
        title: "Mẫu đề xuất mua sắm (Form-PO-03)",
        ext: "DOCX",
        size: "98 KB",
        updated: "05/10/2025",
      ),
      _DocItem(
        title: "ISO 9001:2015 - Checklist đánh giá",
        ext: "XLSX",
        size: "156 KB",
        updated: "28/09/2025",
      ),
    ];

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0F000000),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
        border: Border.all(color: const Color(0x11_000000)),
      ),
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: _primary.withOpacity(.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.local_library_rounded,
                  color: _primary,
                  size: 22,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Thư viện số tài liệu chuyên môn",
                      style: text.titleMedium?.copyWith(
                        fontWeight: FontWeight.w700,
                        letterSpacing: .2,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      "Nơi tập trung tài liệu nội bộ: quy trình, biểu mẫu, tiêu chuẩn… có phân quyền truy cập.",
                      style: text.bodySmall?.copyWith(
                        color: Colors.black.withOpacity(.6),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          // Chủ đề nhanh (chips cuộn ngang)
          SizedBox(
            height: 38,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: topics.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                final t = topics[i];
                return InkWell(
                  borderRadius: BorderRadius.circular(20),
                  onTap: () {
                    // TODO: navigate to filtered list by topic "t"
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xfff3f5f7),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xffe8eaee)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.tag_rounded, size: 16),
                        const SizedBox(width: 6),
                        Text(t, style: text.labelMedium),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 12),

          // Danh sách tài liệu mới/cần thiết (3 dòng)
          ...docs.map((d) => _DocRow(item: d)).toList(),

          const SizedBox(height: 8),

          // CTA
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 44,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _primary,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 0,
                    ),
                    onPressed: () {
                      // TODO: mở trang thư viện số
                    },
                    icon: const Icon(Icons.folder_open_rounded),
                    label: const Text("Mở thư viện"),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              SizedBox(
                height: 44,
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    side: BorderSide(color: _primary.withOpacity(.6)),
                    foregroundColor: _primary,
                  ),
                  onPressed: () {
                    // TODO: mở dialog tải lên tài liệu
                  },
                  icon: const Icon(Icons.drive_folder_upload_rounded),
                  label: const Text("Tải lên"),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _DocItem {
  final String title;
  final String ext; // PDF/DOCX/XLSX...
  final String size; // "2.3 MB"
  final String updated; // "dd/MM/yyyy"
  const _DocItem({
    required this.title,
    required this.ext,
    required this.size,
    required this.updated,
  });
}

class _DocRow extends StatelessWidget {
  const _DocRow({super.key, required this.item});
  final _DocItem item;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;

    IconData icon;
    switch (item.ext.toUpperCase()) {
      case "PDF":
        icon = Icons.picture_as_pdf_rounded;
        break;
      case "DOC":
      case "DOCX":
        icon = Icons.description_rounded;
        break;
      case "XLS":
      case "XLSX":
        icon = Icons.grid_on_rounded;
        break;
      case "PPT":
      case "PPTX":
        icon = Icons.slideshow_rounded;
        break;
      default:
        icon = Icons.insert_drive_file_rounded;
    }

    return InkWell(
      onTap: () {
        // TODO: mở chi tiết tài liệu
      },
      borderRadius: BorderRadius.circular(10),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: const Color(0xfff3f5f7),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, size: 20),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                item.title,
                style: text.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(width: 10),
            Text(
              "${item.ext.toUpperCase()} • ${item.size} • ${item.updated}",
              style: text.bodySmall?.copyWith(
                color: Colors.black.withOpacity(.55),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// --- CARD: Kho lưu trữ số ---
class _DigitalArchiveCard extends StatelessWidget {
  const _DigitalArchiveCard({super.key});

  static const _primary = Color(0xff1aa05b);

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;

    final folders = const [
      _FolderItem(name: "Hồ sơ hành chính", count: 128, updated: "20/10/2025"),
      _FolderItem(name: "Công văn đi - đến", count: 93, updated: "18/10/2025"),
      _FolderItem(name: "Hợp đồng & Phụ lục", count: 56, updated: "15/10/2025"),
      _FolderItem(
        name: "Biên bản - Nghị quyết",
        count: 44,
        updated: "05/10/2025",
      ),
    ];

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0F000000),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
        border: Border.all(color: const Color(0x11_000000)),
      ),
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: _primary.withOpacity(.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.cloud_done_rounded,
                  color: _primary,
                  size: 22,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Kho lưu trữ số",
                      style: text.titleMedium?.copyWith(
                        fontWeight: FontWeight.w700,
                        letterSpacing: .2,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      "Lưu trữ hồ sơ, công văn, hợp đồng và dữ liệu nội bộ an toàn — có thể tra cứu, tải về nhanh chóng.",
                      style: text.bodySmall?.copyWith(
                        color: Colors.black.withOpacity(.6),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          // Danh sách thư mục
          Column(children: folders.map((f) => _FolderRow(item: f)).toList()),

          const SizedBox(height: 8),

          // CTA
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 44,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _primary,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 0,
                    ),
                    onPressed: () {
                      // TODO: mở trang Kho lưu trữ
                    },
                    icon: const Icon(Icons.folder_open_rounded),
                    label: const Text("Mở kho lưu trữ"),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              SizedBox(
                height: 44,
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    side: BorderSide(color: _primary.withOpacity(.6)),
                    foregroundColor: _primary,
                  ),
                  onPressed: () {
                    // TODO: mở giao diện tải tài liệu vào kho
                  },
                  icon: const Icon(Icons.cloud_upload_rounded),
                  label: const Text("Tải lên"),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _FolderItem {
  final String name;
  final int count;
  final String updated;
  const _FolderItem({
    required this.name,
    required this.count,
    required this.updated,
  });
}

class _FolderRow extends StatelessWidget {
  const _FolderRow({super.key, required this.item});
  final _FolderItem item;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return InkWell(
      onTap: () {
        // TODO: mở chi tiết thư mục
      },
      borderRadius: BorderRadius.circular(10),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: const Color(0xfff3f5f7),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(
                Icons.folder_rounded,
                size: 20,
                color: Color(0xff1aa05b),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                item.name,
                style: text.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(width: 10),
            Text(
              "${item.count} tài liệu • ${item.updated}",
              style: text.bodySmall?.copyWith(
                color: Colors.black.withOpacity(.55),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
