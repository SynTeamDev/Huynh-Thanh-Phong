import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/shared/menu/menu_model.dart';
import '../../../../core/widgets/custom_snackbar_widget.dart';
import '../../../auth/presentation/providers/profile_provider.dart';

/// Grid 4 cột – mỗi ô cao ~100px (giống layout trong ảnh)
class CitizenShortcutGrid extends ConsumerWidget {
  const CitizenShortcutGrid({super.key, required this.items});
  final List<MenuModel> items;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        crossAxisSpacing: 12,
        mainAxisSpacing: 2,
        mainAxisExtent: 100, // 58 (icon) + 6 + 32 (label) + margin
      ),
      itemBuilder: (_, i) {
        final it = items[i];
        return _CitizenShortcutTile(
          item: it,
          onTap: () {
            if (!it.enabled) {
              showSnack(context, 'Đang được phát triển!');
              return;
            }
            final profile = ref.read(profileProvider).value;
            if (it.requireLogin && profile == null) {
              context.push('/login');
              return;
            }
            it.onTap(context);
          },
        );
      },
    );
  }
}

class _CitizenShortcutTile extends StatelessWidget {
  const _CitizenShortcutTile({
    super.key,
    required this.item,
    required this.onTap,
  });
  final MenuModel item;
  final VoidCallback onTap;

  static const double _iconSize = 58;
  static const double _labelH = 32;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          // 🔷 Icon vuông bo góc + viền xanh nhạt + bóng nhẹ (giống ảnh)
          Container(
            width: _iconSize,
            height: _iconSize,
            decoration: BoxDecoration(
              color: const Color(0xFFF7F9FF),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFE6ECFF), width: 1),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x14000000),
                  blurRadius: 6,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.all(2),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: CachedNetworkImage(
                  imageUrl: item.iconUrl,
                  fit: BoxFit.cover, // icon đầy ô như ảnh mẫu
                  errorWidget: (_, __, ___) => const Icon(
                    Icons.image_not_supported,
                    color: Color(0xFF4B5563),
                  ),
                ),
              ),
            ),
          ),

          const SizedBox(height: 6),

          // 🏷 Nhãn 2 dòng cố định chiều cao để thẳng hàng
          SizedBox(
            height: _labelH,
            width: double.infinity,
            child: Text(
              item.labelVi,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 12,
                height: 1.2,
                color: Colors.black87,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}