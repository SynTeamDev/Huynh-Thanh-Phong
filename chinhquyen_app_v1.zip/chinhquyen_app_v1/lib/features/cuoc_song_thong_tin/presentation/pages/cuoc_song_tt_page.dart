import 'package:flutter/material.dart';

import '../widgets/cstt1_page.dart';
import '../widgets/cstt2_page.dart';
import '../widgets/cstt3_page.dart';
import '../widgets/cstt4_page.dart';
import '../widgets/cstt5_page.dart';

class CuocSongTTPage extends StatefulWidget {
  const CuocSongTTPage({super.key});

  @override
  State<CuocSongTTPage> createState() => _CuocSongTTPageState();
}

class _CuocSongTTPageState extends State<CuocSongTTPage> {
  // Màu & style
  static const Color kGreen = Color(0xFF147A38);
  static const double kChipRadius = 999;

  int _selected = 0; // item đang chọn

  // Gắn mỗi menu vào 1 "trang" (Widget) hiển thị bên dưới
  // trong _CuocSongTTPageState
  late final List<_MenuItem> _items = [
    _MenuItem(
      label: 'Công dân số',
      assetIcon: 'assets/images_v1/vi.png', // ✅ dùng ảnh cờ VN
      content: const Cstt1Page(),
      pinned: true,
    ),

    _MenuItem(label: 'Chính quyền số', content: const Cstt2Page()),
    _MenuItem(label: 'Du lịch', content: const Cstt3Page()),
    _MenuItem(label: 'Giáo dục · Văn hóa', content: const Cstt4Page()),
    _MenuItem(label: 'Trao đổi · Kết nối', content: const Cstt5Page()),
  ];

  void _onSelect(int index) => setState(() => _selected = index);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          SafeArea(
            bottom: false,
            child: _GreenMenuBar(
              items: _items,
              selectedIndex: _selected,
              onSelected: _onSelect, // 👈 chỉ đổi index, không push
            ),
          ),
          const Divider(height: 1),

          // Nội dung bên dưới đổi theo menu: dùng IndexedStack để giữ state từng tab
          Expanded(
            child: IndexedStack(
              index: _selected,
              children: _items.map((e) => e.content).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class _GreenMenuBar extends StatefulWidget {
  const _GreenMenuBar({
    required this.items,
    required this.selectedIndex,
    required this.onSelected,
  });

  final List<_MenuItem> items;
  final int selectedIndex;
  final ValueChanged<int> onSelected;

  @override
  State<_GreenMenuBar> createState() => _GreenMenuBarState();
}

class _GreenMenuBarState extends State<_GreenMenuBar> {
  final _scrollCtrl = ScrollController();

  @override
  void dispose() {
    _scrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pinnedIndex = widget.items.indexWhere((e) => e.pinned);
    final pinnedItem = pinnedIndex >= 0 ? widget.items[pinnedIndex] : null;

    // các item còn lại để cuộn
    final scrollItems = <(int, _MenuItem)>[];
    for (var i = 0; i < widget.items.length; i++) {
      if (i != pinnedIndex) scrollItems.add((i, widget.items[i]));
    }

    return Material(
      color: _CuocSongTTPageState.kGreen,
      child: SizedBox(
        height: 66,
        child: Row(
          children: [
            const SizedBox(width: 10), // padding trái chung
            // pinned: dùng đúng _MenuChip như các item khác + spacing giống hệt
            if (pinnedItem != null) ...[
              _MenuChip(
                label: pinnedItem.label,
                icon: pinnedItem.icon,
                assetIcon: pinnedItem.assetIcon, // ✅
                selected: widget.selectedIndex == pinnedIndex,
                onTap: () => widget.onSelected(pinnedIndex),
              ),
              const SizedBox(width: 6), // khoảng cách giống separator của list
            ],

            // list cuộn các item còn lại
            Expanded(
              child: ListView.separated(
                controller: _scrollCtrl,
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.fromLTRB(
                  10,
                  0,
                  2,
                  0,
                ), // padding phải chung
                itemCount: scrollItems.length,
                separatorBuilder: (_, __) => const SizedBox(width: 6),
                itemBuilder: (context, idx) {
                  final (realIndex, it) = scrollItems[idx];
                  return _MenuChip(
                    label: it.label,
                    icon: it.icon,
                    selected: widget.selectedIndex == realIndex,
                    onTap: () {
                      widget.onSelected(realIndex);
                      // auto-scroll nhẹ để đưa item vào tầm nhìn
                      _scrollCtrl.animateTo(
                        (_scrollCtrl.offset + (idx - 2) * 60).clamp(
                          0.0,
                          _scrollCtrl.position.maxScrollExtent,
                        ),
                        duration: const Duration(milliseconds: 220),
                        curve: Curves.easeOut,
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MenuChip extends StatelessWidget {
  const _MenuChip({
    required this.label,
    required this.selected,
    required this.onTap,
    this.icon,
    this.assetIcon, // ✅ thêm
  });

  final String label;
  final IconData? icon;
  final String? assetIcon; // ✅ thêm
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(_CuocSongTTPageState.kChipRadius);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: AnimatedScale(
        scale: selected ? 1.02 : 1.0,
        duration: const Duration(milliseconds: 150),
        child: InkWell(
          borderRadius: radius,
          onTap: onTap,
          splashColor: Colors.transparent,
          highlightColor: Colors.transparent,
          hoverColor: Colors.transparent,
          overlayColor: const MaterialStatePropertyAll(Colors.transparent),
          splashFactory: NoSplash.splashFactory,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: radius,
              border: Border.all(
                color: selected ? Colors.white : Colors.transparent,
                width: selected ? 1.6 : 1.0,
              ),
            ),
            child: Row(
              children: [
                if (assetIcon != null) ...[
                  // ✅ hiện ảnh cờ Việt Nam
                  ClipRRect(
                    borderRadius: BorderRadius.circular(3),
                    child: Image.asset(
                      assetIcon!,
                      width: 18,
                      height: 18,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(width: 6),
                ] else if (icon != null) ...[
                  Icon(icon, size: 18, color: Colors.white),
                  const SizedBox(width: 6),
                ],
                AnimatedDefaultTextStyle(
                  duration: const Duration(milliseconds: 150),
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: selected ? FontWeight.w800 : FontWeight.w700,
                    fontSize: 15,
                    height: 1.05,
                    letterSpacing: .2,
                  ),
                  child: Text(label),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MenuItem {
  final String label;
  final IconData? icon; // icon Material (tuỳ chọn)
  final String? assetIcon; // ✅ icon từ asset (tuỳ chọn)
  final Widget content;
  final bool pinned;

  const _MenuItem({
    required this.label,
    required this.content,
    this.icon,
    this.assetIcon,
    this.pinned = false,
  });
}
