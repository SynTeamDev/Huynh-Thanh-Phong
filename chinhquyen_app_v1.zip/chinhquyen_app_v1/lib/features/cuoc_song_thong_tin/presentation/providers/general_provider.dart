import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../../../core/network/api_provider.dart';

//! State lấy danh sách
final tamguongsangListProvider =
    StateNotifierProvider<TamGuongSangListNotifier, List<Map<String, dynamic>>>(
      (ref) => TamGuongSangListNotifier(ref),
    );

//! Api lazy loading
class TamGuongSangListNotifier
    extends StateNotifier<List<Map<String, dynamic>>> {
  TamGuongSangListNotifier(this.ref) : super([]) {
    fetchTamGuongSangList();
  }

  final Ref ref;
  int _pageIndex = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  Future<void> fetchTamGuongSangList() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;

    final result = await ref
        .read(apiServiceProvider)
        .fetchDmTamGuongSang(type: 1, pageIndex: _pageIndex);

    if (result.isEmpty) {
      _hasMore = false;
    } else {
      state = [...state, ...result];
      _pageIndex++;
    }

    _isLoading = false;
  }

  Map<String, dynamic>? _findLocalById(String id) {
    try {
      return state.firstWhere((e) => (e['id'] ?? '').toString() == id);
    } catch (_) {
      return null;
    }
  }

  /// Tìm item theo id. Nếu chưa có trong state, tự load thêm trang đến khi thấy hoặc hết dữ liệu.
  Future<Map<String, dynamic>?> getById(String id) async {
    // 1) thử trong state hiện tại
    final hit = _findLocalById(id);
    if (hit != null) return hit;

    // 2) load thêm cho tới khi thấy hoặc hết dữ liệu
    while (_hasMore) {
      await fetchTamGuongSangList();
      final found = _findLocalById(id);
      if (found != null) return found;
    }
    return null; // không tìm thấy
  }
}

//TODO: làm tin chính trị fetchDmTamGuongSang(type: 2, pageIndex: _pageIndex);

//! State lấy danh sách
final chinhtriListProvider =
    StateNotifierProvider<ChinhTriListNotifier, List<Map<String, dynamic>>>(
      (ref) => ChinhTriListNotifier(ref),
    );

//! Api lazy loading
class ChinhTriListNotifier extends StateNotifier<List<Map<String, dynamic>>> {
  ChinhTriListNotifier(this.ref) : super([]) {
    fetchChinhTriList();
  }

  final Ref ref;
  int _pageIndex = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  Future<void> fetchChinhTriList() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;

    final result = await ref
        .read(apiServiceProvider)
        .fetchDmTamGuongSang(type: 2, pageIndex: _pageIndex);

    if (result.isEmpty) {
      _hasMore = false;
    } else {
      state = [...state, ...result];
      _pageIndex++;
    }

    _isLoading = false;
  }

  Map<String, dynamic>? _findLocalById(String id) {
    try {
      return state.firstWhere((e) => (e['id'] ?? '').toString() == id);
    } catch (_) {
      return null;
    }
  }

  /// Tìm item theo id. Nếu chưa có trong state, tự load thêm trang đến khi thấy hoặc hết dữ liệu.
  Future<Map<String, dynamic>?> getById(String id) async {
    // 1) thử trong state hiện tại
    final hit = _findLocalById(id);
    if (hit != null) return hit;

    // 2) load thêm cho tới khi thấy hoặc hết dữ liệu
    while (_hasMore) {
      await fetchChinhTriList();
      final found = _findLocalById(id);
      if (found != null) return found;
    }
    return null; // không tìm thấy
  }
}
