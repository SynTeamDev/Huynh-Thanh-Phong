// =================== MODEL (giữ nguyên + thêm fromApi) ===================
class HeroModel {
  final String id; // ⬅️ thêm
  final String name;
  final String placeChip;
  final String title;
  final String subtitle;
  final String imageUrl;

  const HeroModel({
    required this.id, // ⬅️ thêm
    required this.name,
    required this.placeChip,
    required this.title,
    required this.subtitle,
    required this.imageUrl,
  });

  factory HeroModel.fromApi(Map<String, dynamic> m) {
    final id = (m['id'] ?? '').toString();
    final img = (m['image_url'] as String?)?.trim() ?? '';
    return HeroModel(
      id: id, // ⬅️ thêm
      name: (m['ho_ten'] ?? '').toString(),
      placeChip: (m['dia_diem_chip'] ?? '').toString(),
      title: (m['tieu_de'] ?? '').toString(),
      subtitle: (m['mo_ta'] ?? '').toString(),
      imageUrl: img,
    );
  }
}
