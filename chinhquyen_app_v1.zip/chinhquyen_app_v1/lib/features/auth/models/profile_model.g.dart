// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'profile_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ProfileModelImpl _$$ProfileModelImplFromJson(Map<String, dynamic> json) =>
    _$ProfileModelImpl(
      user_id: (json['user_id'] as num?)?.toInt(),
      username: json['username'] as String?,
      nickname: json['nickname'] as String?,
      e_mail: json['e_mail'] as String?,
      phone: json['phone'] as String?,
      admin: (json['admin'] as num?)?.toInt(),
      ma_pb: json['ma_pb'] as String?,
      ma_bp: json['ma_bp'] as String?,
    );

Map<String, dynamic> _$$ProfileModelImplToJson(_$ProfileModelImpl instance) =>
    <String, dynamic>{
      'user_id': instance.user_id,
      'username': instance.username,
      'nickname': instance.nickname,
      'e_mail': instance.e_mail,
      'phone': instance.phone,
      'admin': instance.admin,
      'ma_pb': instance.ma_pb,
      'ma_bp': instance.ma_bp,
    };
