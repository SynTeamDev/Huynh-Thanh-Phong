// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'profile_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
  'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models',
);

ProfileModel _$ProfileModelFromJson(Map<String, dynamic> json) {
  return _ProfileModel.fromJson(json);
}

/// @nodoc
mixin _$ProfileModel {
  int? get user_id => throw _privateConstructorUsedError;
  String? get username => throw _privateConstructorUsedError;
  String? get nickname => throw _privateConstructorUsedError;
  String? get e_mail => throw _privateConstructorUsedError;
  String? get phone => throw _privateConstructorUsedError;
  int? get admin => throw _privateConstructorUsedError;
  String? get ma_pb => throw _privateConstructorUsedError;
  String? get ma_bp => throw _privateConstructorUsedError;

  /// Serializes this ProfileModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of ProfileModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $ProfileModelCopyWith<ProfileModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileModelCopyWith<$Res> {
  factory $ProfileModelCopyWith(
    ProfileModel value,
    $Res Function(ProfileModel) then,
  ) = _$ProfileModelCopyWithImpl<$Res, ProfileModel>;
  @useResult
  $Res call({
    int? user_id,
    String? username,
    String? nickname,
    String? e_mail,
    String? phone,
    int? admin,
    String? ma_pb,
    String? ma_bp,
  });
}

/// @nodoc
class _$ProfileModelCopyWithImpl<$Res, $Val extends ProfileModel>
    implements $ProfileModelCopyWith<$Res> {
  _$ProfileModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of ProfileModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? user_id = freezed,
    Object? username = freezed,
    Object? nickname = freezed,
    Object? e_mail = freezed,
    Object? phone = freezed,
    Object? admin = freezed,
    Object? ma_pb = freezed,
    Object? ma_bp = freezed,
  }) {
    return _then(
      _value.copyWith(
            user_id: freezed == user_id
                ? _value.user_id
                : user_id // ignore: cast_nullable_to_non_nullable
                      as int?,
            username: freezed == username
                ? _value.username
                : username // ignore: cast_nullable_to_non_nullable
                      as String?,
            nickname: freezed == nickname
                ? _value.nickname
                : nickname // ignore: cast_nullable_to_non_nullable
                      as String?,
            e_mail: freezed == e_mail
                ? _value.e_mail
                : e_mail // ignore: cast_nullable_to_non_nullable
                      as String?,
            phone: freezed == phone
                ? _value.phone
                : phone // ignore: cast_nullable_to_non_nullable
                      as String?,
            admin: freezed == admin
                ? _value.admin
                : admin // ignore: cast_nullable_to_non_nullable
                      as int?,
            ma_pb: freezed == ma_pb
                ? _value.ma_pb
                : ma_pb // ignore: cast_nullable_to_non_nullable
                      as String?,
            ma_bp: freezed == ma_bp
                ? _value.ma_bp
                : ma_bp // ignore: cast_nullable_to_non_nullable
                      as String?,
          )
          as $Val,
    );
  }
}

/// @nodoc
abstract class _$$ProfileModelImplCopyWith<$Res>
    implements $ProfileModelCopyWith<$Res> {
  factory _$$ProfileModelImplCopyWith(
    _$ProfileModelImpl value,
    $Res Function(_$ProfileModelImpl) then,
  ) = __$$ProfileModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({
    int? user_id,
    String? username,
    String? nickname,
    String? e_mail,
    String? phone,
    int? admin,
    String? ma_pb,
    String? ma_bp,
  });
}

/// @nodoc
class __$$ProfileModelImplCopyWithImpl<$Res>
    extends _$ProfileModelCopyWithImpl<$Res, _$ProfileModelImpl>
    implements _$$ProfileModelImplCopyWith<$Res> {
  __$$ProfileModelImplCopyWithImpl(
    _$ProfileModelImpl _value,
    $Res Function(_$ProfileModelImpl) _then,
  ) : super(_value, _then);

  /// Create a copy of ProfileModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? user_id = freezed,
    Object? username = freezed,
    Object? nickname = freezed,
    Object? e_mail = freezed,
    Object? phone = freezed,
    Object? admin = freezed,
    Object? ma_pb = freezed,
    Object? ma_bp = freezed,
  }) {
    return _then(
      _$ProfileModelImpl(
        user_id: freezed == user_id
            ? _value.user_id
            : user_id // ignore: cast_nullable_to_non_nullable
                  as int?,
        username: freezed == username
            ? _value.username
            : username // ignore: cast_nullable_to_non_nullable
                  as String?,
        nickname: freezed == nickname
            ? _value.nickname
            : nickname // ignore: cast_nullable_to_non_nullable
                  as String?,
        e_mail: freezed == e_mail
            ? _value.e_mail
            : e_mail // ignore: cast_nullable_to_non_nullable
                  as String?,
        phone: freezed == phone
            ? _value.phone
            : phone // ignore: cast_nullable_to_non_nullable
                  as String?,
        admin: freezed == admin
            ? _value.admin
            : admin // ignore: cast_nullable_to_non_nullable
                  as int?,
        ma_pb: freezed == ma_pb
            ? _value.ma_pb
            : ma_pb // ignore: cast_nullable_to_non_nullable
                  as String?,
        ma_bp: freezed == ma_bp
            ? _value.ma_bp
            : ma_bp // ignore: cast_nullable_to_non_nullable
                  as String?,
      ),
    );
  }
}

/// @nodoc
@JsonSerializable()
class _$ProfileModelImpl implements _ProfileModel {
  const _$ProfileModelImpl({
    this.user_id,
    this.username,
    this.nickname,
    this.e_mail,
    this.phone,
    this.admin,
    this.ma_pb,
    this.ma_bp,
  });

  factory _$ProfileModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProfileModelImplFromJson(json);

  @override
  final int? user_id;
  @override
  final String? username;
  @override
  final String? nickname;
  @override
  final String? e_mail;
  @override
  final String? phone;
  @override
  final int? admin;
  @override
  final String? ma_pb;
  @override
  final String? ma_bp;

  @override
  String toString() {
    return 'ProfileModel(user_id: $user_id, username: $username, nickname: $nickname, e_mail: $e_mail, phone: $phone, admin: $admin, ma_pb: $ma_pb, ma_bp: $ma_bp)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProfileModelImpl &&
            (identical(other.user_id, user_id) || other.user_id == user_id) &&
            (identical(other.username, username) ||
                other.username == username) &&
            (identical(other.nickname, nickname) ||
                other.nickname == nickname) &&
            (identical(other.e_mail, e_mail) || other.e_mail == e_mail) &&
            (identical(other.phone, phone) || other.phone == phone) &&
            (identical(other.admin, admin) || other.admin == admin) &&
            (identical(other.ma_pb, ma_pb) || other.ma_pb == ma_pb) &&
            (identical(other.ma_bp, ma_bp) || other.ma_bp == ma_bp));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
    runtimeType,
    user_id,
    username,
    nickname,
    e_mail,
    phone,
    admin,
    ma_pb,
    ma_bp,
  );

  /// Create a copy of ProfileModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$ProfileModelImplCopyWith<_$ProfileModelImpl> get copyWith =>
      __$$ProfileModelImplCopyWithImpl<_$ProfileModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProfileModelImplToJson(this);
  }
}

abstract class _ProfileModel implements ProfileModel {
  const factory _ProfileModel({
    final int? user_id,
    final String? username,
    final String? nickname,
    final String? e_mail,
    final String? phone,
    final int? admin,
    final String? ma_pb,
    final String? ma_bp,
  }) = _$ProfileModelImpl;

  factory _ProfileModel.fromJson(Map<String, dynamic> json) =
      _$ProfileModelImpl.fromJson;

  @override
  int? get user_id;
  @override
  String? get username;
  @override
  String? get nickname;
  @override
  String? get e_mail;
  @override
  String? get phone;
  @override
  int? get admin;
  @override
  String? get ma_pb;
  @override
  String? get ma_bp;

  /// Create a copy of ProfileModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$ProfileModelImplCopyWith<_$ProfileModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
