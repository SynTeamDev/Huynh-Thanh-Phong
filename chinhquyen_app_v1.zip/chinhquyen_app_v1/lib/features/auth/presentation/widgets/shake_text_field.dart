import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../../core/utils/upper_case_helper.dart';

class ShakeTextField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final IconData? icon;
  final bool obscure;
  final Widget? suffixIcon;
  final AnimationController animation;
  final FocusNode focusNode;
  final bool isDate; // 👈 Thêm vào đây
  final TextInputType keyboardType;
  final int? maxLength;
  final List<TextInputFormatter>? inputFormatters;
  final VoidCallback? onSuffixTap;
  final bool toUpperCase;

  const ShakeTextField({
    super.key,
    required this.controller,
    required this.hint,
    this.icon,
    this.obscure = false,
    this.suffixIcon,
    required this.animation,
    required this.focusNode,
    this.isDate = false, // 👈 Default là false
    this.keyboardType = TextInputType.text,
    this.maxLength,
    this.inputFormatters,
    this.onSuffixTap,
    this.toUpperCase = false,
  });

  @override
  Widget build(BuildContext context) {
    final offsetAnimation = TweenSequence([
      TweenSequenceItem(
        tween: Tween(
          begin: 0.0,
          end: -3.0,
        ).chain(CurveTween(curve: Curves.easeOut)),
        weight: 20,
      ),
      TweenSequenceItem(
        tween: Tween(
          begin: -10.0,
          end: 2.0,
        ).chain(CurveTween(curve: Curves.easeInOut)),
        weight: 20,
      ),
      TweenSequenceItem(
        tween: Tween(
          begin: 10.0,
          end: -1.0,
        ).chain(CurveTween(curve: Curves.easeInOut)),
        weight: 20,
      ),
      TweenSequenceItem(
        tween: Tween(
          begin: -10.0,
          end: 0.0,
        ).chain(CurveTween(curve: Curves.easeInOut)),
        weight: 40,
      ),
    ]).animate(animation);

    Widget buildHintText() {
      return AnimatedBuilder(
        animation: animation,
        builder: (context, child) {
          return Transform.translate(
            offset: Offset(0, offsetAnimation.value),
            child: Text(
              hint,
              style: TextStyle(
                color: Colors.black54.withOpacity(0.5),
                fontWeight: FontWeight.bold,
              ),
            ),
          );
        },
      );
    }

    return Theme(
      data: Theme.of(context).copyWith(
        textSelectionTheme: const TextSelectionThemeData(
          cursorColor: Colors.blue,
          selectionColor: Colors.lightBlue,
          selectionHandleColor: Colors.blue,
        ),
      ),
      child: TextField(
        focusNode: focusNode,
        controller: controller,
        obscureText: obscure,
        style: const TextStyle(
          color: Colors.black,
          fontWeight: FontWeight.bold,
        ),
        keyboardType: isDate ? TextInputType.number : keyboardType,
        maxLength: maxLength,
        maxLengthEnforcement: MaxLengthEnforcement.enforced,
        inputFormatters: isDate
            ? [SmartDateInputFormatter()] // 👈 Dùng formatter duy nhất
            : [if (toUpperCase) UpperCaseTextFormatter(), ...?inputFormatters],

        decoration: InputDecoration(
          prefixIcon: icon != null ? Icon(icon, color: Colors.black87) : null,
          suffixIcon:
              suffixIcon ??
              (isDate
                  ? IconButton(
                      icon: const Icon(Icons.calendar_today),
                      onPressed: onSuffixTap,
                    )
                  : null),
          hintText: hint,
          hintStyle: TextStyle(
            color: Colors.black54.withOpacity(0.5),
            fontWeight: FontWeight.bold,
          ),
          filled: true,
          fillColor: Colors.white.withOpacity(0.1),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(color: Colors.black.withOpacity(0.3)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: Colors.black),
          ),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 16,
          ),
          floatingLabelBehavior: FloatingLabelBehavior.never,
          label: buildHintText(),
          counterText: '', // ✅ Thêm dòng này để ẩn "0/30"
        ),
      ),
    );
  }
}

class SmartDateInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    String digits = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    String newText = '';

    if (digits.length >= 1) {
      newText += digits.substring(0, digits.length.clamp(0, 2));
    }
    if (digits.length >= 3) {
      newText += '-' + digits.substring(2, digits.length.clamp(2, 4));
    }
    if (digits.length >= 5) {
      newText += '-' + digits.substring(4, digits.length.clamp(4, 8));
    }

    // Kiểm tra giá trị ngày tháng năm
    final parts = newText.split('-');
    if (parts.length > 0 && parts[0].length == 2) {
      final day = int.tryParse(parts[0]);
      if (day == null || day < 1 || day > 31) return oldValue;
    }

    if (parts.length > 1 && parts[1].length == 2) {
      final month = int.tryParse(parts[1]);
      if (month == null || month < 1 || month > 12) return oldValue;
    }

    if (parts.length > 2 && parts[2].length == 4) {
      final year = int.tryParse(parts[2]);
      if (year == null || year < 1754 || year > 2999) return oldValue;
    }

    return TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: newText.length),
    );
  }
}

class PasswordInputFormatter extends TextInputFormatter {
  final RegExp _allowedChars = RegExp(r'^[\x20-\x7E]+$'); // chỉ ASCII printable

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final filtered = newValue.text.replaceAll(' ', '').split('').where((char) {
      return _allowedChars.hasMatch(char);
    }).join();

    return TextEditingValue(
      text: filtered,
      selection: TextSelection.collapsed(offset: filtered.length),
    );
  }
}
