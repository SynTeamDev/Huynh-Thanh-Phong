import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../../core/network/api_provider.dart';
import '../../../../core/shared/enum.dart';
import '../../models/profile_model.dart';
import 'profile_provider.dart';

final loginProvider = StateNotifierProvider<LoginNotifier, LoginState>((ref) {
  return LoginNotifier(ref);
});

sealed class LoginState {
  const LoginState();
}

class LoginInitial extends LoginState {}

class LoginLoading extends LoginState {}

class LoginSuccess extends LoginState {
  final String username;
  const LoginSuccess(this.username);
}

class LoginFailure extends LoginState {
  final String message;
  const LoginFailure(this.message);
}

class LoginNotifier extends StateNotifier<LoginState> {
  LoginNotifier(this.ref) : super(LoginInitial());
  final Ref ref;

  Future<void> login(
    BuildContext context,
    String username,
    String password,
  ) async {
    state = LoginLoading();

    final api = ref.watch(apiServiceProvider);
    final result = await api.checkLogin(username, password);

    switch (result) {
      case LoginEnum.success:
        //! xử lí lưu profile khi login
        final api = ref.read(apiServiceProvider);
        final profileNotifier = ref.read(profileProvider.notifier);

        final response = await api.getUserInfo(username: username);
        final profile = ProfileModel.fromJson(
          (response.data as List).first as Map<String, dynamic>,
        );
        await profileNotifier.setProfile(profile);

        //! Lưu username sau khi đăng nhập
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('lastUsername', username);

        //! xử lí trả về login thành công
        state = LoginSuccess(username);
        break;
      case LoginEnum.userNotFound:
        state = const LoginFailure("Tài khoản không tồn tại.");
        break;
      case LoginEnum.wrongPassword:
        state = const LoginFailure("Mật khẩu không đúng.");
        break;
      case LoginEnum.error:
      default:
        state = const LoginFailure("Đăng nhập thất bại. Vui lòng thử lại.");
        break;
    }
  }

  void reset() => state = LoginInitial();
}
