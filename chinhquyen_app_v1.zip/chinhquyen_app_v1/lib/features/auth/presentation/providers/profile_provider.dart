import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../models/profile_model.dart';

final profileProvider = AsyncNotifierProvider<ProfileNotifier, ProfileModel?>(
  ProfileNotifier.new,
);

class ProfileNotifier extends AsyncNotifier<ProfileModel?> {
  static const _key = 'user_profile';

  @override
  Future<ProfileModel?> build() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonStr = prefs.getString(_key);
    if (jsonStr == null) return null;

    return ProfileModel.fromJson(json.decode(jsonStr));
  }

  Future<void> setProfile(ProfileModel profile) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, json.encode(profile.toJson()));
    state = AsyncData(profile);
  }

  Future<void> clearProfile() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
    state = const AsyncData(null);
  }
}

int? getUserId(WidgetRef ref) {
  final user = ref.read(profileProvider).value;
  return user?.user_id;
}

int? getUserIdRef(Ref ref) {
  final user = ref.read(profileProvider).value;
  return user?.user_id;
}

String? getUsername(WidgetRef ref) {
  final user = ref.read(profileProvider).value;
  return user?.username;
}

String getUsernameRef(Ref ref) {
  final user = ref.read(profileProvider).value;
  return user?.username ?? '';
}

String getMa_pb(WidgetRef ref) {
  final user = ref.read(profileProvider).value;
  return user!.ma_pb ?? '';
}

String getMa_bp(WidgetRef ref) {
  final user = ref.read(profileProvider).value;
  return user!.ma_bp ?? '';
}
