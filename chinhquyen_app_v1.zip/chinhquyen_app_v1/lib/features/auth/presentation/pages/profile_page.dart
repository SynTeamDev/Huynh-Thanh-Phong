import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/widgets/comfirm_dialog_widget.dart';
import '../../../../core/widgets/row_appbar_widget.dart';
import '../providers/profile_provider.dart';

class ProfilePage extends ConsumerStatefulWidget {
  const ProfilePage({super.key});

  @override
  ConsumerState<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends ConsumerState<ProfilePage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const RowAppbarWidget(text: 'Thông tin cá nhân'),

                // Other Settings
                const Text(
                  'ĐĂNG XUẤT',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    color: Colors.black54,
                  ),
                ),
                const SizedBox(height: 12),
                _buildSettingsSection([
                  _SettingsItem(
                    icon: Icons.logout,
                    label: 'Đăng xuất',
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (_) => ConfirmDialogWidget(
                          title: 'Xác nhận',
                          content: 'Bạn có muốn đăng xuất không?',
                          onConfirm: () async {
                            //! clear profile cục bộ
                            await ref
                                .read(profileProvider.notifier)
                                .clearProfile();
                            //! quay về home
                            context.go('/home');
                          },
                        ),
                      );
                    },
                  ),
                ]),
                const SizedBox(height: 90),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSettingsSection(List<_SettingsItem> items) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ListView.builder(
        shrinkWrap: true,
        physics:
            const NeverScrollableScrollPhysics(), // Disable internal scrolling
        itemCount: items.length,
        itemBuilder: (context, index) {
          final item = items[index];
          return _SettingsListTile(
            icon: item.icon,
            label: item.label,
            onPressed: item.onPressed,
          );
        },
      ),
    );
  }
}

class _SettingsItem {
  final IconData icon;
  final String label;
  final VoidCallback onPressed;
  const _SettingsItem({
    required this.icon,
    required this.label,
    required this.onPressed,
  });
}

class _SettingsListTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onPressed;
  const _SettingsListTile({
    required this.icon,
    required this.label,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onPressed,
      splashColor: Colors.transparent, // 👈 Ẩn hiệu ứng ripple
      highlightColor: Colors.transparent, // 👈 Ẩn hiệu ứng nhấn giữ
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Icon(icon, color: Colors.black54, size: 22),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(fontSize: 16, color: Colors.black87),
              ),
            ),
            const Icon(Icons.chevron_right, color: Colors.black38, size: 20),
          ],
        ),
      ),
    );
  }
}
