import 'package:chinhquyen_app/core/widgets/loading_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:ionicons/ionicons.dart';

import '../../../../core/widgets/custom_snackbar_widget.dart';
import '../../../../core/widgets/row_appbar_widget.dart';
import '../widgets/shake_text_field.dart';
import '../providers/login_provider.dart'; // import file chứa loginProvider

class LoginPage extends ConsumerStatefulWidget {
  const LoginPage({super.key, this.title});
  final String? title;

  @override
  ConsumerState<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends ConsumerState<LoginPage>
    with TickerProviderStateMixin {
  late final TextEditingController _usernameController;
  late final TextEditingController _passwordController;
  late final AnimationController _usernameShakeController;
  late final AnimationController _passwordShakeController;
  late final FocusNode _usernameFocus;
  late final FocusNode _passwordFocus;

  bool _obscurePassword = true;

  @override
  void initState() {
    super.initState();
    _usernameController = TextEditingController();
    _passwordController = TextEditingController();
    _usernameShakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _passwordShakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _usernameFocus = FocusNode();
    _passwordFocus = FocusNode();

    _usernameShakeController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _usernameFocus.requestFocus();
        _usernameShakeController.reset();
      }
    });
    _passwordShakeController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _passwordFocus.requestFocus();
        _passwordShakeController.reset();
      }
    });
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    _usernameShakeController.dispose();
    _passwordShakeController.dispose();
    _usernameFocus.dispose();
    _passwordFocus.dispose();
    super.dispose();
  }

  void _handleLogin() {
    FocusScope.of(context).unfocus();
    final user = _usernameController.text.trim();
    final pass = _passwordController.text.trim();

    bool hasError = false;
    if (user.isEmpty && pass.isEmpty) {
      _usernameShakeController.forward(from: 0);
      hasError = true;
    } else if (user.isNotEmpty && pass.isEmpty) {
      _passwordShakeController.forward(from: 0);
      hasError = true;
    } else if (user.isEmpty && pass.isNotEmpty) {
      _usernameShakeController.forward(from: 0);
      hasError = true;
    }

    if (hasError) return;

    ref.read(loginProvider.notifier).login(context, user, pass);
  }

  @override
  Widget build(BuildContext context) {
    final loginState = ref.watch(loginProvider);

    ref.listen<LoginState>(loginProvider, (prev, next) {
      if (next is LoginSuccess) {
        //! pop về home
        if (Navigator.of(context).canPop()) {
          Navigator.of(context).pop();
        }
      } else if (next is LoginFailure) {
        showSnack(context, next.message);
      }
    });

    return Scaffold(
      resizeToAvoidBottomInset:
          false, //! quan trọng để tránh lỗi khi bàn phím hiện lên
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset('assets/images/login_bg.png', fit: BoxFit.cover),
            Container(color: Colors.black.withOpacity(0.05)),

            SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  children: [
                    const RowAppbarWidget(iconColor: Colors.white),
                    const SizedBox(height: 30),
                    const Text(
                      'GREENGOV - CHÍNH QUYỀN XANH\nPHƯỜNG 3 BẢO LỘC',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        height: 1.2,
                      ),
                    ),
                    const SizedBox(height: 40),

                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.85),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          ShakeTextField(
                            controller: _usernameController,
                            hint: 'Tên đăng nhập',
                            icon: Ionicons.person_outline,
                            obscure: false,
                            animation: _usernameShakeController,
                            focusNode: _usernameFocus,
                            toUpperCase: true,
                          ),
                          const SizedBox(height: 12),
                          ShakeTextField(
                            controller: _passwordController,
                            hint: 'Mật khẩu',
                            icon: Ionicons.lock_closed_outline,
                            obscure: _obscurePassword,
                            animation: _passwordShakeController,
                            focusNode: _passwordFocus,
                            suffixIcon: IconButton(
                              icon: Icon(
                                _obscurePassword
                                    ? Ionicons.eye_off_outline
                                    : Ionicons.eye_outline,
                              ),
                              onPressed: () {
                                setState(() {
                                  _obscurePassword = !_obscurePassword;
                                });
                              },
                            ),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton(
                              onPressed: () => print("Quên mk!"),
                              child: const Text(
                                'Quên mật khẩu?',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.blue,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),

                          //! Nút đăng nhập
                          Row(
                            children: [
                              Expanded(
                                child: Container(
                                  height: 50,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(6),
                                    gradient: const LinearGradient(
                                      colors: [
                                        Colors.lightBlue,
                                        Colors.blueAccent,
                                      ],
                                      begin: Alignment.centerLeft,
                                      end: Alignment.centerRight,
                                    ),
                                  ),
                                  child: Material(
                                    color: Colors.transparent,
                                    borderRadius: BorderRadius.circular(6),
                                    child: InkWell(
                                      onTap: loginState is LoginLoading
                                          ? null
                                          : _handleLogin,
                                      borderRadius: BorderRadius.circular(6),
                                      splashColor: Colors.white.withOpacity(
                                        0.2,
                                      ),
                                      highlightColor: Colors.white.withOpacity(
                                        0.1,
                                      ),
                                      child: Center(
                                        child: loginState is LoginLoading
                                            ? const LoadingWidget()
                                            : const Text(
                                                'Đăng nhập',
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),

                          const SizedBox(height: 12),
                          ElevatedButton.icon(
                            onPressed: () => print("Login with VNeID!"),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red,
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            icon: Image.asset(
                              'assets/icons/logo_vneid.png',
                              height: 28,
                            ),
                            label: const Text(
                              'Đăng nhập bằng tài khoản\nĐịnh danh điện tử',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 14,
                                height: 1.2,
                                color: Colors.white,
                              ),
                            ),
                          ),

                          const SizedBox(height: 12),
                          Center(
                            child: GestureDetector(
                              onTap: () => print("Đăng ký mới!"),
                              child: const Text.rich(
                                TextSpan(
                                  text: 'Bạn chưa có tài khoản? ',
                                  style: TextStyle(color: Colors.black87),
                                  children: [
                                    TextSpan(
                                      text: 'Đăng ký mới',
                                      style: TextStyle(color: Colors.blue),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
