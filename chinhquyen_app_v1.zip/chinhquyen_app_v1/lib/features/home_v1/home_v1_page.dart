import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:ionicons/ionicons.dart';
import 'package:marquee/marquee.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/shared/menu/menu_model.dart';
import '../../core/shared/menu/menu_provider.dart';
import '../../core/widgets/loading_widget.dart';
import '../auth/presentation/providers/profile_provider.dart';

class HomeV1Page extends ConsumerStatefulWidget {
  const HomeV1Page({super.key});
  @override
  ConsumerState<HomeV1Page> createState() => _HomeV1PageState();
}

class _HomeV1PageState extends ConsumerState<HomeV1Page> {
  final _pageCtrl = PageController(viewportFraction: 0.92);
  final _scrollCtrl = ScrollController(); // 👈 thêm controller cho scrollbar
  int _page = 0;

  Timer? _autoTimer;
  bool _userDragging = false; // tạm dừng khi người dùng kéo

  static const _pageCount = 5;

  @override
  void initState() {
    super.initState();

    _autoTimer = Timer.periodic(const Duration(seconds: 7), (_) {
      if (!_pageCtrl.hasClients || _userDragging) return;
      final next = (_page + 1) % _pageCount;
      _pageCtrl.animateToPage(
        next,
        duration: const Duration(milliseconds: 450),
        curve: Curves.easeOut,
      );
    });
  }

  @override
  void dispose() {
    _pageCtrl.dispose();
    _scrollCtrl.dispose(); // đừng quên dispose
    _autoTimer?.cancel();
    super.dispose();
  }

  // Màu chủ đạo giống hình
  static const Color kPrimary = Color(0xFF5A65F4); // tím header
  static const Color kPrimaryDark = Color(0xFF4250E8);
  static const Color kCardBlue = Color(0xFF1F57E5); // xanh thẻ chào
  static const double kRadius = 18;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        bottom: false,
        child: Scrollbar(
          controller: _scrollCtrl, // 👈 gắn vào đây
          thumbVisibility: true, // hiện luôn thanh cuộn
          thickness: 4, // độ dày thanh cuộn
          radius: const Radius.circular(8),
          child: CustomScrollView(
            controller: _scrollCtrl,
            slivers: [
              // GHIM HEADER
              SliverPersistentHeader(
                pinned: true,
                delegate: _PinnedHeader(
                  minExtent: 78,
                  maxExtent: 78,
                  child: _Header(), // dùng header bạn đã có
                ),
              ),
              SliverToBoxAdapter(child: const SizedBox(height: 6)),
              // 👇 Thêm đoạn này
              SliverToBoxAdapter(
                child: Container(
                  height: 32,
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEEF3FF),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Marquee(
                    text:
                        '🌿 Chính quyền xanh - Minh bạch, hiệu quả, gần dân. 🌿',
                    style: const TextStyle(
                      fontSize: 15,
                      color: Color(0xFF1F57E5),
                      fontWeight: FontWeight.w600,
                    ),
                    velocity: 40.0, // tốc độ chạy
                    blankSpace: 80.0, // khoảng cách giữa 2 lần lặp
                    startPadding: 16.0,
                    pauseAfterRound: const Duration(seconds: 1),
                  ),
                ),
              ),

              SliverToBoxAdapter(child: const SizedBox(height: 6)),
              SliverToBoxAdapter(child: _WelcomeCard()),
              SliverToBoxAdapter(child: const SizedBox(height: 14)),
              // Carousel các thẻ trắng
              SliverToBoxAdapter(
                child: SizedBox(
                  height: 150,
                  child: Listener(
                    // pause khi người dùng chạm/kéo
                    onPointerDown: (_) => _userDragging = true,
                    onPointerUp: (_) => _userDragging = false,
                    child: PageView.builder(
                      controller: _pageCtrl,
                      itemCount: _pageCount,
                      onPageChanged: (i) => setState(() => _page = i),
                      itemBuilder: (context, index) => _InfoCard(index: index),
                    ),
                  ),
                ),
              ),

              SliverToBoxAdapter(
                child: Column(
                  children: [
                    const SizedBox(height: 8),
                    _Dots(count: _pageCount, current: _page),
                    const SizedBox(height: 10),
                    // thanh kéo mini như ảnh
                    Container(
                      width: 36,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.black12,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
              SliverToBoxAdapter(child: const _RecentServices()),
              SliverToBoxAdapter(child: const SizedBox(height: 24)),
              SliverToBoxAdapter(child: const _WeatherCard()),
              SliverToBoxAdapter(child: const SizedBox(height: 14)),
              SliverToBoxAdapter(child: const _LifePlusCard()),
              SliverToBoxAdapter(child: const SizedBox(height: 20)),

              //! ====== ======
              SliverToBoxAdapter(child: _AdministrativeProceduresStrip()),
              const SliverToBoxAdapter(child: SizedBox(height: 14)),

              SliverToBoxAdapter(child: _SapabayCard()),
              const SliverToBoxAdapter(child: SizedBox(height: 14)),
              SliverToBoxAdapter(child: _SapabayAppCard()),
              const SliverToBoxAdapter(child: SizedBox(height: 14)),

              // SliverToBoxAdapter(child: _TTHCCard1()),
              // const SliverToBoxAdapter(child: SizedBox(height: 14)),
              // SliverToBoxAdapter(child: _TTHCCard2()),
              // const SliverToBoxAdapter(child: SizedBox(height: 14)),
              // SliverToBoxAdapter(child: _TTHCCard3()),
              // const SliverToBoxAdapter(child: SizedBox(height: 14)),
              // SliverToBoxAdapter(child: _TTHCCard4()),
              // const SliverToBoxAdapter(child: SizedBox(height: 14)),

              // SliverToBoxAdapter(child: ProcedureLookupCard()),
              // const SliverToBoxAdapter(child: SizedBox(height: 14)),
              // SliverToBoxAdapter(child: _AdminCategoryCard()),
              // const SliverToBoxAdapter(child: SizedBox(height: 14)),
              // SliverToBoxAdapter(
              //   child: _OnlineQueueCard(),
              // ), // 👈 Thẻ mới “Lấy số thứ tự Online”
              // const SliverToBoxAdapter(child: SizedBox(height: 14)),
              //! ====== ======
              SliverToBoxAdapter(
                child: OnlineJobsCard(),
              ), // 👈 Thẻ “Chợ việc làm online”
              const SliverToBoxAdapter(child: SizedBox(height: 14)),

              SliverToBoxAdapter(child: _BusCard()),
              const SliverToBoxAdapter(child: SizedBox(height: 14)),

              SliverToBoxAdapter(
                child: const _ThemePlaygroundCard(),
              ), // 👈 THÊM MỚI
              SliverToBoxAdapter(child: const SizedBox(height: 16)),
              SliverToBoxAdapter(child: _BridgeStatsCard()),
              const SliverToBoxAdapter(child: SizedBox(height: 14)),
              SliverToBoxAdapter(child: _BarefootTrailCard()),
              const SliverToBoxAdapter(child: SizedBox(height: 14)),
              SliverToBoxAdapter(child: _CityTourBanner()),
              const SliverToBoxAdapter(child: SizedBox(height: 24)),

              // 👇 THÊM MỚI
              SliverToBoxAdapter(child: _EduBookCard()),
              const SliverToBoxAdapter(child: SizedBox(height: 14)),
              SliverToBoxAdapter(child: _MusicFountainCard()),
              const SliverToBoxAdapter(child: SizedBox(height: 24)),

              SliverToBoxAdapter(child: _OilPriceCard()),
              const SliverToBoxAdapter(child: SizedBox(height: 24)),
              SliverToBoxAdapter(child: _HospitalPharmacyCard()),
              const SliverToBoxAdapter(child: SizedBox(height: 14)),
              SliverToBoxAdapter(child: _MartOpenCard()),
              const SliverToBoxAdapter(child: SizedBox(height: 24)),

              // ... sau _MartOpenCard()
              SliverToBoxAdapter(child: _AppShortcutPager()),
              const SliverToBoxAdapter(child: SizedBox(height: 14)),
              SliverToBoxAdapter(child: _LibraryNoticeCard()),
              const SliverToBoxAdapter(child: SizedBox(height: 16)),
              SliverToBoxAdapter(child: _FooterSection()),
              const SliverToBoxAdapter(child: SizedBox(height: 24)),
            ],
          ),
        ),
      ),
    );
  }
}

/// Header tím: logo bên trái + ô tìm kiếm “giả lập” + 2 icon chuông/người
class _Header extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileAsync = ref.watch(profileProvider);
    final profile = profileAsync.valueOrNull;

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [_HomeV1PageState.kPrimary, _HomeV1PageState.kPrimaryDark],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(22)),
      ),
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
      child: Column(
        children: [
          Row(
            children: [
              // Logo giả
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Text(
                  'GREENGOV',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 18,
                  ),
                ),
              ),
              const Spacer(),
              IconButton(
                onPressed: () {},
                icon: const Icon(Ionicons.search_outline, color: Colors.white),
              ),
              SizedBox(width: 2),
              CircleAvatar(
                radius: 18,
                backgroundImage: AssetImage('assets/icons/notification.png'),
              ),
              SizedBox(width: 6),
              InkWell(
                onTap: () {
                  if (profile == null) {
                    context.push('/login');
                  } else {
                    context.push('/profile');
                  }
                },
                child: const CircleAvatar(
                  radius: 18,
                  backgroundImage: AssetImage(
                    'assets/icons/logo_phuongcauonglanh.png',
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PinnedHeader extends SliverPersistentHeaderDelegate {
  _PinnedHeader({
    required this.minExtent,
    required this.maxExtent,
    required this.child,
  });
  @override
  final double minExtent;
  @override
  final double maxExtent;
  final Widget child;

  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) {
    return Material(
      elevation: overlapsContent ? 2 : 0,
      color: Colors.transparent,
      child: child,
    );
  }

  @override
  bool shouldRebuild(covariant _PinnedHeader oldDelegate) =>
      oldDelegate.minExtent != minExtent ||
      oldDelegate.maxExtent != maxExtent ||
      oldDelegate.child != child;
}

/// Thẻ chào mừng màu xanh
class _WelcomeCard extends ConsumerWidget {
  const _WelcomeCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    //! Login
    final profileAsync = ref.watch(profileProvider);
    final profile = profileAsync.valueOrNull;
    final displayName = (profile?.nickname?.isNotEmpty ?? false)
        ? 'Xin chào, ${profile!.nickname!}'
        : 'Đăng nhập.';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: InkWell(
        onTap: () {
          if (profile == null) {
            context.push('/login');
          } else {
            context.push('/profile');
          }
        },
        child: Container(
          decoration: BoxDecoration(
            color: _HomeV1PageState.kCardBlue,
            borderRadius: BorderRadius.circular(_HomeV1PageState.kRadius),
            boxShadow: [
              BoxShadow(
                color: _HomeV1PageState.kCardBlue.withOpacity(.25),
                blurRadius: 18,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              // Text bên trái
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      displayName,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'Nhiều thông tin đời sống đa dạng! Hãy xem trên GREENGOV nhé~',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 13,
                        height: 1.3,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              // Avatar tròn như ảnh
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: Colors.white10,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white24, width: 1),
                ),
                child: const Icon(
                  Ionicons.person,
                  color: Colors.white,
                  size: 30,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// /// Thẻ trắng bo góc + CTA + hình minh hoạ
// class _InfoCard extends ConsumerWidget {
//   const _InfoCard({required this.index});
//   final int index;
//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     // Data 1→5 đúng thứ tự ảnh banner_v1_1.jpg ... banner_v1_5.jpg
//     const items = [
//       (
//         'Dinh Độc Lập',
//         'Khám phá Dinh Độc Lập – biểu tượng lịch sử Sài Gòn.',
//         'assets/images_v1/banner_v1_1.jpg',
//       ),
//       (
//         'Nhà thờ Đức Bà Sài Gòn',
//         'Chiêm ngưỡng kiến trúc cổ kính giữa lòng thành phố.',
//         'assets/images_v1/banner_v1_2.jpg',
//       ),
//       (
//         'Bưu điện Trung tâm Sài Gòn',
//         'Ghé thăm bưu điện cổ với mái vòm ấn tượng.',
//         'assets/images_v1/banner_v1_3.jpg',
//       ),
//       (
//         'Chợ Bến Thành',
//         'Không khí nhộn nhịp và đặc sản Sài Gòn.',
//         'assets/images_v1/banner_v1_4.jpg',
//       ),
//       (
//         'Nhà hát Thành phố',
//         'Vẻ đẹp kiến trúc Pháp giữa trung tâm quận 1.',
//         'assets/images_v1/banner_v1_5.jpg',
//       ),
//     ];
//     // đảm bảo index an toàn
//     final i = index % items.length;
//     final title = items[i].$1;
//     final desc = items[i].$2;
//     final asset = items[i].$3;
//     return Padding(
//       padding: const EdgeInsets.fromLTRB(
//         8,
//         0,
//         8,
//         4,
//       ), // viewportFraction đã chừa 8px 2 bên
//       child: Container(
//         decoration: BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.circular(_HomeV1PageState.kRadius),
//           boxShadow: const [
//             BoxShadow(
//               color: Color(0x14000000),
//               blurRadius: 18,
//               offset: Offset(0, 8),
//             ),
//           ],
//         ),
//         padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
//         child: Row(
//           children: [
//             // Nội dung văn bản + CTA
//             Expanded(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     title,
//                     overflow: TextOverflow.ellipsis,
//                     maxLines: 2,
//                     style: const TextStyle(
//                       fontWeight: FontWeight.w900,
//                       fontSize: 20,
//                     ),
//                   ),
//                   const SizedBox(height: 8),
//                   Text(
//                     desc,
//                     overflow: TextOverflow.ellipsis,
//                     maxLines: 3,
//                     style: const TextStyle(color: Colors.black54, height: 1.35),
//                   ),
//                   const SizedBox(height: 12),
//                   ElevatedButton.icon(
//                     onPressed: () {},
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: Colors.black,
//                       foregroundColor: Colors.white,
//                       elevation: 0,
//                       padding: const EdgeInsets.symmetric(
//                         horizontal: 14,
//                         vertical: 10,
//                       ),
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(999),
//                       ),
//                     ),
//                     icon: const Icon(Icons.arrow_forward_rounded, size: 18),
//                     label: const Text(
//                       'Khám phá',
//                       style: TextStyle(fontWeight: FontWeight.w700),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             const SizedBox(width: 12),
//             // Hình banner theo index
//             ClipRRect(
//               borderRadius: BorderRadius.circular(12),
//               child: SizedBox(
//                 width: 130,
//                 height: 130,
//                 child: Image.asset(
//                   asset, // ví dụ: images_v1/banner_v1_3.jpg
//                   fit: BoxFit.cover,
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

/// Thẻ trắng bo góc + ảnh nền + text như hình mẫu (chuẩn tỉ lệ)
class _InfoCard extends ConsumerWidget {
  const _InfoCard({required this.index});
  final int index;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    const items = [
      (
        'Dinh Độc Lập',
        'Khám phá Dinh Độc Lập – biểu tượng lịch sử Sài Gòn.',
        'assets/images_v1/banner_v1_1.jpg',
      ),
      (
        'Nhà thờ Đức Bà Sài Gòn',
        'Chiêm ngưỡng kiến trúc cổ kính giữa lòng thành phố.',
        'assets/images_v1/banner_v1_2.jpg',
      ),
      (
        'Bưu điện Trung tâm Sài Gòn',
        'Ghé thăm bưu điện cổ với mái vòm ấn tượng.',
        'assets/images_v1/banner_v1_3.jpg',
      ),
      (
        'Chợ Bến Thành',
        'Không khí nhộn nhịp và đặc sản Sài Gòn.',
        'assets/images_v1/banner_v1_4.jpg',
      ),
      (
        'Nhà hát Thành phố',
        'Vẻ đẹp kiến trúc Pháp giữa trung tâm quận 1.',
        'assets/images_v1/banner_v1_5.jpg',
      ),
    ];

    final i = index % items.length;
    final title = items[i].$1;
    final desc = items[i].$2;
    final asset = items[i].$3;

    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(
              color: Color(0x14000000), // nhẹ, mềm
              blurRadius: 10,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: AspectRatio(
            aspectRatio: 16 / 4.3, // ⚡ chỉnh tỷ lệ giống hình demo
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Ảnh nền
                Image.asset(asset, fit: BoxFit.cover),

                // Lớp gradient từ trái sang phải
                Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                      colors: [
                        Color.fromARGB(87, 0, 0, 0), // đậm bên trái
                        Color.fromARGB(17, 0, 0, 0),
                        Color.fromARGB(0, 0, 0, 0),
                      ],
                    ),
                  ),
                ),

                // Text (desc nhỏ ở trên, title đậm bên dưới)
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 340),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            desc,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w400,
                              fontSize: 15,
                              height: 1.35,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 23,
                              height: 1.1,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Dot indicator như ảnh
class _Dots extends StatelessWidget {
  const _Dots({required this.count, required this.current});
  final int count;
  final int current;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(count, (i) {
        final sel = i == current;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          margin: const EdgeInsets.symmetric(horizontal: 3.5),
          width: sel ? 9 : 7,
          height: sel ? 9 : 7,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: sel ? const Color(0xFF333333) : Colors.black26,
          ),
        );
      }),
    );
  }
}

class _RecentServices extends StatelessWidget {
  const _RecentServices();

  @override
  Widget build(BuildContext context) {
    final items = const [
      _Service(icon: Icons.local_hospital_outlined, label: 'Y tế'),
      _Service(icon: Icons.air_outlined, label: 'Bản đồ thời tiết'),
      _Service(icon: Icons.ev_station_outlined, label: 'Trạm sạc'),
      _Service(icon: Icons.park_outlined, label: 'Công viên'),
      _Service(icon: Icons.directions_bus_outlined, label: 'Xe buýt'),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            'Các dịch vụ được hỗ trợ',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 44, // chiều cao pill
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 4),
            scrollDirection: Axis.horizontal,
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (context, i) => _ServicePill(service: items[i]),
          ),
        ),
      ],
    );
  }
}

class _Service {
  final IconData icon;
  final String label;
  const _Service({required this.icon, required this.label});
}

class _ServicePill extends StatelessWidget {
  const _ServicePill({required this.service});
  final _Service service;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(999),
      elevation: 2,
      shadowColor: Colors.black12,
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: () {
          // TODO: điều hướng theo nhu cầu
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(
            children: [
              Icon(service.icon, size: 18, color: Colors.black87),
              const SizedBox(width: 6),
              Text(
                service.label,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ===== WEATHER CARD =====
class _WeatherCard extends StatefulWidget {
  const _WeatherCard();
  @override
  State<_WeatherCard> createState() => _WeatherCardState();
}

class _WeatherCardState extends State<_WeatherCard> {
  int tab = 0; // 0: theo giờ, 1: theo tuần, 2: bụi mịn

  // Nhiệt độ hiện tại
  final int currentTempC = 31;

  // Tạo giờ 23h..06h (VI)
  final hours = List<String>.generate(
    8,
    (i) => '${((23 + i) % 24).toString().padLeft(2, '0')}h',
  );

  // Nhiệt độ 8 giờ tới dựa trên 31°
  // (có thể chỉnh kế hoạch giảm tăng bên dưới cho phù hợp địa phương)
  final List<int> temps = List<int>.generate(8, (i) {
    const drops = [0, 0, -1, -1, -2, -2, -3, -3]; // 31,31,30,30,29,29,28,28
    return 31 + drops[i];
    // hoặc: return currentTempC + drops[i];
  });

  // Icon thời tiết theo giờ
  final icons = const [
    Icons.wb_sunny, // 23h
    Icons.wb_sunny, // 00h
    Icons.wb_sunny, // 01h
    Icons.cloud, // 02h
    Icons.cloud, // 03h
    Icons.cloud, // 04h
    Icons.cloud, // 05h
    Icons.cloud, // 06h
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(_HomeV1PageState.kRadius),
          boxShadow: const [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 18,
              offset: Offset(0, 8),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header: icon + 26° + mô tả + khu vực
            Row(
              children: [
                const CircleAvatar(
                  radius: 18,
                  backgroundColor: Color(0xFFFFF3C4),
                  child: Icon(Icons.wb_sunny, color: Color(0xFFFFB300)),
                ),
                const SizedBox(width: 10),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '31° Trời quang',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      SizedBox(height: 2),
                      Text(
                        'Mang nước & che nắng khi ra ngoài',
                        style: TextStyle(color: Colors.black54, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                Row(
                  children: const [
                    Text(
                      'Thành phố Hồ Chí Minh',
                      style: TextStyle(fontSize: 12, color: Colors.black87),
                    ),
                    SizedBox(width: 4),
                    Icon(Icons.my_location, size: 16, color: Colors.black45),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Chips
            Row(
              children: [
                _ChipBtn(
                  label: 'Theo giờ',
                  selected: tab == 0,
                  onTap: () => setState(() => tab = 0),
                ),
                const SizedBox(width: 8),
                _ChipOutlined(
                  label: 'Theo tuần',
                  selected: tab == 1,
                  onTap: () => setState(() => tab = 1),
                ),
                const SizedBox(width: 8),
                _ChipOutlined(
                  label: 'Bụi mịn',
                  selected: tab == 2,
                  onTap: () => setState(() => tab = 2),
                ),
              ],
            ),
            const SizedBox(height: 12),

            if (tab == 0)
              _HourlyChart(hours: hours, temps: temps, icons: icons)
            else if (tab == 1)
              const _WeeklyPlaceholder()
            else
              const _PmPlaceholder(),

            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: const [
                  Text(
                    'Tìm hiểu thêm',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                  SizedBox(width: 4),
                  Icon(Icons.chevron_right, size: 18),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ChipBtn extends StatelessWidget {
  const _ChipBtn({
    required this.label,
    required this.selected,
    required this.onTap,
  });
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _HomeV1PageState.kPrimary.withOpacity(0.15),
      borderRadius: BorderRadius.circular(999),
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Text(
            label,
            style: TextStyle(
              color: _HomeV1PageState.kPrimaryDark,
              fontWeight: FontWeight.w800,
              fontSize: 12,
            ),
          ),
        ),
      ),
    );
  }
}

class _ChipOutlined extends StatelessWidget {
  const _ChipOutlined({
    required this.label,
    required this.selected,
    required this.onTap,
  });
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final sel = selected;
    return Material(
      color: sel ? Colors.black.withOpacity(0.04) : Colors.white,
      shape: StadiumBorder(side: BorderSide(color: Colors.black12, width: 1)),
      child: InkWell(
        customBorder: const StadiumBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Text(
            label,
            style: TextStyle(
              color: Colors.black87,
              fontWeight: sel ? FontWeight.w700 : FontWeight.w600,
              fontSize: 12,
            ),
          ),
        ),
      ),
    );
  }
}

class _HourlyChart extends StatelessWidget {
  const _HourlyChart({
    required this.hours,
    required this.temps,
    required this.icons,
  });
  final List<String> hours;
  final List<int> temps;
  final List<IconData> icons;

  @override
  Widget build(BuildContext context) {
    assert(hours.length == temps.length && temps.length == icons.length);

    // helper: chuẩn hoá giờ -> "HHh" & loại bỏ '시' nếu có
    String normalizeHour(String s) {
      if (s.contains('시')) {
        final digits = RegExp(r'\d+').stringMatch(s) ?? '0';
        final hh = int.tryParse(digits) ?? 0;
        return '${hh.toString().padLeft(2, '0')}h';
      }
      return s;
    }

    final minT = temps.reduce((a, b) => a < b ? a : b);
    final maxT = temps.reduce((a, b) => a > b ? a : b);
    final range = (maxT - minT).clamp(1, 100);

    return SizedBox(
      height: 110,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: List.generate(temps.length, (i) {
          final val = temps[i];
          final y = (val - minT) / range; // 0..1
          return Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                SizedBox(
                  height: 45,
                  child: Stack(
                    alignment: Alignment.bottomCenter,
                    children: [
                      Positioned(
                        bottom: y * 36,
                        child: Container(
                          width: 6,
                          height: 6,
                          decoration: const BoxDecoration(
                            color: Color(0xFF3B5BFF),
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(icons[i], size: 18, color: Colors.amber.shade700),
                const SizedBox(height: 6),
                Text(
                  '${temps[i]}',
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  normalizeHour(hours[i]), // <-- luôn hiện "HHh"
                  style: const TextStyle(fontSize: 11, color: Colors.black54),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

class _WeeklyPlaceholder extends StatelessWidget {
  const _WeeklyPlaceholder();
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      alignment: Alignment.center,
      child: const Text(
        'Dự báo theo tuần (Đang phát triển)',
        style: TextStyle(color: Colors.black54),
      ),
    );
  }
}

class _PmPlaceholder extends StatelessWidget {
  const _PmPlaceholder();
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      alignment: Alignment.center,
      child: const Text(
        'Thông tin bụi mịn (Đang phát triển)',
        style: TextStyle(color: Colors.black54),
      ),
    );
  }
}

/// Thẻ “Sống thông minh tại Sejong +”
class _LifePlusCard extends StatelessWidget {
  const _LifePlusCard();

  @override
  Widget build(BuildContext context) {
    final items = const [
      _LifeItem(Icons.event_note, 'Trung tâm đặt chỗ'),
      _LifeItem(Icons.directions_bus, 'Xe buýt thời gian thực'),
      _LifeItem(Icons.masks, 'Không khí quanh đây'),
      _LifeItem(Icons.report_problem, 'Báo cáo bụi mịn'),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF5A65F4), Color(0xFF4250E8)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(_HomeV1PageState.kRadius),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF4250E8).withOpacity(.25),
              blurRadius: 18,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Tiêu đề góc trên
            Row(
              children: const [
                Text(
                  'Cuộc sống ',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(
                  'TP.HCM ',
                  style: TextStyle(
                    color: Colors.yellow,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  'thông minh +',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Spacer(),
                Icon(Icons.circle, size: 8, color: Colors.white70),
              ],
            ),
            const SizedBox(height: 14),

            Row(
              children: [
                for (final e in items) Expanded(child: _LifeIcon(item: e)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _LifeItem {
  final IconData icon;
  final String label;
  const _LifeItem(this.icon, this.label);
}

class _LifeIcon extends StatelessWidget {
  const _LifeIcon({required this.item});
  final _LifeItem item;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 66,
          height: 66,
          decoration: const BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
          ),
          child: Icon(
            item.icon,
            size: 30,
            color: _HomeV1PageState.kPrimaryDark,
          ),
        ),
        const SizedBox(height: 8),
        // label: tối đa 2 dòng, không tràn
        SizedBox(
          width: double.infinity, // bám theo bề rộng Expanded ở trên
          child: Text(
            item.label,
            textAlign: TextAlign.center,
            maxLines: 2,
            softWrap: true,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
              fontSize: 12,
              height: 1.2,
            ),
          ),
        ),
      ],
    );
  }
}

//! dịch vụ Tra cứu thủ tục hành chính
//TODO:
const _dvcUrl = 'https://dichvucong.gov.vn/p/home/dvc-tra-cuu-ho-so.html';
const _url = 'https://dichvucong.gov.vn/p/home/dvc-tthc-category.html';

class ProcedureLookupCard extends StatelessWidget {
  const ProcedureLookupCard({super.key});

  static const Color _grad1 = Color(0xFF5A65F4);
  static const Color _grad2 = Color(0xFF4250E8);
  static const Color ink = Color(0xFF4250E8);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(
              color: Color(0x1A000000),
              blurRadius: 18,
              offset: Offset(0, 8),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Column(
            children: [
              // Header tím + icon
              Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_grad1, _grad2],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
                child: Row(
                  children: [
                    Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(.15),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.fact_check,
                        color: Colors.white,
                        size: 18,
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Expanded(
                      child: Text(
                        'Tra cứu thủ tục hành chính',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 15.5,
                          letterSpacing: .2,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Thân trắng
              Container(
                width: double.infinity,
                color: Colors.white,
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Hai nút cân đối
                    _TwoBalancedButtons(
                      left: _ActionButton.primary(
                        label: 'Đi đến tra cứu',
                        icon: Icons.language,
                        onTap: () {
                          context.push(
                            '/webview?title=${Uri.encodeComponent('Tra cứu thủ tục hành chính')}'
                            '&url=${Uri.encodeComponent(_dvcUrl)}',
                          );
                        },
                      ),
                      right: _ActionButton.outline(
                        label: 'Mở ngoài trình duyệt',
                        icon: Icons.open_in_new,
                        onTap: () async {
                          final uri = Uri.parse(_dvcUrl);
                          await launchUrl(
                            uri,
                            mode: LaunchMode.externalApplication,
                          );
                        },
                      ),
                    ),

                    const SizedBox(height: 12),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Icon(
                          Icons.info_outline,
                          size: 18,
                          color: Colors.black45,
                        ),
                        SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            'Tra cứu hồ sơ & thủ tục trên Cổng Dịch vụ công Quốc gia.',
                            style: TextStyle(
                              color: Colors.black54,
                              fontSize: 12,
                              height: 1.35,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Hai nút “cân đối tương xứng”:
/// - Màn hình rộng: nằm ngang 2 cột bằng nhau
/// - Màn hình hẹp: tự động xuống 2 hàng cho đẹp
class _TwoBalancedButtons extends StatelessWidget {
  const _TwoBalancedButtons({required this.left, required this.right});
  final Widget left;
  final Widget right;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (_, c) {
        final narrow = c.maxWidth < 360;
        if (narrow) {
          return Column(children: [left, const SizedBox(height: 10), right]);
        }
        return Row(
          children: [
            Expanded(child: left),
            const SizedBox(width: 10),
            Expanded(child: right),
          ],
        );
      },
    );
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton._({
    required this.label,
    required this.icon,
    required this.onTap,
    required this.filled,
  });

  factory _ActionButton.primary({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
  }) => _ActionButton._(label: label, icon: icon, onTap: onTap, filled: true);

  factory _ActionButton.outline({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
  }) => _ActionButton._(label: label, icon: icon, onTap: onTap, filled: false);

  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final bool filled;

  @override
  Widget build(BuildContext context) {
    const borderClr = Color(0xFFE6E8FF);
    const ink = Color(0xFF4250E8);

    final Widget content = Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, size: 18, color: ink),
        const SizedBox(width: 8),
        Flexible(
          child: Text(
            label,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: ink,
              fontSize: 13.5,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    );

    // Primary: nền nhẹ; Outline: nền trắng + viền
    final BoxDecoration deco = BoxDecoration(
      color: filled ? const Color(0xFFF1F3FF) : Colors.white,
      borderRadius: BorderRadius.circular(24),
      border: filled ? null : Border.all(color: borderClr),
      boxShadow: filled
          ? [
              const BoxShadow(
                color: Color(0x0D4250E8),
                blurRadius: 8,
                offset: Offset(0, 3),
              ),
            ]
          : const [],
    );

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: onTap,
        child: Container(
          height: 46,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: deco,
          alignment: Alignment.center,
          child: content,
        ),
      ),
    );
  }
}

class _AdminCategoryCard extends StatelessWidget {
  const _AdminCategoryCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 18,
              offset: Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          children: [
            // Header tím (giống style cũ)
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF5A65F4), Color(0xFF4250E8)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(18),
                  topRight: Radius.circular(18),
                ),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: const [
                  Icon(Icons.menu_book_rounded, color: Colors.white, size: 20),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Danh mục thủ tục hành chính',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 15,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Thân trắng có 1 nút
            Container(
              width: double.infinity,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(18),
                  bottomRight: Radius.circular(18),
                ),
              ),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  _RoundedButton(
                    label: 'Xem danh mục trên Cổng DVC Quốc gia',
                    icon: Icons.open_in_new_rounded,
                    onTap: () async {
                      // final uri = Uri.parse(_url);
                      // await launchUrl(uri, mode: LaunchMode.externalApplication);

                      context.push(
                        '/webview?title=${Uri.encodeComponent('Cổng DVC Quốc gia')}'
                        '&url=${Uri.encodeComponent(_url)}',
                      );
                    },
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'Danh mục thủ tục hành chính toàn quốc được công bố '
                    'trên Cổng Dịch vụ công Quốc gia.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.black54,
                      fontSize: 12.5,
                      height: 1.35,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OnlineQueueCard extends StatelessWidget {
  const _OnlineQueueCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 18,
              offset: Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          children: [
            // Header tím gradient
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF5A65F4), Color(0xFF4250E8)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(18),
                  topRight: Radius.circular(18),
                ),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: const [
                  Icon(
                    Icons.confirmation_number_rounded,
                    color: Colors.white,
                    size: 20,
                  ),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Lấy số thứ tự Online',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 15,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Thân trắng
            Container(
              width: double.infinity,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(18),
                  bottomRight: Radius.circular(18),
                ),
              ),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  _RoundedButton(
                    label: 'Đăng ký & lấy số thứ tự trực tuyến',
                    icon: Icons.open_in_new_rounded,
                    onTap: () async {
                      //TODO: thêm link khi có
                      context.push(
                        '/screen/00.13.02?title=${Uri.encodeComponent('Lấy số thứ tự HCC')}',
                      );
                    },
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'Đăng ký lấy số thứ tự online giúp tiết kiệm thời gian khi đến làm việc tại cơ quan hành chính công.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.black54,
                      fontSize: 12.5,
                      height: 1.35,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Nút bo tròn nhẹ, màu tím nhạt, hiệu ứng gọn gàng
class _RoundedButton extends StatelessWidget {
  const _RoundedButton({
    required this.label,
    required this.icon,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    const Color mainColor = Color(0xFF4250E8);
    return Material(
      color: const Color(0xFFF1F3FF),
      borderRadius: BorderRadius.circular(24),
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: onTap,
        child: Container(
          height: 46,
          padding: const EdgeInsets.symmetric(horizontal: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            boxShadow: const [
              BoxShadow(
                color: Color(0x0D4250E8),
                blurRadius: 8,
                offset: Offset(0, 3),
              ),
            ],
          ),
          alignment: Alignment.center,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 18, color: mainColor),
              const SizedBox(width: 8),
              Flexible(
                child: Text(
                  label,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: mainColor,
                    fontSize: 13.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ====================== THỦ TỤC HÀNH CHÍNH (1 HÀNG / 4 CỘT) ======================
class _AdministrativeProceduresStrip extends StatelessWidget {
  const _AdministrativeProceduresStrip({super.key});

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;

    // Khai báo từng item + onTap riêng
    final items = [
      _ProcItem(
        index: 1,
        title: 'Danh mục\nTTHC',
        image: 'assets/images/tthc_im1.png',
        onTap: () {
          // TODO: mở màn hình danh mục TTHC
          context.push(
            '/webview?title=${Uri.encodeComponent('Cổng DVC Quốc gia')}'
            '&url=${Uri.encodeComponent(_url)}',
          );
        },
      ),
      _ProcItem(
        index: 2,
        title: 'Tra cứu\nTTHC',
        image: 'assets/images/tthc_im2.png',
        onTap: () {
          // TODO: mở màn hình tra cứu
          context.push(
            '/webview?title=${Uri.encodeComponent('Tra cứu thủ tục hành chính')}'
            '&url=${Uri.encodeComponent(_dvcUrl)}',
          );
        },
      ),
      _ProcItem(
        index: 3,
        title: 'Lấy số thứ tự\ntrực tuyến',
        image: 'assets/images/tthc_im3.png',
        onTap: () {
          //TODO: thêm link khi có
          context.push(
            '/screen/00.13.11?title=${Uri.encodeComponent('Lấy số thứ tự HCC')}',
          );
        },
      ),
      _ProcItem(
        index: 4,
        title: 'Hỗ trợ, tư vấn\nTTHC trực tuyến',
        image: 'assets/images/tthc_im4.png',
        onTap: () {
          // TODO: mở màn hình hỗ trợ/tư vấn
        },
      ),
    ];

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12),
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x12000000),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Thủ tục hành chính',
                style: text.titleMedium?.copyWith(
                  fontWeight: FontWeight.w800,
                  letterSpacing: .2,
                ),
              ),
              const Spacer(),
            ],
          ),
          const SizedBox(height: 12),

          // 1 hàng / 4 cột
          SizedBox(
            height: 170,
            child: Row(
              children: List.generate(items.length * 2 - 1, (i) {
                if (i.isOdd) return const SizedBox(width: 5);
                final item = items[i ~/ 2];
                return Expanded(child: _ProcTile(item: item));
              }),
            ),
          ),
        ],
      ),
    );
  }
}

class _ProcItem {
  final int index; // 1..4
  final String title; // 2 dòng
  final String image; // asset path
  final VoidCallback? onTap; // sự kiện riêng
  const _ProcItem({
    required this.index,
    required this.title,
    required this.image,
    this.onTap,
  });
}

class _ProcTile extends StatelessWidget {
  const _ProcTile({super.key, required this.item});
  final _ProcItem item;

  Color get badgeColor {
    switch (item.index) {
      case 1:
        return const Color(0xff2563EB);
      case 2:
        return const Color(0xff16A34A);
      case 3:
        return const Color(0xffB45309);
      default:
        return const Color(0xff1D4ED8);
    }
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;

    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: item.onTap,
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            // Nền thẻ + ảnh full
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(
                    color: const Color(0xffE5E7EB),
                  ), // viền mảnh như mẫu
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    // Ảnh nền full card
                    Image.asset(
                      item.image,
                      fit: BoxFit.cover, // 🔥 full thẻ
                      filterQuality: FilterQuality.high,
                    ),

                    // Lớp mờ nhẹ để chữ rõ hơn (từ trên xuống giữa)
                    const DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.center,
                          colors: [
                            Color(0xB3FFFFFF), // trắng mờ ở trên
                            Color(0x66FFFFFF), // nhạt dần
                            Color(0x00FFFFFF), // trong suốt
                          ],
                        ),
                      ),
                    ),

                    // Nội dung: chừa đỉnh cho badge
                    Padding(
                      padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
                      child: Column(
                        children: [
                          const SizedBox(height: 6), // khoảng trống dưới badge
                          // Tiêu đề 2 dòng ở giữa
                          Expanded(
                            child: Center(
                              child: Text(
                                item.title,
                                textAlign: TextAlign.center,
                                maxLines: 5,
                                overflow: TextOverflow.ellipsis,
                                style: text.titleSmall?.copyWith(
                                  fontWeight: FontWeight.w700,
                                  height: 1.25,
                                  fontSize: 13,
                                  color: Colors.black87,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Badge số tròn nằm chồng trên đỉnh
            Positioned(
              top: -12,
              left: 0,
              right: 0,
              child: Align(
                alignment: Alignment.topCenter,
                child: Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    color: badgeColor,
                    shape: BoxShape.circle,
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0x33000000),
                        blurRadius: 6,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      '${item.index}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TTHCCard1 extends StatelessWidget {
  const _TTHCCard1({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          // TODO: xử lý khi bấm vào (ví dụ: mở trang bản đồ giao thông)
          context.push(
            '/webview?title=${Uri.encodeComponent('Tra cứu thủ tục hành chính')}'
            '&url=${Uri.encodeComponent(_dvcUrl)}',
          );
        },
        child: Container(
          height: 120,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            boxShadow: const [
              BoxShadow(
                color: Color(0x19000000),
                blurRadius: 14,
                offset: Offset(0, 6),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Ảnh nền
                Image.asset(
                  'assets/images/tthc_im1_banner.png',
                  fit: BoxFit.cover,
                ),

                // Nội dung chữ
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Tra cứu thủ tục hành chính  →',
                          maxLines: 3,
                          style: const TextStyle(
                            color: Colors.black87,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.2,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TTHCCard2 extends StatelessWidget {
  const _TTHCCard2({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          // TODO: xử lý khi bấm vào (ví dụ: mở trang bản đồ giao thông)

          context.push(
            '/webview?title=${Uri.encodeComponent('Cổng DVC Quốc gia')}'
            '&url=${Uri.encodeComponent(_url)}',
          );
        },
        child: Container(
          height: 120,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            boxShadow: const [
              BoxShadow(
                color: Color(0x19000000),
                blurRadius: 14,
                offset: Offset(0, 6),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Ảnh nền
                Image.asset(
                  'assets/images/tthc_im2_banner.png',
                  fit: BoxFit.cover,
                ),

                // Nội dung chữ
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Danh sách thủ tục hành chính  →',
                          maxLines: 3,
                          style: const TextStyle(
                            color: Colors.black87,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.2,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TTHCCard3 extends StatelessWidget {
  const _TTHCCard3({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          // TODO: xử lý khi bấm vào (ví dụ: mở trang bản đồ giao thông)

          context.push(
            '/screen/00.13.11?title=${Uri.encodeComponent('Lấy số thứ tự HCC')}',
          );
        },
        child: Container(
          height: 120,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            boxShadow: const [
              BoxShadow(
                color: Color(0x19000000),
                blurRadius: 18,
                offset: Offset(0, 6),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Ảnh nền
                Image.asset(
                  'assets/images/tthc_im3_banner.png',
                  fit: BoxFit.cover,
                ),

                // Nội dung chữ
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Lấy số thứ tự online  →',
                          maxLines: 3,
                          style: const TextStyle(
                            color: Colors.black87,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.2,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TTHCCard4 extends StatelessWidget {
  const _TTHCCard4({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          // TODO: xử lý khi bấm vào (ví dụ: mở trang bản đồ giao thông)
        },
        child: Container(
          height: 120,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            boxShadow: const [
              BoxShadow(
                color: Color(0x19000000),
                blurRadius: 14,
                offset: Offset(0, 6),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Ảnh nền
                Image.asset(
                  'assets/images/tthc_im4_banner.png',
                  fit: BoxFit.cover,
                ),

                // Nội dung chữ
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Tổ hỗ trợ tư vấn TTHC trực tuyến  →',
                          maxLines: 3,
                          style: const TextStyle(
                            color: Colors.black87,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.2,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

//! Chợ việc làm
class OnlineJobsCard extends StatelessWidget {
  const OnlineJobsCard({super.key});

  static const _targetUrl =
      'https://www.vieclamtot.com/tags/viec-lam-online-tai-nha';

  // Ảnh minh họa — đổi thành asset nếu muốn
  static const _imageUrl =
      'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800&q=80';

  static const _ink = Color(0xFF4250E8);

  Future<void> _open() async {
    final uri = Uri.parse(_targetUrl);
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    const double photoW = 108; // 👈 KÍCH THƯỚC ẢNH CỐ ĐỊNH
    const double radius = 16;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: const BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 16,
              offset: Offset(0, 8),
            ),
          ],
        ),
        child: Material(
          color: Colors.white,
          borderRadius: BorderRadius.circular(radius),
          child: InkWell(
            borderRadius: BorderRadius.circular(radius),
            // onTap: _open,
            onTap: () => {
              context.push(
                '/webview?title=${Uri.encodeComponent('Chợ việc làm online')}'
                '&url=${Uri.encodeComponent(_targetUrl)}',
              ),
            },
            child: ClipRRect(
              borderRadius: BorderRadius.circular(radius),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Row(
                  children: [
                    // Ảnh bên trái (có width cố định)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: SizedBox(
                        width: photoW,
                        height: photoW * 3 / 4, // 4:3
                        child: Image.network(
                          _imageUrl,
                          fit: BoxFit.cover,
                          loadingBuilder: (c, w, p) => p == null
                              ? w
                              : Container(
                                  color: const Color(0xFFEFF2FF),
                                  alignment: Alignment.center,
                                  child: const SizedBox(
                                    width: 18,
                                    height: 18,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                    ),
                                  ),
                                ),
                          errorBuilder: (_, __, ___) => Container(
                            color: const Color(0xFFEFF2FF),
                            alignment: Alignment.center,
                            child: const Icon(Icons.work_outline, color: _ink),
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(width: 12),

                    // Nội dung bên phải
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Chợ việc làm online',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 15.5,
                              fontWeight: FontWeight.w800,
                              color: Color(0xFF111827),
                            ),
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            'Việc tại nhà • Làm từ xa • Freelancer\nCập nhật tin mới mỗi ngày.',
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 12.5,
                              height: 1.25,
                              color: Colors.black54,
                            ),
                          ),
                          const SizedBox(height: 10),

                          Row(
                            children: const [
                              _TinyChip(
                                icon: Icons.star_rounded,
                                text: 'Uy tín',
                              ),
                              SizedBox(width: 12),
                              _TinyChip(
                                icon: Icons.schedule_rounded,
                                text: 'Linh hoạt',
                              ),
                            ],
                          ),

                          const SizedBox(height: 10),

                          SizedBox(
                            height: 40,
                            child: ElevatedButton.icon(
                              onPressed: _open,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFF1F3FF),
                                elevation: 0,
                                foregroundColor: _ink,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(22),
                                  side: const BorderSide(
                                    color: Color(0xFFE6E8FF),
                                  ),
                                ),
                              ),
                              icon: const Icon(
                                Icons.open_in_new_rounded,
                                size: 18,
                              ),
                              label: const Text(
                                'Xem việc online',
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13.5,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// Chip nhỏ
class _TinyChip extends StatelessWidget {
  const _TinyChip({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: const Color(0xFFF7F8FF),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFFE6E8FF)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.star_rounded,
            size: 0,
          ), // dummy to keep const? (not needed)
          Icon(icon, size: 14, color: const Color(0xFF6B72EE)),
          const SizedBox(width: 4),
          Text(
            text,
            style: const TextStyle(
              fontSize: 11.5,
              fontWeight: FontWeight.w600,
              color: Color(0xFF374151),
            ),
          ),
        ],
      ),
    );
  }
}

//TODO:

class _TaskColumn extends StatelessWidget {
  const _TaskColumn({
    required this.topLabel,
    this.bottomLabel = 'Kết thúc xử lý',
  });

  final String topLabel;
  final String bottomLabel;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Chip hành động (2 dòng tối đa)
        Material(
          color: const Color(0xFF5A65F4).withOpacity(.10),
          shape: const StadiumBorder(),
          child: InkWell(
            customBorder: const StadiumBorder(),
            onTap: () {},
            child: ConstrainedBox(
              constraints: const BoxConstraints(minHeight: 44),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                child: SizedBox(
                  width: double.infinity,
                  child: Text(
                    topLabel,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Color(0xFF4250E8),
                      fontWeight: FontWeight.w800,
                      fontSize: 13,
                      height: 1.15,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 10),

        // Nút xám
        Material(
          color: const Color(0xFFF3F4F6),
          shape: const StadiumBorder(),
          child: InkWell(
            customBorder: const StadiumBorder(),
            onTap: () {},
            child: ConstrainedBox(
              constraints: const BoxConstraints(minHeight: 40),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                child: SizedBox(
                  width: double.infinity,
                  child: Text(
                    bottomLabel,
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _ThemePlaygroundCard extends StatelessWidget {
  const _ThemePlaygroundCard();

  @override
  Widget build(BuildContext context) {
    // tiêu đề: phần "Vươn lên" tô xanh
    final titleStyle = const TextStyle(
      fontSize: 18,
      fontWeight: FontWeight.w900,
    );

    final items = const [
      _PlayItem(
        'Thảo Cầm Viên Sài Gòn',
        '07:00 ~ 17:30',
        'assets/images_v1/cv_v1_1.jpg',
      ),
      _PlayItem(
        'Sân chơi Công viên Tao Đàn',
        '05:00 ~ 22:00',
        'assets/images_v1/cv_v1_2.jpeg',
      ),
      _PlayItem(
        'Sân chơi Công viên Lê Văn Tám',
        '05:00 ~ 22:00',
        'assets/images_v1/cv_v1_3.webp',
      ),
      _PlayItem(
        'Sân chơi Công viên Gia Định',
        '05:00 ~ 22:00',
        'assets/images_v1/cv_v1_4.jpg',
      ),
      _PlayItem(
        'Công viên Bán Nguyệt – Cầu Ánh Sao',
        '17:00 ~ 22:00',
        'assets/images_v1/cv_v1_5.jpg',
      ),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 18,
              offset: Offset(0, 8),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Tiêu đề + nút tải
            Row(
              children: [
                Expanded(
                  child: RichText(
                    text: TextSpan(
                      style: titleStyle.copyWith(color: Colors.black),
                      children: const [
                        TextSpan(text: 'Cơ thể và tâm trí '),
                        TextSpan(
                          text: 'vươn lên',
                          style: TextStyle(color: Color(0xFF19BF6C)), // xanh lá
                        ),
                        TextSpan(text: ' · Sân chơi theo chủ đề'),
                      ],
                    ),
                  ),
                ),
                Material(
                  color: const Color(0xFFF1F5FF),
                  shape: const CircleBorder(),
                  child: IconButton(
                    icon: const Icon(
                      Icons.cloud_download_outlined,
                      size: 20,
                      color: Color(0xFF5A65F4),
                    ),
                    onPressed: () {},
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),

            // dòng cập nhật
            Row(
              children: const [
                Text(
                  'Cập nhật lúc: 25.08.16 21:56',
                  style: TextStyle(fontSize: 12, color: Colors.black54),
                ),
                SizedBox(width: 6),
                Icon(Icons.refresh, size: 16, color: Colors.black38),
              ],
            ),
            const SizedBox(height: 12),

            // Grid 2 cột (cao hơn, theo tỉ lệ)
            GridView.builder(
              padding: EdgeInsets.zero,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: items.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                // width / height -> 1.55 cho chiều cao ~95–105px tùy màn
                childAspectRatio: 1.55,
              ),
              itemBuilder: (_, i) => _PlayTile(items[i]),
            ),

            const SizedBox(height: 10),
            // ghi chú
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Icon(Icons.info_outline, size: 18, color: Colors.black45),
                SizedBox(width: 6),
                Expanded(
                  child: Text(
                    'Mức độ đông có thể thay đổi tùy tình hình thực tế.',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.black54,
                      height: 1.35,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),

            // nút “Xem trên bản đồ”
            Align(
              alignment: Alignment.center,
              child: ElevatedButton.icon(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF5A65F4),
                  foregroundColor: Colors.white,
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 10,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
                icon: const Icon(Icons.map_outlined, size: 18),
                label: const Text(
                  'Xem trên bản đồ',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlayTile extends StatelessWidget {
  final _PlayItem it;
  const _PlayTile(this.it, {super.key});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Ảnh nền
          Image.asset(it.bgAsset, fit: BoxFit.cover),
          // Overlay tối để chữ nổi bật
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.10),
                  Colors.black.withOpacity(0.45),
                ],
              ),
            ),
          ),
          // Nội dung
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Tiêu đề (chiếm phần còn lại, 2 dòng)
                Expanded(
                  child: Center(
                    child: Text(
                      it.title,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 13,
                        height: 1.2,
                        shadows: [Shadow(blurRadius: 2, color: Colors.black54)],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 2),
                // Giờ mở cửa
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.access_time,
                      size: 16,
                      color: Colors.white70,
                    ),
                    const SizedBox(width: 6),
                    Flexible(
                      child: Text(
                        it.time,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PlayItem {
  final String title;
  final String time;
  final String bgAsset;
  const _PlayItem(this.title, this.time, this.bgAsset);
}

// =================== Card 1: 이응다리 방문 통계 ===================
class _BridgeStatsCard extends StatelessWidget {
  const _BridgeStatsCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 18,
              offset: Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header: tiêu đề + chip trạng thái + chevron
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 14, 8, 6),
              child: Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Cầu Thủ Thiêm 2', // TP.HCM
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF4F5F7),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: const Text(
                      'Đang vận hành', // thay vì "Ngừng vận hành"
                      style: TextStyle(fontSize: 12, color: Colors.black87),
                    ),
                  ),
                  const SizedBox(width: 6),
                  const Icon(
                    Icons.keyboard_arrow_down_rounded,
                    color: Colors.black38,
                  ),
                ],
              ),
            ),

            // Dòng ngày/ghi chú tổng hợp (minh hoạ)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
              child: Row(
                children: const [
                  Text(
                    // dữ liệu minh hoạ
                    'Từ 2023.01.01 đến hôm qua\nTổng 1.234.567 lượt qua cầu.',
                    style: TextStyle(color: Colors.black54, height: 1.35),
                  ),
                  Spacer(),
                  Icon(Icons.more_horiz, color: Colors.black26),
                ],
              ),
            ),

            // Box số liệu đi bộ / xe đạp (minh hoạ)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: const Color(0xFFE8EAED)),
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
                child: Column(
                  children: [
                    // Box số liệu phương tiện (TP.HCM)
                    _bridgeRow(
                      icon: Icons.motorcycle,
                      title: 'Xe máy',
                      total: 'Tổng 982.340 lượt',
                      today: 'Hôm nay +3.420 lượt',
                    ),
                    const SizedBox(height: 10),
                    const Divider(height: 1, color: Color(0xFFEDEDED)),
                    const SizedBox(height: 10),
                    _bridgeRow(
                      icon: Icons.directions_car_filled_rounded,
                      title: 'Ô tô',
                      total: 'Tổng 756.200 lượt',
                      today: 'Hôm nay +1.120 lượt',
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),

            // Ghi chú theo ngữ cảnh TP.HCM
            const Padding(
              padding: EdgeInsets.fromLTRB(14, 0, 14, 14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.info_outline, size: 18, color: Colors.black45),
                  SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'Trong giờ cao điểm hoặc khi mưa lớn/triều cường, có thể hạn chế người đi bộ và xe đạp. '
                      'Vui lòng tuân thủ biển báo và hướng dẫn của lực lượng chức năng.',
                      style: TextStyle(
                        color: Colors.black54,
                        fontSize: 12,
                        height: 1.35,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _bridgeRow({
    required IconData icon,
    required String title,
    required String total,
    required String today,
  }) {
    return Row(
      children: [
        Icon(icon, color: const Color(0xFF9C6B2C)),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.w700),
          ),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(total, style: const TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 2),
            Text(today, style: const TextStyle(color: Color(0xFF4E7CFD))),
          ],
        ),
      ],
    );
  }
}

// =================== Card 2: Tóm tắt lối đi chân trần ===================
class _BarefootTrailCard extends StatelessWidget {
  const _BarefootTrailCard({super.key});

  @override
  Widget build(BuildContext context) {
    // Số liệu minh hoạ – đổi theo dữ liệu thật nếu có
    const int todayCount = 520;
    const int cumulativeCount = 86240;
    const String since = '2024.07.19';

    String fmt(int v) {
      final s = v.toString();
      final buf = StringBuffer();
      var c = 0;
      for (int i = s.length - 1; i >= 0; i--) {
        buf.write(s[i]);
        c++;
        if (c == 3 && i != 0) {
          buf.write('.');
          c = 0;
        }
      }
      return buf.toString().split('').reversed.join();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 18,
              offset: Offset(0, 8),
            ),
          ],
        ),
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Hàng 1: Tiêu đề (trái) + số người hôm nay (phải)
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Expanded(
                  child: Text(
                    'Lối đi chân trần – Công viên Tao Đàn',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  '${fmt(todayCount)} người',
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ],
            ),
            const SizedBox(height: 8),

            // Hàng 2: pill "Hôm nay" + dấu chấm trang trí nhỏ
            Row(
              children: const [
                _MetaPill(icon: Icons.today, label: 'Hôm nay'),
                SizedBox(width: 10),
                _Dot(),
              ],
            ),
            const SizedBox(height: 8),

            // Mô tả lũy kế
            Text(
              'Từ $since đến hiện tại đã có ${fmt(cumulativeCount)} lượt tham quan.',
              style: const TextStyle(color: Colors.black54, height: 1.35),
            ),
          ],
        ),
      ),
    );
  }
}

// ---- Widgets phụ gọn gàng ----
class _MetaPill extends StatelessWidget {
  const _MetaPill({required this.icon, required this.label});
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFF3F4F6),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: Colors.black54),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(fontSize: 12, color: Colors.black87),
          ),
        ],
      ),
    );
  }
}

class _Dot extends StatelessWidget {
  const _Dot();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 6,
      height: 6,
      decoration: const BoxDecoration(
        color: Colors.black26,
        shape: BoxShape.circle,
      ),
    );
  }
}

// =================== Card 3: Banner “Hướng dẫn City Tour TP.HCM →” ===================
class _CityTourBanner extends StatelessWidget {
  const _CityTourBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        height: 110,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF5A65F4), Color(0xFF4250E8)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF4250E8).withOpacity(.25),
              blurRadius: 18,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned.fill(
              child: Row(
                children: [
                  const SizedBox(width: 16),
                  const Expanded(
                    child: Text(
                      'Hướng dẫn City Tour TP.HCM  →',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  // “illustration” placeholder
                  Container(
                    width: 120,
                    margin: const EdgeInsets.only(right: 10),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.directions_bus,
                      color: Colors.white,
                      size: 44,
                    ),
                  ),
                ],
              ),
            ),
            Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () {
                  // TODO: điều hướng tới trang city tour TP.HCM
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// =================== EDU BOOK CARD (TP.HCM) ===================
class _EduBookCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 18,
              offset: Offset(0, 8),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
        child: Column(
          children: [
            // ô "sách mở" 2 cột
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFFF8FAFF),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFE8ECFF)),
              ),
              padding: const EdgeInsets.fromLTRB(14, 16, 14, 16),
              child: Stack(
                children: [
                  Row(
                    children: [
                      // cột trái
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'Khám phá\nước mơ tại HCM!',
                              style: TextStyle(
                                color: Colors.black54,
                                height: 1.35,
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              'Trải nghiệm\nGiáo dục',
                              style: TextStyle(
                                color: Color(0xFF2563EB),
                                fontWeight: FontWeight.w900,
                                fontSize: 18,
                                height: 1.25,
                              ),
                            ),
                          ],
                        ),
                      ),
                      // cột phải
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: const [
                            Text(
                              'Càng tìm hiểu\ncàng bổ ích',
                              textAlign: TextAlign.right,
                              style: TextStyle(
                                color: Colors.black54,
                                height: 1.35,
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              '',
                              textAlign: TextAlign.right,
                              style: TextStyle(
                                color: Color(0xFF2563EB),
                                fontWeight: FontWeight.w900,
                                fontSize: 18,
                                height: 1.25,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  // minh họa nhân vật (placeholder)
                  const Positioned(
                    right: 0,
                    bottom: -6,
                    child: Icon(
                      Icons.emoji_people,
                      size: 46,
                      color: Color(0xFF7C8CFB),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),

            // dòng "Xem thêm"
            Row(
              children: const [
                // 👇 Cho text co giãn và cắt đuôi nếu dài
                Expanded(
                  child: Text(
                    'Xem thêm tại Trung tâm Hỗ trợ Giáo dục TP.HCM',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: Color(0xFF2563EB),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                SizedBox(width: 8),
                Icon(Icons.chevron_right, size: 20, color: Colors.black54),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// =================== MUSIC FOUNTAIN CARD (TP.HCM) ===================
class _MusicFountainCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 18,
              offset: Offset(0, 8),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // tiêu đề + icon pháo hoa
            Row(
              children: const [
                Expanded(
                  child: Text(
                    'Đài phun nước âm nhạc',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                  ),
                ),
                Icon(Icons.attractions_outlined, color: Color(0xFF7C8CFB)),
              ],
            ),
            const SizedBox(height: 10),

            // dòng 1 – Phố đi bộ Nguyễn Huệ
            _fountainRow(
              title: 'Phố đi bộ Nguyễn Huệ',
              period: 'Thời gian hoạt động: Cuối tuần & ngày lễ',
              statusText: 'Đang hoạt động',
              isOn: true,
              times: const ['Hôm nay: 19:30–19:50,', '20:30–20:50'],
            ),
            const SizedBox(height: 10),

            // dòng 2 – Công viên 23/9
            _fountainRow(
              title: 'Công viên 23/9 – Khu A',
              period: 'Thời gian hoạt động: 18:30–21:00',
              statusText: 'Đang hoạt động',
              isOn: true,
              times: const ['Hôm nay: 19:00–19:20,', '20:00–20:20'],
            ),

            const SizedBox(height: 8),
            const Text(
              '※ Lịch phun có thể thay đổi theo thời tiết, sự kiện hoặc yêu cầu vận hành.',
              style: TextStyle(
                color: Color(0xFFE11D48),
                fontSize: 12,
                height: 1.35,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _fountainRow({
    required String title,
    required String period,
    required String statusText,
    required bool isOn,
    required List<String> times,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFF),
        border: Border.all(color: const Color(0xFFE8ECFF)),
        borderRadius: BorderRadius.circular(12),
      ),
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
              // chip trạng thái
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: isOn
                      ? const Color(0xFFE8F8ED)
                      : const Color(0xFFFDECEC),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  statusText,
                  style: TextStyle(
                    color: isOn
                        ? const Color(0xFF16A34A)
                        : const Color(0xFFDC2626),
                    fontWeight: FontWeight.w700,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              period,
              style: const TextStyle(color: Colors.black54, fontSize: 12),
            ),
          ),
          const SizedBox(height: 8),
          // “radio” tròn nhạt + giờ hôm nay
          Row(
            children: [
              Container(
                width: 18,
                height: 18,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: const Color(0xFFD8DAE0), width: 2),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Wrap(
                  spacing: 6,
                  runSpacing: 2,
                  children: times
                      .map(
                        (t) => Text(
                          t,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 13,
                          ),
                        ),
                      )
                      .toList(),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ====================== KẾT NỐI GIAO THÔNG CARD ======================
class _BusCard extends StatelessWidget {
  const _BusCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          // TODO: xử lý khi bấm vào (ví dụ: mở trang bản đồ giao thông)
        },
        child: Container(
          height: 130,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            boxShadow: const [
              BoxShadow(
                color: Color(0x19000000),
                blurRadius: 14,
                offset: Offset(0, 6),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Ảnh nền
                Image.asset('assets/images/bus_banner.png', fit: BoxFit.cover),

                // Nội dung chữ
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Kết nối giao thông  →',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.2,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ====================== SAPABAY CARD ======================
class _SapabayCard extends StatelessWidget {
  const _SapabayCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          context.push(
            '/webview?title=${Uri.encodeComponent('Sàn SAPABAY')}'
            '&url=${Uri.encodeComponent('https://sapabay.com/')}',
          );
        },
        child: Container(
          height: 130,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            boxShadow: const [
              BoxShadow(
                color: Color(0x19000000),
                blurRadius: 14,
                offset: Offset(0, 6),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Ảnh nền (banner tải app)
                Image.asset(
                  'assets/images_v1/dich_vu/b3.png',
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => Container(
                    color: const Color(0xFFE3F2FD),
                    alignment: Alignment.center,
                    child: const Icon(
                      Icons.image,
                      color: Color(0xFF1A73E8),
                      size: 48,
                    ),
                  ),
                ),

                // Lớp mờ gradient để chữ dễ đọc
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.bottomLeft,
                      end: Alignment.topRight,
                      colors: [
                        Colors.black.withOpacity(0.05),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),

                // Tiêu đề "Sàn Sapabay"
                Positioned(
                  left: 16,
                  bottom: 16,
                  child: Text(
                    'Sàn SAPABAY',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      shadows: [
                        Shadow(
                          offset: Offset(0, 1),
                          blurRadius: 3,
                          color: Colors.black26,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SapabayAppCard extends StatelessWidget {
  const _SapabayAppCard({super.key});

  static const _apkUrl =
      'https://firebasestorage.googleapis.com/v0/b/imagegov.firebasestorage.app/o/app_mobile%2FSAPABAY.apk?alt=media&token=e78d4f5d-d18f-40c9-a792-bbcc3610aad7';

  Future<void> _openDownloadLink() async {
    final uri = Uri.parse(_apkUrl);

    // Mở bằng trình duyệt mặc định (Chrome, Safari,...)
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Không thể mở link tải: $uri');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: _openDownloadLink,
        child: Container(
          height: 130,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            boxShadow: const [
              BoxShadow(
                color: Color(0x19000000),
                blurRadius: 14,
                offset: Offset(0, 6),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Ảnh nền (banner tải app)
                Image.asset(
                  'assets/images_v1/dich_vu/b1.png',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    color: const Color(0xFFE3F2FD),
                    alignment: Alignment.center,
                    child: const Icon(
                      Icons.download_rounded,
                      color: Color(0xFF1A73E8),
                      size: 48,
                    ),
                  ),
                ),

                // Lớp phủ gradient
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.bottomLeft,
                      end: Alignment.topRight,
                      colors: [
                        Colors.black.withOpacity(0.05),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),

                // Tiêu đề
                 Positioned(
                  left: 16,
                  right: 16,        // <-- giới hạn chiều ngang
                  bottom: 16,
                  child: Row(
                    children: [
                      const Icon(
                        Icons.download_rounded,
                        color: Colors.white,
                        size: 22,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Trải nghiệm ngay mua sắm hàng ngày tại sapabay.com',
                          maxLines: 2,                         // cho tối đa 2 dòng
                          overflow: TextOverflow.ellipsis,     // nếu dư thì "..."
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,                      // hơi nhỏ lại cho fit
                            fontWeight: FontWeight.w700,
                            height: 1.2,
                            shadows: [
                              Shadow(
                                offset: Offset(0, 1),
                                blurRadius: 3,
                                color: Colors.black26,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ================= OIL PRICE CARD =================
class _OilPriceCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Ví dụ minh hoạ – thay bằng dữ liệu thực tế nếu có
    const String fuel = 'Xăng RON95';
    const String date = '2025-08-16';
    const String avg = '25.980'; // đồng/lít, hiển thị dạng 25.980
    const String delta = '-150'; // chênh lệch so với hôm qua (đ)
    const String minP = '25.600';
    const String maxP = '26.400';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 18,
              offset: Offset(0, 8),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(14, 16, 14, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // header
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Giá xăng hôm nay',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                  ),
                ),
                Text(fuel, style: const TextStyle(color: Colors.black87)),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: const [
                Text(
                  'TP.HCM trung bình (đồng/lít)',
                  style: TextStyle(color: Colors.black54, fontSize: 12),
                ),
                Spacer(),
                Text(
                  'Cập nhật: 2025-08-16',
                  style: TextStyle(color: Colors.black54, fontSize: 12),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                const Text(
                  avg,
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                ),
                const SizedBox(width: 8),
                Text(
                  delta.startsWith('-') ? delta : '+$delta',
                  style: TextStyle(
                    color: delta.startsWith('-')
                        ? const Color(0xFF2563EB) // giảm: xanh
                        : const Color(0xFFE11D48), // tăng: đỏ
                    fontSize: 14,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Text.rich(
                  TextSpan(
                    style: const TextStyle(color: Colors.black87, fontSize: 13),
                    children: [
                      const TextSpan(text: 'Thấp nhất '),
                      TextSpan(
                        text: minP,
                        style: const TextStyle(
                          color: Color(0xFF16A34A),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 20),
                Text.rich(
                  TextSpan(
                    style: const TextStyle(color: Colors.black87, fontSize: 13),
                    children: [
                      const TextSpan(text: 'Cao nhất '),
                      TextSpan(
                        text: maxP,
                        style: const TextStyle(
                          color: Color(0xFFE11D48), // đỏ
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 6),
            const Text(
              'Nguồn: tham khảo từ các cửa hàng xăng dầu tại TP.HCM',
              style: TextStyle(color: Colors.black45, fontSize: 11),
            ),
            const SizedBox(height: 12),
            // bottom bar
            Container(
              width: double.infinity,
              height: 40,
              decoration: BoxDecoration(
                color: const Color(0xFFF8FAFF),
                borderRadius: BorderRadius.circular(12),
              ),
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () {},
                child: const Center(
                  child: Text(
                    'Xem thêm cây xăng >',
                    style: TextStyle(
                      color: Color(0xFF2563EB),
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ================= HOSPITAL & PHARMACY CARD (TP.HCM) =================
class _HospitalPharmacyCard extends StatelessWidget {
  const _HospitalPharmacyCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 18,
              offset: Offset(0, 8),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(14, 16, 14, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text.rich(
              TextSpan(
                children: [
                  TextSpan(
                    text: 'Đang hoạt động ',
                    style: TextStyle(
                      color: Color(0xFF16A34A),
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  TextSpan(
                    text: 'Bệnh viện · Nhà thuốc',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                ],
              ),
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 6),
            const Text(
              'Bạn có thể xem các cơ sở mở cửa vào ngày nghỉ/ban đêm tại TP.HCM.',
              style: TextStyle(color: Colors.black54, height: 1.35),
            ),
            const SizedBox(height: 12),
            Column(
              children: const [
                _HpRow(
                  icon: Icons.local_hospital_outlined,
                  label: 'Tìm bệnh viện',
                ),
                Divider(height: 1, color: Color(0xFFE5E7EB)),
                _HpRow(
                  icon: Icons.local_pharmacy_outlined,
                  label: 'Tìm nhà thuốc',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _HpRow extends StatelessWidget {
  const _HpRow({required this.icon, required this.label, super.key});
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {}, // TODO: điều hướng tra cứu
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Row(
          children: [
            Icon(icon, color: const Color(0xFF2563EB)),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                color: Color(0xFF2563EB),
                fontWeight: FontWeight.w700,
                fontSize: 14,
              ),
            ),
            const Spacer(),
            const Icon(Icons.chevron_right, size: 20, color: Colors.black38),
          ],
        ),
      ),
    );
  }
}

// ================= MART OPEN CARD (TP.HCM) =================
class _MartOpenCard extends StatelessWidget {
  const _MartOpenCard({super.key});

  @override
  Widget build(BuildContext context) {
    // Danh sách siêu thị phổ biến ở TP.HCM (ví dụ minh hoạ)
    final marts = [
      {
        'name': 'Emart',
        'branch': 'Gò Vấp',
        'color': const Color(0xFFF59E0B),
        'logo': Icons.store_mall_directory_outlined,
      },
      {
        'name': 'AEON',
        'branch': 'Tân Phú',
        'color': const Color(0xFF6366F1),
        'logo': Icons.apartment_rounded,
      },
      {
        'name': 'LOTTE Mart',
        'branch': 'Quận 7',
        'color': const Color(0xFFE11D48),
        'logo': Icons.shopping_bag_outlined,
      },
      {
        'name': 'GO! (Big C)',
        'branch': 'Thủ Đức',
        'color': const Color(0xFF22C55E),
        'logo': Icons.shopping_cart_checkout_outlined,
      },
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 18,
              offset: Offset(0, 8),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(14, 16, 14, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text.rich(
              TextSpan(
                children: [
                  const TextSpan(text: 'Lịch mở cửa '),
                  const TextSpan(
                    text: 'Hằng ngày',
                    style: TextStyle(
                      color: Color(0xFFE11D48),
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const TextSpan(text: ': các siêu thị lớn '),
                  const TextSpan(
                    text: 'mở cửa',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const TextSpan(text: ' • xem vị trí gần bạn →'),
                ],
              ),
              style: TextStyle(fontSize: 15),
            ),
            const SizedBox(height: 14),

            // >>> Thêm list vào đây (không thể để const vì dùng biến marts)
            _MartOpenList(marts: marts),
          ],
        ),
      ),
    );
  }
}

// Gắn list hiển thị ngay bên dưới tiêu đề:
class _MartOpenList extends StatelessWidget {
  const _MartOpenList({required this.marts, super.key});
  final List<Map<String, Object>> marts;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 96,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: marts.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, i) {
          final mart = marts[i];
          return Container(
            width: 92,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: mart['color'] as Color,
            ),
            padding: const EdgeInsets.all(8),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(mart['logo'] as IconData, color: Colors.white, size: 28),
                const SizedBox(height: 6),
                Text(
                  mart['name'] as String,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  mart['branch'] as String,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 11),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// =============== 1) APP SHORTCUT PAGER ===============
class _AppShortcutPager extends ConsumerStatefulWidget {
  const _AppShortcutPager({super.key});

  @override
  ConsumerState<_AppShortcutPager> createState() => _AppShortcutPagerState();
}

class _AppShortcutPagerState extends ConsumerState<_AppShortcutPager> {
  final _ctrl = PageController();
  int _index = 0;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final itemsAsync = ref.watch(menuTracuuProvider('vi'));

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 18,
              offset: Offset(0, 8),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(10, 14, 10, 12),
        child: itemsAsync.when(
          loading: () => const SizedBox(height: 200, child: LoadingWidget()),
          error: (e, _) => SizedBox(
            height: 200,
            child: Center(child: Text('Lỗi tải menu: $e')),
          ),
          data: (all) {
            final items = all.take(16).toList();
            if (items.isEmpty) {
              return const SizedBox(
                height: 60,
                child: Center(child: Text('Chưa có mục nào')),
              );
            }

            final pages = _chunk(items, 8);

            return Column(
              children: [
                // ===== Header với nút Xem tất cả =====
                Row(
                  children: [
                    const Text(
                      'Tra cứu nhanh',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const Spacer(),
                    TextButton.icon(
                      onPressed: () {
                        context.push('/tracuu');
                      },
                      icon: const Icon(
                        Icons.apps_outlined,
                        size: 16,
                        color: Color(0xFF2563EB),
                      ),
                      label: const Text(
                        'Xem tất cả',
                        style: TextStyle(
                          color: Color(0xFF2563EB),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 6,
                        ),
                        shape: const StadiumBorder(),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                // ===== Lưới shortcut dạng trang =====
                SizedBox(
                  height: 200,
                  child: PageView.builder(
                    controller: _ctrl,
                    itemCount: pages.length,
                    onPageChanged: (i) => setState(() => _index = i),
                    itemBuilder: (_, i) => _ShortcutGridApi(items: pages[i]),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(pages.length, (i) {
                    final sel = i == _index;
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.symmetric(horizontal: 3.5),
                      width: sel ? 7 : 6,
                      height: sel ? 7 : 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: sel ? Colors.black87 : Colors.black26,
                      ),
                    );
                  }),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

/// Chia list thành các khúc [size]
List<List<T>> _chunk<T>(List<T> list, int size) {
  final out = <List<T>>[];
  for (var i = 0; i < list.length; i += size) {
    out.add(list.sublist(i, i + size > list.length ? list.length : i + size));
  }
  return out;
}

// Grid 2×4 – mỗi ô cao hơn một chút để đủ 2 dòng chữ
class _ShortcutGridApi extends StatelessWidget {
  const _ShortcutGridApi({required this.items, super.key});
  final List<MenuModel> items;

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(6, 0, 6, 4),
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        // 52 (icon) + 6 (khoảng cách) + 34 (khu chữ 2 dòng) + 6 (đệm)
        mainAxisExtent: 98,
      ),
      itemCount: items.length,
      itemBuilder: (_, i) => _ShortcutTileApi(item: items[i]),
    );
  }
}

class _ShortcutTileApi extends StatelessWidget {
  const _ShortcutTileApi({required this.item, super.key});
  final MenuModel item;

  static const double _iconSize = 52;
  static const double _labelBoxH = 34; // vừa cho 2 dòng cỡ 12, height ~1.2

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => item.onTap(context),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start, // icon luôn thẳng hàng trên
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // ICON ZONE (cố định)
          Container(
            width: _iconSize,
            height: _iconSize,
            decoration: BoxDecoration(
              color: const Color(0xFFF6F7FB),
              borderRadius: BorderRadius.circular(14),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Image.network(
                item.iconUrl,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) =>
                    const Icon(Icons.apps, size: 28, color: Color(0xFF4B5563)),
              ),
            ),
          ),

          const SizedBox(height: 6),

          // LABEL ZONE (cố định chiều cao cho toàn hàng)
          SizedBox(
            height: _labelBoxH,
            width: double.infinity,
            child: Center(
              child: Text(
                item.labelVi,
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12, height: 1.2),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// =============== 2) LIBRARY NOTICE CARD ===============
class _LibraryNoticeCard extends StatelessWidget {
  const _LibraryNoticeCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(
              color: Color(0x14000000),
              blurRadius: 18,
              offset: Offset(0, 8),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            // tiêu đề 2 dòng, có chữ xanh
            Text.rich(
              TextSpan(
                children: [
                  TextSpan(text: 'Nơi lan toả '),
                  TextSpan(
                    text: 'văn hoá đọc',
                    style: TextStyle(
                      color: Color(0xFF16A34A),
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  TextSpan(text: '\nThư viện TP.HCM'),
                ],
              ),
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w900,
                height: 1.35,
              ),
            ),
            SizedBox(height: 8),
            Text(
              '※ Thư viện nghỉ vào Thứ Hai hằng tuần và các ngày lễ.',
              style: TextStyle(color: Colors.black54, height: 1.35),
            ),
            SizedBox(height: 10),
            Row(
              children: [
                Text(
                  'Cập nhật lúc: 25.08.16 21:56',
                  style: TextStyle(color: Colors.black54, fontSize: 12),
                ),
                SizedBox(width: 6),
                Icon(Icons.refresh, size: 16, color: Colors.black38),
              ],
            ),
            SizedBox(height: 10),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.info_outline, size: 18, color: Colors.black45),
                SizedBox(width: 6),
                Expanded(
                  child: Text(
                    'Lượng khách có thể thay đổi tuỳ tình hình thực tế.',
                    style: TextStyle(
                      color: Colors.black54,
                      fontSize: 12,
                      height: 1.35,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// =============== 3) FOOTER SECTION ===============
class _FooterSection extends StatelessWidget {
  const _FooterSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Column(
        children: [
          // nút hàng trên: Tùy chỉnh giao diện | Lên đầu trang
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () {},
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    side: const BorderSide(color: Color(0xFFE5E7EB)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text('Tùy chỉnh giao diện'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton(
                  onPressed: () {
                    // scroll to top
                    PrimaryScrollController.of(context)?.animateTo(
                      0,
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeOut,
                    );
                  },
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    side: const BorderSide(color: Color(0xFFE5E7EB)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text('Lên đầu trang'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          // link nhỏ dưới cùng
          const Wrap(
            alignment: WrapAlignment.center,
            spacing: 12,
            runSpacing: 6,
            children: [
              _FooterLink('Chính sách quyền riêng tư'),
              _FooterLink('Chính sách bản quyền'),
              _FooterLink('Không thu thập email trái phép'),
              _FooterLink('Chính sách vận hành thiết bị ghi hình'),
            ],
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}

class _FooterLink extends StatelessWidget {
  const _FooterLink(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {},
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 12,
          decoration: TextDecoration.underline,
        ),
      ),
    );
  }
}
