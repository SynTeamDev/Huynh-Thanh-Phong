import 'package:flutter/material.dart';
//https://api.openweathermap.org/data/2.5/air_pollution?lat=10.7826415&lon=106.7017684&appid=8fddbcd00caa56dff1f51927a5bd5ba6
class AQIModel {
  final int aqi;

  AQIModel({required this.aqi});

  factory AQIModel.fromJson(Map<String, dynamic> json) {
    return AQIModel(aqi: json['list'][0]['main']['aqi']);
  }

  // Tùy theo chuẩn AQI của OpenWeatherMap (1–5)
  String get qualityText {
    switch (aqi) {
      case 1:
        return 'Tốt';
      case 2:
        return 'Khá';
      case 3:
        return 'Trung bình';
      case 4:
        return 'Kém';
      case 5:
        return 'Rất kém';
      default:
        return 'Không xác định';
    }
  }

  Color get qualityColor {
    switch (aqi) {
      case 1:
        return Colors.green;
      case 2:
        return Colors.lightGreen;
      case 3:
        return Colors.orange;
      case 4:
        return Colors.red;
      case 5:
        return Colors.brown;
      default:
        return Colors.grey;
    }
  }
}
