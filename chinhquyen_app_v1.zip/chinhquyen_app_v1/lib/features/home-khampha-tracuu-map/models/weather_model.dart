
//https://api.openweathermap.org/data/2.5/weather?lat=10.7826415&lon=106.7017684&units=metric&lang=vi&appid=8fddbcd00caa56dff1f51927a5bd5ba6
class WeatherModel {
  final double temp;
  final String description;
  final String city;
  final String icon;

  WeatherModel({
    required this.temp,
    required this.description,
    required this.city,
    required this.icon,
  });

  factory WeatherModel.fromJson(Map<String, dynamic> json) {
    return WeatherModel(
      temp: json['main']['temp']?.toDouble() ?? 0,
      description: json['weather'][0]['description'] ?? '',
      city: json['name'] ?? '',
      icon: json['weather'][0]['icon'] ?? '',
    );
  }
}
