import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dio/dio.dart';

import '../../../../config/env.dart';
import '../../../../core/utils/permisson.dart';
import '../../models/aqi_model.dart';

final aqiProvider = FutureProvider<AQIModel>((ref) async {
  final position = await LocationService.getCurrentPosition();
  final dio = Dio();

  final response = await dio.get(
    '${Env.weatherUrl}/air_pollution',
    queryParameters: {
      'lat': position.latitude,
      'lon': position.longitude,
      'appid': Env.weatherApiKey,
    },
  );

  return AQIModel.fromJson(response.data);
});
