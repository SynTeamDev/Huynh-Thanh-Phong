import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';

import '../../../../core/utils/permisson.dart';

final locationProvider = FutureProvider<Position>((ref) async {
  return await LocationService.getCurrentPosition();
});
