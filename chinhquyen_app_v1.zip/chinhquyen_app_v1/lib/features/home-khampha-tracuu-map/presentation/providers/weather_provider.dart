import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dio/dio.dart';

import '../../../../config/env.dart';
import '../../../../core/utils/permisson.dart';
import '../../models/weather_model.dart';

final weatherProvider = FutureProvider<WeatherModel>((ref) async {
  final position = await LocationService.getCurrentPosition();
  final dio = Dio();

  print("lat: ${position.latitude}");
  print("lon: ${position.longitude}");

  final response = await dio.get(
    '${Env.weatherUrl}/weather',
    queryParameters: {
      'lat': position.latitude,
      'lon': position.longitude,
      'units': 'metric',
      'lang': 'vi',
      'appid': Env.weatherApiKey,
    },
  );

  return WeatherModel.fromJson(response.data);
});
