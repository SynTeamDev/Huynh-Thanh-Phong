import 'package:chinhquyen_app/core/widgets/loading_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:ionicons/ionicons.dart';

import '../../../../../../../../core/utils/delay_btn_helper.dart';
import '../providers/map_location_provider.dart';
import '../widgets/home-khampha/tim_kiem_dia_diem/presentation/providers/tim_kiem_dia_diem_provider.dart';
import '../widgets/home-khampha/tim_kiem_dia_diem/presentation/widgets/tim_kiem_dia_diem_filter.dart';

class MapPage extends ConsumerStatefulWidget {
  const MapPage({super.key});

  @override
  ConsumerState<MapPage> createState() => _MapPageState();
}

class _MapPageState extends ConsumerState<MapPage> {
  GoogleMapController? _mapController;

  ScrollController? _listCtrl;
  final _sheetCtrl = DraggableScrollableController();

  static const double _min = 0.11;
  static const double _max = 0.35; // << chỉ mở tối đa tới 0.35
  static const double _init = 0.35; // << khởi tạo ở mức tối đa (bằng _max)

  bool _expanded = true;
  // ---- UI constants ----
  static const double _initZoom = 16;

  // ---- state ----
  final Set<Marker> _markers = {};
  String? _selectedMa;

  DateTime? _ngayCt1, _ngayCt2;
  String? _ma_lhhd, _ten_location;

  @override
  void initState() {
    super.initState();
    // bỏ _listCtrl.addListener(_onListScroll);  // vì _listCtrl chưa có ở đây

    _sheetCtrl.addListener(() {
      final e = _sheetCtrl.size > (_min + _max) / 2;
      if (e != _expanded) setState(() => _expanded = e);
    });

    _initDatesToDefault();
    final filter = ref.read(timkiemddFilterStateProvider);
    if (filter != null) _applyFilterFromTuple(filter);
  }

  @override
  void dispose() {
    _listCtrl?.removeListener(
      _onListScroll,
    ); // KHÔNG dispose vì không phải do mình tạo
    _sheetCtrl.dispose();
    _mapController?.dispose();
    super.dispose();
  }

  void _bindListCtrl(ScrollController c) {
    if (identical(_listCtrl, c)) return; // tránh gắn lại nhiều lần
    _listCtrl?.removeListener(_onListScroll);
    _listCtrl = c;
    _listCtrl!.addListener(_onListScroll);
  }

  void _toggleSheet() {
    if (!_sheetCtrl.isAttached) return;
    final target = _expanded ? _min : _max; // mở <-> thu giữa 0.35 và 0.11
    _sheetCtrl.animateTo(
      target,
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
    );
  }

  // ---------------- helpers ----------------
  void _initDatesToDefault() {
    final now = DateTime.now();
    _ngayCt1 = DateTime(now.year, now.month - 6, 1);
    _ngayCt2 = DateTime(now.year, now.month + 2, 0);
  }

  void _applyFilterFromTuple((DateTime, DateTime, String?, String?) filter) {
    final (ngayCt1, ngayCt2, ma_lhhd, ten_location) = filter;
    _ngayCt1 = ngayCt1;
    _ngayCt2 = ngayCt2;
    _ma_lhhd = ma_lhhd;
    _ten_location = ten_location;
  }

  Future<void> _onRefreshPressed() async {
    if (!GlobalButtonDisableHelper.isDisabled) {
      GlobalButtonDisableHelper.disableTemporarily(seconds: 1);
      setState(() {
        _initDatesToDefault();
        _ma_lhhd = _ten_location = null;
      });
      ref.read(timkiemddFilterStateProvider.notifier).state = null;
      ref.invalidate(timkiemddListProvider); // gọi lại API
    }
  }

  Future<void> _onFilterPressed() async {
    if (GlobalButtonDisableHelper.isDisabled) return;
    GlobalButtonDisableHelper.disableTemporarily(seconds: 1);

    final result = await TimKiemDiaDiemFilter(
      initialFromDate: _ngayCt1 ?? DateTime.now(),
      initialToDate: _ngayCt2 ?? DateTime.now(),
      initialValues: (_ma_lhhd, _ten_location),
    ).show(context);

    if (result != null) {
      ref.read(timkiemddFilterStateProvider.notifier).state = result;
      setState(() => _applyFilterFromTuple(result));
      ref.invalidate(timkiemddListProvider);
    }
  }

  void _onListScroll() {
    final c = _listCtrl;
    if (c == null) return;
    if (c.position.pixels >= c.position.maxScrollExtent - 100) {
      ref.read(timkiemddListProvider.notifier).fetchTimKiemDDList();
    }
  }

  double _toDouble(dynamic v) {
    if (v == null) return 0;
    if (v is num) return v.toDouble();
    if (v is String) return double.tryParse(v) ?? 0;
    return 0;
  }

  String _distanceKm(Position me, double lat, double lng) {
    final d = Geolocator.distanceBetween(me.latitude, me.longitude, lat, lng);
    if (d < 1000) return '${d.toStringAsFixed(0)} m';
    return '${(d / 1000).toStringAsFixed(1)} km';
  }

  Future<void> _animateTo(LatLng target, {double zoom = 17}) async {
    await _mapController?.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: target, zoom: zoom),
      ),
    );
  }

  void _zoomIn() => _mapController?.animateCamera(CameraUpdate.zoomIn());
  void _zoomOut() => _mapController?.animateCamera(CameraUpdate.zoomOut());

  void _setMarkers(Position me, {Map<String, dynamic>? place}) {
    final set = <Marker>{
      Marker(
        markerId: const MarkerId('current'),
        position: LatLng(me.latitude, me.longitude),
        infoWindow: const InfoWindow(title: 'Bạn đang ở đây'),
      ),
    };
    if (place != null) {
      final lat = _toDouble(place['tdy']);
      final lng = _toDouble(place['tdx']);
      set.add(
        Marker(
          markerId: MarkerId('sel_${place['ma_location']}'),
          position: LatLng(lat, lng),
          infoWindow: InfoWindow(
            title: (place['ten_location'] ?? '').toString(),
            snippet: (place['dia_chi'] ?? '').toString(),
          ),
        ),
      );
    }
    setState(() {
      _markers
        ..clear()
        ..addAll(set);
    });
  }

  Future<void> _goToPlace(Map<String, dynamic> item, Position me) async {
    final lat = _toDouble(item['tdy']);
    final lng = _toDouble(item['tdx']);
    setState(() => _selectedMa = (item['ma_location'] ?? '').toString());
    _setMarkers(me, place: item);
    await _animateTo(LatLng(lat, lng));
  }

  void _goToCurrentLocation(Position me) {
    _animateTo(LatLng(me.latitude, me.longitude), zoom: _initZoom);
    _setMarkers(me);
  }

  // ---------------- UI builders ----------------
  Widget _buildMap(LatLng myLatLng) {
    return GoogleMap(
      onMapCreated: (controller) => _mapController = controller,
      initialCameraPosition: CameraPosition(target: myLatLng, zoom: _initZoom),
      markers: _markers,
      myLocationEnabled: true,
      myLocationButtonEnabled: false,
      zoomControlsEnabled: false, // ⛔ tắt hộp +/- mặc định
    );
  }

  Widget _buildControls(Position me) {
    return Positioned(
      right: 8,
      top: 0,
      child: SafeArea(
        child: Column(
          children: [
            _RoundMapBtn(
              icon: Icons.my_location,
              onTap: () => _goToCurrentLocation(me),
            ),
            const SizedBox(height: 8),
            _RoundMapBtn(icon: Icons.add, onTap: _zoomIn),
            const SizedBox(height: 6),
            _RoundMapBtn(icon: Icons.remove, onTap: _zoomOut),
          ],
        ),
      ),
    );
  }

  // --------------- build ---------------
  @override
  Widget build(BuildContext context) {
    final locationAsync = ref.watch(locationProvider);
    final list = ref.watch(timkiemddListProvider);

    return Scaffold(
      backgroundColor: Colors.white,
      body: locationAsync.when(
        loading: () => const LoadingWidget(),
        error: (e, _) => Center(child: Text('Lỗi định vị: $e')),
        data: (me) {
          final myLatLng = LatLng(me.latitude, me.longitude);
          if (_markers.isEmpty) _setMarkers(me);

          return Stack(
            children: [
              _buildMap(myLatLng),
              _buildControls(me),
              DraggableScrollableSheet(
                controller: _sheetCtrl,
                initialChildSize: _init,
                minChildSize: _min,
                maxChildSize: _max,
                snap: true,
                snapSizes: const [_min, _max], // << bỏ _init vì trùng _max
                // ĐỪNG đặt tên tham số ở đây là _listCtrl để khỏi đè biến field!
                builder: (context, sheetScrollCtrl) {
                  _bindListCtrl(sheetScrollCtrl); // nối controller để lazy-load

                  return ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(16),
                    ),
                    child: Material(
                      color: Colors.white,
                      elevation: 12,

                      child: CustomScrollView(
                        controller: sheetScrollCtrl, // quan trọng!
                        slivers: [
                          // Handle + arrow
                          SliverToBoxAdapter(
                            child: GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onTap: _toggleSheet,
                              child: Padding(
                                padding: const EdgeInsets.only(
                                  top: 4,
                                  bottom: 6,
                                ),
                                child: Center(
                                  child: AnimatedRotation(
                                    turns: _expanded ? 0.5 : 0.0,
                                    duration: const Duration(milliseconds: 180),
                                    child: const Icon(
                                      Ionicons.chevron_up,
                                      size: 18,
                                      color: Colors.black38,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),

                          // Header
                          SliverToBoxAdapter(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(16, 0, 8, 8),
                              child: Row(
                                children: [
                                  const Expanded(
                                    child: Text(
                                      'Danh sách địa điểm',
                                      style: TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 16,
                                      ),
                                    ),
                                  ),
                                  IconButton(
                                    tooltip: 'Làm mới',
                                    onPressed: _onRefreshPressed,
                                    icon: const Icon(
                                      Ionicons.refresh,
                                      color: Colors.blue,
                                    ),
                                  ),
                                  IconButton(
                                    tooltip: 'Lọc',
                                    onPressed: _onFilterPressed,
                                    icon: const Icon(
                                      Ionicons.search_outline,
                                      color: Colors.blue,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),

                          // List
                          SliverList(
                            delegate: SliverChildBuilderDelegate(
                              (context, i) => Padding(
                                padding: const EdgeInsets.fromLTRB(
                                  12,
                                  0,
                                  12,
                                  6,
                                ),
                                child: _buildPlaceCardCompact(me, list[i]),
                              ),
                              childCount: list.length,
                            ),
                          ),

                          // đáy chừa khoảng nhỏ để không đè viền bo
                          const SliverToBoxAdapter(child: SizedBox(height: 8)),
                        ],
                      ),

                      // child: Column(
                      //   children: [
                      //     // Handle + arrow: bấm để thu/mở
                      //     GestureDetector(
                      //       behavior: HitTestBehavior.opaque,
                      //       onTap: _toggleSheet,
                      //       child: Padding(
                      //         padding: const EdgeInsets.only(top: 0, bottom: 0),
                      //         child: Column(
                      //           children: [
                      //             const SizedBox(height: 2),
                      //             AnimatedRotation(
                      //               turns: _expanded ? 0.5 : 0.0,
                      //               duration: const Duration(milliseconds: 180),
                      //               child: const Icon(
                      //                 Ionicons.chevron_up,
                      //                 size: 18,
                      //                 color: Colors.black38,
                      //               ),
                      //             ),
                      //           ],
                      //         ),
                      //       ),
                      //     ),
                      //     // Header
                      //     Padding(
                      //       padding: const EdgeInsets.fromLTRB(16, 0, 8, 0),
                      //       child: Row(
                      //         children: [
                      //           const Expanded(
                      //             child: Text(
                      //               'Danh sách địa điểm',
                      //               style: TextStyle(
                      //                 fontWeight: FontWeight.w700,
                      //                 fontSize: 16,
                      //               ),
                      //             ),
                      //           ),
                      //           IconButton(
                      //             tooltip: 'Làm mới',
                      //             onPressed: _onRefreshPressed,
                      //             icon: const Icon(
                      //               Ionicons.refresh,
                      //               color: Colors.blue,
                      //             ),
                      //           ),
                      //           IconButton(
                      //             tooltip: 'Lọc',
                      //             onPressed: _onFilterPressed,
                      //             icon: const Icon(
                      //               Ionicons.search_outline,
                      //               color: Colors.blue,
                      //             ),
                      //           ),
                      //         ],
                      //       ),
                      //     ),
                      //     // List: dùng đúng controller của sheet (đã bind ở trên)
                      //     Expanded(
                      //       child: ListView.builder(
                      //         controller: sheetScrollCtrl,
                      //         padding: const EdgeInsets.fromLTRB(12, 0, 12, 6),
                      //         itemCount: list.length,
                      //         itemBuilder: (context, i) =>
                      //             _buildPlaceCardCompact(me, list[i]),
                      //       ),
                      //     ),
                      //   ],
                      // ),
                    ),
                  );
                },
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildPlaceCardCompact(Position me, Map<String, dynamic> item) {
    final ma = (item['ma_location'] ?? '').toString();
    final ten = (item['ten_location'] ?? '').toString();
    final lat = _toDouble(item['tdy']);
    final lng = _toDouble(item['tdx']);
    final selected = ma == _selectedMa;
    final distance = _distanceKm(me, lat, lng);

    return Card(
      elevation: selected ? 6 : 2,
      color: Colors.white,
      shadowColor: Colors.black26,
      margin: const EdgeInsets.symmetric(vertical: 1),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(
          color: selected ? Colors.blue : Colors.transparent,
          width: 1.1,
        ),
      ),
      child: InkWell(
        onTap: () => _goToPlace(item, me), // chỉ đến chỗ chọn
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 6, 12, 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // --- Hàng tiêu đề: icon + tên + chip km ---
              Row(
                children: [
                  CircleAvatar(
                    radius: 18,
                    backgroundColor: Colors.blue.shade50,
                    child: const Icon(Icons.place, color: Colors.blue),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      ten, // ví dụ: "Bệnh viện Từ Dũ"
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.green.shade50,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      distance, // ví dụ: "2.5 km"
                      style: const TextStyle(
                        color: Colors.green,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RoundMapBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _RoundMapBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 42,
      height: 42,
      decoration: const BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: Color(0x22000000),
            blurRadius: 6,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        type: MaterialType.transparency,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Center(child: Icon(icon, size: 22, color: Colors.blue)),
        ),
      ),
    );
  }
}
