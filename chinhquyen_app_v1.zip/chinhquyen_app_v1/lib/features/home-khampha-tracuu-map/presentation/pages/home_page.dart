import 'package:chinhquyen_app/core/widgets/loading_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:marquee/marquee.dart';
import 'package:collection/collection.dart';

import '../../../../core/shared/menu/grid_menu_widget.dart';
import '../../../../core/shared/menu/menu_model.dart';
import '../../../../core/shared/menu/menu_provider.dart';
import '../../../../core/utils/date_helper.dart';
import '../../../auth/presentation/providers/profile_provider.dart';
import '../providers/aqi_provider.dart';
import '../providers/data.dart';
import '../providers/weather_provider.dart';

class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    //! Weather/AQI
    final weatherAsync = ref.watch(weatherProvider);
    final aqiAsync = ref.watch(aqiProvider);

    //! Login
    final profileAsync = ref.watch(profileProvider);
    final profile = profileAsync.valueOrNull;
    final displayName = (profile?.nickname?.isNotEmpty ?? false)
        ? profile!.nickname!
        : 'Đăng nhập';

    //! Menu động từ API
    final menuAsync = ref.watch(menuUserProvider('vi'));

    return Scaffold(
      backgroundColor: Colors.white,
      body: menuAsync.when(
        loading: () => const LoadingWidget(),
        error: (e, _) => Center(child: Text('Lỗi menu: $e')),
        data: (all) {
          // Gom nhóm tự động
          final grouped = groupBy(all, (MenuModel m) => m.groupNameVi.trim());

          // Lấy 2 nhóm theo tên hiển thị bạn đang dùng
          final congDanSo = (grouped['Công dân số'] ?? <MenuModel>[]);
          final chinhQuyenSo = (grouped['Chính quyền số'] ?? <MenuModel>[]);

          // Cắt top 11 cho Công dân số như logic cũ
          final citizenTopItems = congDanSo.take(11).toList();
          final govItems = chinhQuyenSo.take(7).toList();

          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Container(
                  padding: const EdgeInsets.fromLTRB(16, 40, 16, 12),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(20),
                      bottomRight: Radius.circular(20),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Logo & avatar row
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {
                              if (profile == null) {
                                context.push('/login');
                              } else {
                                context.push('/profile');
                              }
                            },
                            child: Row(
                              children: [
                                const CircleAvatar(
                                  radius: 20,
                                  backgroundImage: AssetImage(
                                    'assets/icons/logo_phuongcauonglanh.png',
                                  ),
                                ),
                                const SizedBox(width: 8),
                                SizedBox(
                                  width: 200,
                                  child: Text(
                                    displayName,
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                      color: Colors.blue,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              // TODO: điều hướng thông báo
                              // context.push('/notifications');
                            },
                            child: const CircleAvatar(
                              radius: 20,
                              backgroundImage: AssetImage(
                                'assets/icons/notification.png',
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      SizedBox(
                        height: 20,
                        child: Marquee(
                          text:
                              'Phường Cầu Ông Lãnh - Dấu ấn mới - Diện mạo mới. Đột phá bằng công nghệ, vững bước cùng chuyển đổi số.',
                          style: const TextStyle(
                            fontSize: 13,
                            color: Colors.black87,
                          ),
                          scrollAxis: Axis.horizontal,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          blankSpace: 50.0,
                          velocity: 30.0,
                          pauseAfterRound: const Duration(seconds: 1),
                          startPadding: 10.0,
                        ),
                      ),
                      const SizedBox(height: 4),

                      // Location & Date
                      Row(
                        children: [
                          const Icon(
                            Icons.location_on_outlined,
                            size: 18,
                            color: Colors.grey,
                          ),
                          const SizedBox(width: 4),
                          const Text("Thành phố Hồ Chí Minh"),
                          const Spacer(),
                          const Icon(
                            Icons.calendar_today,
                            size: 16,
                            color: Colors.grey,
                          ),
                          const SizedBox(width: 4),
                          Text(formatDate(DateTime.now().toString())),
                        ],
                      ),

                      const SizedBox(height: 4),

                      // Weather and AQI (giữ nguyên)
                      // weatherAsync.when(
                      //   data: (weather) => aqiAsync.when(
                      //     data: (aqi) => Row(
                      //       children: [
                      //         Image.network(
                      //           "https://openweathermap.org/img/wn/${weather.icon}@2x.png",
                      //           width: 40,
                      //           height: 40,
                      //           errorBuilder: (_, __, ___) => const Icon(
                      //             Icons.wb_cloudy,
                      //             size: 28,
                      //             color: Colors.orange,
                      //           ),
                      //         ),
                      //         const SizedBox(width: 8),
                      //         Text(
                      //           "${weather.temp.toStringAsFixed(1)}°C\n${weather.description}",
                      //           style: const TextStyle(fontSize: 13),
                      //         ),
                      //         const Spacer(),
                      //         ConstrainedBox(
                      //           constraints: const BoxConstraints(
                      //             maxWidth: 160,
                      //           ),
                      //           child: Container(
                      //             padding: const EdgeInsets.symmetric(
                      //               horizontal: 8,
                      //               vertical: 4,
                      //             ),
                      //             decoration: BoxDecoration(
                      //               color: aqi.qualityColor,
                      //               borderRadius: BorderRadius.circular(8),
                      //             ),
                      //             child: Column(
                      //               crossAxisAlignment:
                      //                   CrossAxisAlignment.start,
                      //               children: [
                      //                 const Text(
                      //                   "Chất lượng",
                      //                   style: TextStyle(
                      //                     color: Colors.white,
                      //                     fontSize: 12,
                      //                   ),
                      //                 ),
                      //                 Text(
                      //                   "Không khí: ${aqi.qualityText}",
                      //                   style: const TextStyle(
                      //                     color: Colors.white,
                      //                     fontSize: 12,
                      //                   ),
                      //                   maxLines: 1,
                      //                   overflow: TextOverflow.ellipsis,
                      //                 ),
                      //                 Text(
                      //                   aqi.aqi.toString(),
                      //                   style: const TextStyle(
                      //                     color: Colors.white,
                      //                     fontWeight: FontWeight.bold,
                      //                     fontSize: 14,
                      //                   ),
                      //                 ),
                      //               ],
                      //             ),
                      //           ),
                      //         ),
                      //       ],
                      //     ),
                      //     loading: () => const LoadingWidget(),
                      //     error: (e, _) => const Text(""),
                      //   ),
                      //   loading: () => const LoadingWidget(),
                      //   error: (e, _) => const Text(""),
                      // ),
                    ],
                  ),
                ),

                const SizedBox(height: 4),

                // 🔹 Tiêu đề
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Nổi bật",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      Text("Xem tất cả", style: TextStyle(color: Colors.blue)),
                    ],
                  ),
                ),

                const SizedBox(height: 4),

                // 🔹 Danh sách ngang các ảnh (giữ nguyên assets của bạn)
                SizedBox(
                  height: 140,
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    scrollDirection: Axis.horizontal,
                    itemCount: festImages.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (context, index) {
                      return ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.asset(
                          festImages[index],
                          width: 360,
                          fit: BoxFit.cover,
                        ),
                      );
                    },
                  ),
                ),

                const SizedBox(height: 4),

                // Nền trống đồng + 2 section dưới
                Stack(
                  children: [
                    Positioned.fill(
                      child: Opacity(
                        opacity: 0.25,
                        child: Image.asset(
                          'assets/images/trongdongbg.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),

                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 4),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                "Công dân số",
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                              GestureDetector(
                                onTap: () => context.go('/khampha'),
                                child: const Text(
                                  "Khám phá",
                                  style: TextStyle(
                                    color: Colors.blue,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        // 👉 Thay bằng GridMenuWidget (top 11)
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: GridMenuWidget(items: citizenTopItems),
                        ),

                        const SizedBox(height: 10),
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 16),
                          child: Text(
                            'Chính quyền số',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        const SizedBox(height: 4),

                        // 👉 Thay bằng GridMenuWidget (full)
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: GridMenuWidget(items: govItems),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
