import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/shared/menu/menu_provider.dart';
import '../../../../core/widgets/loading_widget.dart';

class TraCuuPage extends ConsumerWidget {
  const TraCuuPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final itemsAsync = ref.watch(menuTracuuProvider('vi'));

    return Scaffold(
      backgroundColor: Colors.white,

      body: Stack(
        children: [
          // Nền trống đồng
          Positioned.fill(
            child: Opacity(
              opacity: 0.25,
              child: Image.asset(
                'assets/images/trongdongbg.png',
                fit: BoxFit.cover,
              ),
            ),
          ),

          // Header tùy biến có nút Back
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 90,
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(20),
                  bottomRight: Radius.circular(20),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 6,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: SafeArea(
                bottom: false,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Row(
                    children: [
                      // nút Back
                      IconButton(
                        icon: const Icon(
                          Icons.arrow_back_ios_new_rounded,
                          color: Colors.blue,
                        ),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                      // tiêu đề căn giữa
                      const Expanded(
                        child: Text(
                          'Tra cứu thông tin',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: Colors.blue,
                          ),
                        ),
                      ),
                      // khoảng trống cân đối với IconButton bên trái
                      const SizedBox(width: 48),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // Nội dung cuộn
          Positioned.fill(
            top: 100,
            child: SafeArea(
              top: false,
              child: itemsAsync.when(
                data: (items) {
                  return ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 2, 16, 8),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 2),
                    itemBuilder: (context, index) {
                      final item = items[index];
                      return InkWell(
                        onTap: () {
                          item.onTap(context);
                        },
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.8),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: Colors.grey.shade200),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.05),
                                blurRadius: 4,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Row(
                            children: [
                              Image.network(
                                item.iconUrl,
                                width: 32,
                                height: 32,
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  item.labelVi,
                                  style: const TextStyle(fontSize: 16),
                                ),
                              ),
                              const Icon(
                                Icons.chevron_right,
                                color: Colors.grey,
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
                loading: () => const LoadingWidget(),
                error: (e, _) => Center(child: Text('Lỗi tải dữ liệu: $e')),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
