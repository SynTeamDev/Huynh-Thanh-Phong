import 'package:chinhquyen_app/core/widgets/loading_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:collection/collection.dart'; // 👈 để dùng groupBy

import '../../../../core/shared/menu/grid_menu_widget.dart';
import '../../../../core/shared/menu/menu_model.dart';
import '../../../../core/shared/menu/menu_provider.dart';

class KhamPhaPage extends ConsumerWidget {
  const KhamPhaPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final menuAsync = ref.watch(menuUserProvider('vi'));

    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // Nền trống đồng
          Positioned.fill(
            child: Opacity(
              opacity: 0.25,
              child: Image.asset(
                'assets/images/trongdongbg.png',
                fit: BoxFit.cover,
              ),
            ),
          ),

          // Nền tiêu đề
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 90,
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(20),
                  bottomRight: Radius.circular(20),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 6,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: SafeArea(
                bottom: false,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Row(
                    children: [
                      // nút Back
                      IconButton(
                        icon: const Icon(
                          Icons.arrow_back_ios_new_rounded,
                          color: Colors.blue,
                        ),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                      // tiêu đề căn giữa
                      const Expanded(
                        child: Text(
                          'Khám phá',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: Colors.blue,
                          ),
                        ),
                      ),
                      // khoảng trống cân đối với IconButton bên trái
                      const SizedBox(width: 48),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // Nội dung
          Positioned.fill(
            top: 100,
            child: SafeArea(
              top: false,
              child: menuAsync.when(
                loading: () => const LoadingWidget(),
                error: (e, _) => Center(child: Text('Lỗi: $e')),
                data: (all) {
                  // Gom nhóm tự động theo groupNameVi
                  final grouped = groupBy(
                    all,
                    (MenuModel m) => m.groupNameVi.trim(),
                  );

                  return SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: grouped.entries.map((entry) {
                        final groupName = entry.key;
                        final items = entry.value;

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 8),
                            Text(
                              groupName,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            const SizedBox(height: 12),
                            _card(
                              constraintsChild: GridMenuWidget(items: items),
                            ),
                            const SizedBox(height: 8),
                          ],
                        );
                      }).toList(),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _card({required Widget constraintsChild}) => Container(
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.2),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Colors.grey.shade300),
      boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.1),
          blurRadius: 4,
          offset: const Offset(0, 2),
        ),
      ],
    ),
    padding: const EdgeInsets.all(2),
    child: constraintsChild,
  );
}
