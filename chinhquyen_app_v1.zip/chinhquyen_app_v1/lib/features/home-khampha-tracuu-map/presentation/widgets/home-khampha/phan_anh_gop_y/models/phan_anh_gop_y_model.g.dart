// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'phan_anh_gop_y_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$PhanAnhGopYModelImpl _$$PhanAnhGopYModelImplFromJson(
  Map<String, dynamic> json,
) => _$PhanAnhGopYModelImpl(
  i_tieu_de: json['i_tieu_de'] as String?,
  i_noi_dung: json['i_noi_dung'] as String?,
  i_dia_diem: json['i_dia_diem'] as String?,
  i_dinh_kem: json['i_dinh_kem'] as String?,
);

Map<String, dynamic> _$$PhanAnhGopYModelImplToJson(
  _$PhanAnhGopYModelImpl instance,
) => <String, dynamic>{
  'i_tieu_de': instance.i_tieu_de,
  'i_noi_dung': instance.i_noi_dung,
  'i_dia_diem': instance.i_dia_diem,
  'i_dinh_kem': instance.i_dinh_kem,
};
