import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../../../core/network/api_provider.dart';
import '../../../../../../../../core/utils/date_helper.dart';
import '../../../../../../../auth/presentation/providers/profile_provider.dart';

//! Provider quản lý tháng đang hiển thị
final calendarProvider = StateNotifierProvider<CalendarNotifier, DateTime>((
  ref,
) {
  return CalendarNotifier();
});

class CalendarNotifier extends StateNotifier<DateTime> {
  CalendarNotifier({DateTime? initialDate})
    : super(initialDate ?? DateTime.now());

  void nextMonth() {
    state = DateTime(state.year, state.month + 1);
  }

  void previousMonth() {
    state = DateTime(state.year, state.month - 1);
  }

  void setMonthYear(DateTime date) {
    state = date;
  }
}

//! ✅ Ngày đang được chọn (có thể null)
final selectedDateProvider = StateProvider<DateTime?>((ref) => null);

//! State lấy danh sách
final lichcuochopListProvider =
    StateNotifierProvider<LichCuocHopListNotifier, List<Map<String, dynamic>>>(
      (ref) => LichCuocHopListNotifier(ref),
    );

//! Api lazy loading
class LichCuocHopListNotifier
    extends StateNotifier<List<Map<String, dynamic>>> {
  LichCuocHopListNotifier(this.ref) : super([]) {
    fetchLichCuocHopList(); // mặc định: theo tháng hiện tại
  }

  final Ref ref;
  int _pageIndex = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  DateTime? _currentDateFilter; // 👈 nếu != null sẽ load theo ngày

  Future<void> fetchLichCuocHopList() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;

    final username = getUsernameRef(ref);
    final displayedMonth = ref.read(calendarProvider);
    final y = displayedMonth.year;
    final m = displayedMonth.month;

    final res = await ref
        .read(apiServiceProvider)
        .fetchLichCuocHop(
          pageIndex: _pageIndex,
          username_current: username,
          year: y,
          month: m,
          date: _currentDateFilter, // 👈 truyền ngày nếu có
        );

    final items = List<Map<String, dynamic>>.from(res['items'] as List);
    final days = (res['days'] as List).cast<int>();

    if (items.isEmpty) {
      _hasMore = false;
    } else {
      state = [...state, ...items];
      _pageIndex++;
    }

    // Cập nhật cache ngày của tháng đang xem (server trả full days)
    final key = '$y-${m.toString().padLeft(2, '0')}';
    ref.read(meetingDaysCacheProvider.notifier).update((cache) {
      final next = Map<String, Set<int>>.from(cache);
      next[key] = days.toSet();
      return next;
    });

    _isLoading = false;
  }

  // Gọi khi user bấm chọn 1 ngày
  Future<void> loadByDay(DateTime date) async {
    _currentDateFilter = DateTime(date.year, date.month, date.day);
    _pageIndex = 0;
    _hasMore = true;
    state = [];
    await fetchLichCuocHopList();
  }

  // Gọi khi đổi tháng (hoặc bỏ chọn ngày)
  Future<void> loadByMonth(DateTime month) async {
    _currentDateFilter = null;
    _pageIndex = 0;
    _hasMore = true;
    state = [];
    await fetchLichCuocHopList();
  }
}

final meetingDaysCacheProvider = StateProvider<Map<String, Set<int>>>(
  (_) => {},
);

final meetingDaysInMonthProvider = Provider.family<Set<int>, DateTime>((
  ref,
  month,
) {
  final cache = ref.watch(meetingDaysCacheProvider);
  final key = '${month.year}-${month.month.toString().padLeft(2, '0')}';

  // 1) Ưu tiên dữ liệu cache từ server
  final cached = cache[key];
  if (cached != null && cached.isNotEmpty) return cached;

  // 2) Fallback (tuỳ chọn): suy ra tạm từ các item đã load (nếu có)
  final all = ref.read(lichcuochopListProvider);
  final fallback = <int>{};
  for (final e in all) {
    final d = parseDate(e['ngay_hop']);
    if (d != null && d.year == month.year && d.month == month.month) {
      fallback.add(d.day);
    }
  }
  return fallback;
});
