import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../../../core/network/api_provider.dart';
import '../../../../../../../../core/widgets/custom_appbar_widget.dart';
import '../../../../../../../../core/widgets/custom_snackbar_widget.dart';
import '../../../../../../../../core/widgets/form/combobox_field_widget.dart';
import '../../../../../../../../core/widgets/form/date_field_widget.dart';
import '../../../../../../../../core/widgets/form/input_field_widget.dart';
import '../../../../../../../../core/widgets/form/vi_date_picker_widget.dart';
import '../../../../../../../../core/widgets/loading_widget.dart';
import '../../../../../../../auth/presentation/providers/profile_provider.dart';
import '../../models/dv_hanh_chinh_cong_model.dart';

class DVHanhChinhCongAdd extends ConsumerStatefulWidget {
  const DVHanhChinhCongAdd({super.key});

  @override
  ConsumerState<DVHanhChinhCongAdd> createState() => _DVHanhChinhCongAddState();
}

class _DVHanhChinhCongAddState extends ConsumerState<DVHanhChinhCongAdd> {
  final _formKey = GlobalKey<FormState>();
  final GlobalKey comboboxKey = GlobalKey();
  bool _isSaving = false;
  bool hasError = false;
  final ScrollController _scrollController = ScrollController();
  bool _showScrollToTopButton = false;

  String? _ma_hccong;
  int? _status;

  String? _stt, _tg, _tgdkbd, _tgdkkt;
  final TextEditingController _sttController = TextEditingController();
  final TextEditingController _tgController = TextEditingController();
  final TextEditingController _tgdkbdController = TextEditingController();
  final TextEditingController _tgdkktController = TextEditingController();

  DateTime selectedDate = DateTime.now(); // ngày mặc định hiện tại
  Future<void> pickDate() async {
    final picked = await showCustomVietnameseDatePicker(
      context: context,
      initialDate: selectedDate,
    );
    if (picked != null) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(() {
      if (_scrollController.offset >= 300 && !_showScrollToTopButton) {
        setState(() => _showScrollToTopButton = true);
      } else if (_scrollController.offset < 300 && _showScrollToTopButton) {
        setState(() => _showScrollToTopButton = false);
      }
    });

    Future.microtask(() async {
      _status = await getDefaultComboboxCode('dmttct_HC1', ref);
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _sttController.dispose();
    _tgController.dispose();
    _tgdkbdController.dispose();
    _tgdkktController.dispose();
    super.dispose();
  }

  void focusAndScrollTo(FocusNode focusNode) {
    if (!focusNode.hasPrimaryFocus) {
      focusNode.requestFocus();
    }
    if (focusNode.context != null && focusNode.context!.mounted) {
      Scrollable.ensureVisible(
        focusNode.context!,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    }
  }

  void scrollToCombobox(GlobalKey key) {
    if (key.currentContext != null) {
      Scrollable.ensureVisible(
        key.currentContext!,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    }
  }

  Future<void> _submitForm() async {
    if (_ma_hccong?.isEmpty ?? true) {
      showSnack(context, '❌ Chọn hạng mục hành chính công!');
      setState(() {
        hasError = true; // ✅ Bật cờ báo lỗi
      });
      scrollToCombobox(comboboxKey); // ✅ Cuộn tới combobox bị lỗi
      return;
    }

    setState(() => _isSaving = true);
    try {
      final request = DVHanhChinhCongModel(
        i_ma_hccong: _ma_hccong,
        i_ngay_ct: selectedDate,
        i_status: _status,
        i_user_id_current: getUserId(ref),
      );

      final success = await ref
          .read(apiServiceProvider)
          .insertDVHanhChinhCong(request);
      if (!mounted) return;

      if (success) {
        Navigator.pop(context, true);
      } else {
        showSnack(context, '❌ Gửi ý kiến thất bại');
      }
    } catch (e) {
      showSnack(context, '❌ Lỗi: $e');
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBarWidget(title: "Phiếu mới - hành chính công"),
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scrollbar(
          controller:
              _scrollController, // ✅ Gắn controller để bấm nút scroll về top
          thumbVisibility: true,
          thickness: 6,
          radius: const Radius.circular(10),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _formKey,
              child: ListView(
                controller:
                    _scrollController, // ✅ Gắn controller để bấm nút scroll về top
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: DateFieldWidget(
                          label: 'Ngày chứng từ',
                          date: selectedDate,
                          onTap: pickDate,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ComboboxFieldWidget(
                          label: 'Trạng thái',
                          tableName: 'dmttct_HC1',
                          selectedValue: _status?.toString(),
                          onChanged: (value) {
                            setState(() {
                              _status = int.tryParse(value!);
                            });
                          },

                          isCode: false,
                          // hasError: hasError,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  ComboboxFieldWidget(
                    label: 'Chọn hạng mục hành chính công',
                    tableName: 'dmhccong',
                    selectedValue: _ma_hccong,
                    showRequiredAsterisk: true,
                    onChanged: (value) async {
                      if (value == null || value.isEmpty) return;

                      setState(() {
                        _ma_hccong = value;
                        hasError = false;
                      });

                      // gọi proc
                      final rows = await ref
                          .read(apiServiceProvider)
                          .fetch_st_QueryHCCONG(ma_hccong: value);

                      if (!mounted) return;

                      // lấy !stt (fallback các cột khác nếu cần)
                      final row = rows.isNotEmpty ? rows.first : null;
                      final dynamic v = row?['!stt'];
                      final dynamic v1 = row?['!thoi_gian'];
                      final dynamic v2 = row?['!tg_dukienbd'];
                      final dynamic v3 = row?['!tg_dukienkt'];

                      final String sttStr = v?.toString() ?? '';
                      final String sttTG = v1?.toString() ?? '';
                      final String sttTGDKBD = v2?.toString() ?? '';
                      final String sttTGDKKT = v3?.toString() ?? '';

                      setState(() {
                        _sttController.text = sttStr;
                        _tgController.text = sttTG;
                        _tgdkbdController.text = sttTGDKBD;
                        _tgdkktController.text = sttTGDKKT;

                        _stt = sttStr;
                        _tg = sttTG;
                        _tgdkbd = sttTGDKBD;
                        _tgdkkt = sttTGDKKT;
                      });
                    },
                    isCode: true,
                    hasError: hasError, // ✅ Truyền trạng thái lỗi
                  ),

                  const SizedBox(height: 5),
                  InputFieldWidget(
                    label: 'Số thứ tự',
                    hintText: '--',
                    controller: _sttController,
                    readOnly: true,
                    enableClear: false,
                    showRequiredAsterisk: true,
                    onChanged: (value) {
                      setState(() => _stt = value);
                    },
                  ),
                  const SizedBox(height: 5),
                  InputFieldWidget(
                    label: 'Thời gian',
                    hintText: '--',
                    controller: _tgController,
                    readOnly: true,
                    enableClear: false,
                    showRequiredAsterisk: true,
                    onChanged: (value) {
                      setState(() => _tg = value);
                    },
                  ),
                  const SizedBox(height: 5),
                  InputFieldWidget(
                    label: 'TG dự kiến bắt đầu',
                    hintText: '--',
                    controller: _tgdkbdController,
                    readOnly: true,
                    enableClear: false,
                    showRequiredAsterisk: true,
                    onChanged: (value) {
                      setState(() => _tgdkbd = value);
                    },
                  ),
                  const SizedBox(height: 5),
                  InputFieldWidget(
                    label: 'TG dự kiến kết thúc',
                    hintText: '--',
                    controller: _tgdkktController,
                    readOnly: true,
                    enableClear: false,
                    showRequiredAsterisk: true,
                    onChanged: (value) {
                      setState(() => _tgdkkt = value);
                    },
                  ),

                  const SizedBox(height: 8),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size(double.infinity, 48),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      backgroundColor: Colors.blueAccent,
                    ),
                    onPressed: _onSaveClick,
                    child: _isSaving
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: LoadingWidget(),
                          )
                        : const Text(
                            'Nhận',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _onSaveClick() {
    if (_isSaving) return;
    _submitForm();
  }
}
