import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../../../core/shared/base_filter.dart';
import '../../../../../../../../core/widgets/form/combobox_field_widget.dart';

class DVHanhChinhCongFilter extends BaseFilter<(DateTime, DateTime, String?)> {
  final (String?,)? initialValues;

  const DVHanhChinhCongFilter({
    super.key,
    required super.initialFromDate,
    required super.initialToDate,
    this.initialValues,
    // ẩn ngày tháng
    //super.showDateFields = false,
  });

  @override
  ConsumerState<DVHanhChinhCongFilter> createState() =>
      _DVHanhChinhCongFilterConsumerState();
}

class _DVHanhChinhCongFilterConsumerState
    extends
        BaseFilterState<(DateTime, DateTime, String?), DVHanhChinhCongFilter> {
  String? ma_hccong;

  @override
  void initState() {
    super.initState();

    final initial = widget.initialValues;
    if (initial != null) {
      ma_hccong = initial.$1;
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  List<Widget> buildFilterFields() {
    return [
      ComboboxFieldWidget(
        label: 'Mã hành chính công',
        tableName: 'dmhccong',
        selectedValue: ma_hccong,
        onChanged: (value) {
          setState(() {
            ma_hccong = value;
          });
        },
        isCode: false,
      ),
    ];
  }

  @override
  (DateTime, DateTime, String?) getFilterResult() {
    return (fromDate, toDate, ma_hccong);
  }
}
