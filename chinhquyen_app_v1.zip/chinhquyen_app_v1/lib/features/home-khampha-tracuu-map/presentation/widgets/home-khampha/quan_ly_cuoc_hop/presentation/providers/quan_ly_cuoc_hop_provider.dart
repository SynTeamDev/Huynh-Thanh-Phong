import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../../../core/network/api_provider.dart';

//! State lưu giá trị filter
final quanlycuochopFilterStateProvider =
    StateProvider<(DateTime, DateTime, String?, String?, String?)?>(
      (ref) => null,
    );
//! State lấy danh sách
final quanlycuochopListProvider =
    StateNotifierProvider<
      QuanLyCuocHopListNotifier,
      List<Map<String, dynamic>>
    >((ref) => QuanLyCuocHopListNotifier(ref));

//! Api lazy loading
class QuanLyCuocHopListNotifier
    extends StateNotifier<List<Map<String, dynamic>>> {
  QuanLyCuocHopListNotifier(this.ref) : super([]) {
    fetchQLCuocHopList();
  }

  final Ref ref;
  int _pageIndex = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  Future<void> fetchQLCuocHopList() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;

    final filter = ref.read(quanlycuochopFilterStateProvider);
    final (ngay_ct1, ngay_ct2, ma_lcuochop, dia_chi, status) =
        filter ?? (null, null, null, null, null);

    final result = await ref
        .read(apiServiceProvider)
        .fetchQLCuocHop(
          pageIndex: _pageIndex,
          ngay_ct1: ngay_ct1,
          ngay_ct2: ngay_ct2,
          ma_lcuochop: ma_lcuochop,
          dia_chi: dia_chi,
          status: status,
        );

    if (result.isEmpty) {
      _hasMore = false;
    } else {
      state = [...state, ...result];
      _pageIndex++;
    }

    _isLoading = false;
  }
}
