import 'package:chinhquyen_app/core/widgets/custom_appbar_widget.dart';
import 'package:chinhquyen_app/features/home-khampha-tracuu-map/presentation/widgets/home-khampha/quan_ly_cuoc_hop/presentation/providers/quan_ly_cuoc_hop_provider.dart'
    show quanlycuochopFilterStateProvider, quanlycuochopListProvider;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:ionicons/ionicons.dart';

import '../../../../../../../../core/utils/date_helper.dart';
import '../../../../../../../../core/utils/delay_btn_helper.dart';
import '../../../../../../../../core/widgets/custom_snackbar_widget.dart';
import '../../../../../../../../core/widgets/form/label_value_row.dart';
import '../../../../../../../../core/widgets/form/title_label_widget.dart';
import '../widgets/expandable_action_menu.dart';
import '../widgets/quan_ly_cuoc_hop_filter.dart';
import '../widgets/single_action_button.dart';

class QuanLyCuocHopPage extends ConsumerStatefulWidget {
  const QuanLyCuocHopPage({super.key, this.title = ''});
  final String title;

  @override
  ConsumerState<QuanLyCuocHopPage> createState() => _QuanLyCuocHopPageState();
}

class _QuanLyCuocHopPageState extends ConsumerState<QuanLyCuocHopPage> {
  final ScrollController _scrollController = ScrollController();

  DateTime? _ngayCt1, _ngayCt2;
  String? _ma_lcuochop, _dia_chi, _status;

  int? selectedIndex; // dòng đang chọn

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);

    _initDatesToDefault();
    final filter = ref.read(quanlycuochopFilterStateProvider);
    if (filter != null) _applyFilterFromTuple(filter);
  }

  void _initDatesToDefault() {
    final now = DateTime.now();
    _ngayCt1 = DateTime(now.year, now.month - 6, 1);
    _ngayCt2 = DateTime(now.year, now.month + 2, 0);
  }

  void _applyFilterFromTuple(
    (DateTime, DateTime, String?, String?, String?) filter,
  ) {
    final (ngayCt1, ngayCt2, ma_lcuochop, dia_chi, status) = filter;
    _ngayCt1 = ngayCt1;
    _ngayCt2 = ngayCt2;

    _ma_lcuochop = ma_lcuochop;
    _dia_chi = dia_chi;
    _status = status;
  }

  Future<void> _onRefreshPressed() async {
    if (!GlobalButtonDisableHelper.isDisabled) {
      GlobalButtonDisableHelper.disableTemporarily(seconds: 1);
      setState(() {
        _initDatesToDefault();
        _ma_lcuochop = _dia_chi = _status = null;
      });
      ref.read(quanlycuochopFilterStateProvider.notifier).state = null;

      // ✅ Quan trọng: trigger lại gọi API
      ref.invalidate(quanlycuochopListProvider);
      selectedIndex = null;
    }
  }

  Future<void> _onFilterPressed() async {
    if (!GlobalButtonDisableHelper.isDisabled) {
      GlobalButtonDisableHelper.disableTemporarily(seconds: 1);
      final result = await QLCuocHopFilter(
        initialFromDate: _ngayCt1 ?? DateTime.now(),
        initialToDate: _ngayCt2 ?? DateTime.now(),
        initialValues: (_ma_lcuochop, _dia_chi, _status),
      ).show(context);

      if (result != null) {
        ref.read(quanlycuochopFilterStateProvider.notifier).state = result;
        setState(() => _applyFilterFromTuple(result));
        // ✅ Quan trọng: trigger lại gọi API
        ref.invalidate(quanlycuochopListProvider);
      }
    }
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 100) {
      ref.read(quanlycuochopListProvider.notifier).fetchQLCuocHopList();
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final QLCuocHopList = ref.watch(quanlycuochopListProvider);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBarWidget(
        title: widget.title,
        actions: [
          IconButton(
            icon: const Icon(Ionicons.refresh, color: Colors.blue),
            onPressed: () {
              _onRefreshPressed();
            },
          ),
          IconButton(
            icon: const Icon(Ionicons.search_outline, color: Colors.blue),
            onPressed: () {
              _onFilterPressed();
            },
          ),
        ],
      ),
      body: Scrollbar(
        controller: _scrollController,
        thumbVisibility: true,
        thickness: 6,
        radius: const Radius.circular(10),
        child: ListView.builder(
          controller: _scrollController,
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
          itemCount: QLCuocHopList.length,
          itemBuilder: (context, index) {
            final isSelected = index == selectedIndex;
            final item = QLCuocHopList[index];
            return GestureDetector(
              onTap: () {
                setState(() {
                  selectedIndex = index;
                });
              },
              child: Container(
                margin: const EdgeInsets.only(bottom: 2),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.8),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isSelected ? Colors.blue : Colors.transparent,
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.03),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TitleLabelWidget(
                      title: 'Mã cuộc họp - #${item['ma_cuochop'] ?? ''}',
                    ),
                    const Divider(),
                    LabelValueRow(
                      label: 'Ngày họp:',
                      value: formatDate(item['ngay_hop']),
                    ),
                    LabelValueRow(
                      label: 'Loại cuộc họp:',
                      value: item['ten_lcuochop'] ?? '',
                    ),

                    LayoutBuilder(
                      builder: (context, constraints) {
                        final maxW =
                            constraints.maxWidth *
                            0.80; // pill tối đa 97% chiều ngang
                        return Row(
                          children: [
                            const Text(
                              'Chủ đề: ',
                              style: TextStyle(
                                fontSize: 13,
                                color: Colors.grey,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const Spacer(),
                            ConstrainedBox(
                              constraints: BoxConstraints(maxWidth: maxW),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 6,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.grey.shade300,
                                  borderRadius: BorderRadius.circular(8),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.green.withOpacity(0.12),
                                      blurRadius: 6,
                                      offset: const Offset(0, 2),
                                    ),
                                  ],
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Flexible(
                                      child: Text(
                                        item['ten_cuochop'] ?? '',
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          color: Colors.black87,
                                          fontSize: 12.5,
                                          fontWeight: FontWeight.w600,
                                          height: 1.1,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        );
                      },
                    ),

                    LabelValueRow(
                      label: 'Chủ trì:',
                      value: item['ds_chutri'] ?? '',
                      maxHeight: 36,
                    ),
                    LabelValueRow(
                      label: 'Danh sách người tham gia: ',
                      value: item['ds_nguoithamgia'] ?? '',
                      maxHeight: 36,
                    ),
                    const SizedBox(height: 2),

                    LayoutBuilder(
                      builder: (context, constraints) {
                        final maxW =
                            constraints.maxWidth *
                            0.80; // pill tối đa 97% chiều ngang
                        return Row(
                          children: [
                            const Text(
                              'Giờ bắt đầu - kết thúc: ',
                              style: TextStyle(
                                fontSize: 13,
                                color: Colors.grey,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const Spacer(),
                            ConstrainedBox(
                              constraints: BoxConstraints(maxWidth: maxW),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 6,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.grey.shade300,
                                  borderRadius: BorderRadius.circular(8),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.green.withOpacity(0.12),
                                      blurRadius: 6,
                                      offset: const Offset(0, 2),
                                    ),
                                  ],
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Flexible(
                                      child: Text(
                                        '${item['gio_bd'] ?? ''} - ${item['gio_kt'] ?? ''}',
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          color: Colors.black87,
                                          fontSize: 12.5,
                                          fontWeight: FontWeight.w600,
                                          height: 1.1,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        );
                      },
                    ),

                    LabelValueRow(
                      label: '',
                      labelWidget: RichText(
                        textAlign: TextAlign.left,
                        text: TextSpan(
                          style: const TextStyle(fontSize: 13),
                          children: [
                            const TextSpan(
                              text: 'Địa điểm: ',
                              style: TextStyle(
                                color: Colors.grey, // 👈 Chữ xám
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            TextSpan(
                              text: item['dia_chi'] ?? '',
                              style: const TextStyle(
                                color: Colors.black87,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      value: '',
                      valueWidget: Align(
                        alignment: Alignment.centerRight,
                        child: Row(
                          mainAxisSize: MainAxisSize
                              .min, // ✅ không chiếm full width -> đỡ tràn
                          children: [
                            const Text(
                              'Trạng thái: ',
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Flexible(
                              // ✅ cho phép badge co lại trong ô bên phải
                              child: _StatusBadgeCompact(
                                status: item['status'].toString(),
                              ),
                            ),
                          ],
                        ),
                      ),

                      maxHeight: 32,
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),

      floatingActionButton: ExpandableActionMenu(
        onAdd: _onAdd,
        onEdit: _onEdit,
        onDelete: _onDelete,
        //onApprove: _onApprove, // có thể bỏ
        //showApprove: true, // hoặc false nếu không cần nút Duyệt
      ),

      // floatingActionButton: SingleActionButton(
      //   onPressedAsync: _onAdd, // 👈 truyền thẳng hàm async
      //   child: const Icon(Icons.add, size: 28, color: Colors.black87),
      // ),
      // floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }

  Future<void> _onAdd() async {
    showSnack(context, 'Đang phát triển!');
    // final result = await context.push('/qlcuochopAdd');
    // if (result == true) {
    //   _onRefreshPressed(); // ✅ Làm mới sau khi thêm thành công
    // }
  }

  Future<void> _onEdit() async {
    showSnack(context, 'Đang phát triển!');
    // if (selectedIndex == null) {
    //   showSnack(context, 'Hãy chọn 1 phiếu để sửa');
    //   return;
    // }
  }

  Future<void> _onDelete() async {
    showSnack(context, 'Đang phát triển!');
  }

  //Future<void> _onApprove() async {}
}

class _StatusBadgeCompact extends StatelessWidget {
  const _StatusBadgeCompact({required this.status});
  final String status;

  @override
  Widget build(BuildContext context) {
    // map status -> text & color
    String text;
    Color color;
    switch (status) {
      case '0':
        text = 'Không sử dụng';
        color = Colors.red;
        break;
      case '1':
        text = 'Còn sử dụng';
        color = Colors.green;
        break;
      default:
        text = 'Không xác định';
        color = Colors.grey;
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        // Giới hạn tối đa theo không gian thực tế của cột phải
        final maxW = constraints.maxWidth; // cột phải
        final cap = maxW * 0.999; // badge tối đa 60% ô phải (tuỳ chỉnh)

        return ConstrainedBox(
          constraints: BoxConstraints(maxWidth: cap),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis, // ✅ cắt gọn
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        );
      },
    );
  }
}
