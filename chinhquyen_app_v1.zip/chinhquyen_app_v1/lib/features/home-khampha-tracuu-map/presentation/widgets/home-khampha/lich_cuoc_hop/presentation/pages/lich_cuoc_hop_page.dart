import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../../../../../../core/widgets/custom_appbar_widget.dart';
import '../../../../../../../../core/widgets/form/label_value_row.dart';
import '../providers/calendar_provider.dart';
import '../widgets/month_year_picker_dialog.dart';

class LichCuocHopPage extends ConsumerStatefulWidget {
  const LichCuocHopPage({super.key, this.title = ''});
  final String title;

  @override
  ConsumerState<LichCuocHopPage> createState() => _LichCuocHopPageState();
}

class _LichCuocHopPageState extends ConsumerState<LichCuocHopPage> {
  final ScrollController _scrollController = ScrollController();
  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
    // ✅ Mỗi khi mở trang, set tháng hiện tại
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(calendarProvider.notifier).setMonthYear(DateTime.now());
    });

    // Future.microtask(() {
    //   ref.invalidate(lichcuochopListProvider);
    // });
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 100) {
      ref.read(lichcuochopListProvider.notifier).fetchLichCuocHopList();
    }
  }

  List<Widget> _buildCalendar({
    required DateTime displayedMonth,
    required DateTime? selectedDate,
    required Set<int> meetingDays, // <-- thêm
    required void Function(DateTime date) onSelect,
  }) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    final firstDayOfMonth = DateTime(
      displayedMonth.year,
      displayedMonth.month,
      1,
    );
    final lastDayOfMonth = DateTime(
      displayedMonth.year,
      displayedMonth.month + 1,
      0,
    );
    final startWeekday = firstDayOfMonth.weekday % 7; // CN = 0
    final totalDays = lastDayOfMonth.day;

    final dayWidgets = <Widget>[];

    for (int i = 0; i < startWeekday; i++) {
      dayWidgets.add(Container());
    }

    for (int i = 1; i <= totalDays; i++) {
      final date = DateTime(displayedMonth.year, displayedMonth.month, i);
      final isToday = date == today;
      final isSelected =
          selectedDate != null &&
          date.year == selectedDate.year &&
          date.month == selectedDate.month &&
          date.day == selectedDate.day;

      final hasMeeting = meetingDays.contains(i);

      // Màu nền/chữ
      Color bg, fg;
      if (isSelected) {
        bg = Colors.deepPurpleAccent;
        fg = Colors.white;
      } else if (isToday) {
        bg = Colors.orangeAccent;
        fg = Colors.black87;
      } else {
        bg = Colors.blue.shade300;
        fg = Colors.black87;
      }

      dayWidgets.add(
        Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(8),
            onTap: () => onSelect(date),
            child: Container(
              margin: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: bg,
                borderRadius: BorderRadius.circular(8),
              ),
              alignment: Alignment.center,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    i.toString(),
                    style: TextStyle(
                      color: fg,
                      fontWeight: (isToday || isSelected)
                          ? FontWeight.bold
                          : FontWeight.normal,
                    ),
                  ),
                  if (hasMeeting) ...[
                    const SizedBox(height: 4),
                    // chấm tròn báo có lịch
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: Colors.tealAccent, // nổi trên nền xanh/tím/cam
                        shape: BoxShape.circle,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      );
    }

    return dayWidgets;
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
  // Khi đổi tháng: clear selection & load lại theo tháng
  ref.listen<DateTime>(calendarProvider, (prev, next) {
    final selected = ref.read(selectedDateProvider);
    if (selected != null && (selected.year != next.year || selected.month != next.month)) {
      ref.read(selectedDateProvider.notifier).state = null;
    }
    // Cập nhật theo tháng
    ref.read(lichcuochopListProvider.notifier).loadByMonth(next);
  });

  // Khi chọn ngày: gọi API theo NGÀY
  ref.listen<DateTime?>(selectedDateProvider, (prev, next) {
    if (next != null) {
      ref.read(lichcuochopListProvider.notifier).loadByDay(next);
    }
  });

  final displayedMonth = ref.watch(calendarProvider);
  final selectedDate   = ref.watch(selectedDateProvider);

  // Danh sách bây giờ lấy trực tiếp từ provider (đã được API filter theo ngày nếu có)
  final meetings       = ref.watch(lichcuochopListProvider);

  // Dấu chấm ngày trong tháng (đọc từ cache)
  final meetingDays    = ref.watch(meetingDaysInMonthProvider(displayedMonth));

    final headerText = DateFormat(
      "'thg' M yyyy▼",
      "vi_VN",
    ).format(displayedMonth);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBarWidget(
        title: widget.title,
        actions: [
          TextButton(
            onPressed: () async {
              final picked = await showMonthYearPickerDialog(context);
              if (picked != null) {
                ref.read(calendarProvider.notifier).setMonthYear(picked);
              }
            },
            child: Text(headerText, style: const TextStyle(color: Colors.blue)),
          ),
        ],
      ),
      body: Column(
        children: [
          // Hàng thứ GHIM CỐ ĐỊNH
          SizedBox(
            height: 40,
            child: GridView.count(
              crossAxisCount: 7,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              padding: EdgeInsets.zero,
              children: const [
                Center(
                  child: Text(
                    "CN",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                Center(
                  child: Text(
                    "Th 2",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                Center(
                  child: Text(
                    "Th 3",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                Center(
                  child: Text(
                    "Th 4",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                Center(
                  child: Text(
                    "Th 5",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                Center(
                  child: Text(
                    "Th 6",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                Center(
                  child: Text(
                    "Th 7",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),

          // Lưới ngày GHIM CỐ ĐỊNH (không cuộn)
          GridView.count(
            crossAxisCount: 7,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            children: _buildCalendar(
              displayedMonth: displayedMonth,
              selectedDate: selectedDate,
              meetingDays: meetingDays, // <-- thêm
              onSelect: (d) =>
                  ref.read(selectedDateProvider.notifier).state = d,
            ),
          ),

          const SizedBox(height: 8),

          // CHỈ PHẦN NÀY CUỘN
          Expanded(
            child: selectedDate == null
                ? const Center(
                    child: Text(
                      'Chọn ngày để xem lịch họp',
                      style: TextStyle(color: Colors.black54),
                    ),
                  )
                : Column(
                    children: [
                      // header ngày
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade100,
                          border: Border(
                            top: BorderSide(color: Colors.grey.shade300),
                          ),
                        ),
                        child: Text(
                          DateFormat(
                            "EEEE, dd/MM/yyyy",
                            "vi_VN",
                          ).format(selectedDate),
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),

                      // danh sách cuộc họp (cuộn)
                      Expanded(
                        child: meetings.isEmpty
                            ? ListView(
                                padding: const EdgeInsets.fromLTRB(
                                  16,
                                  12,
                                  16,
                                  12,
                                ),
                                children: const [
                                  Text(
                                    'Chưa có lịch họp cho ngày này.',
                                    style: TextStyle(color: Colors.black54),
                                  ),
                                ],
                              )
                            : ListView.separated(
                                controller: _scrollController,
                                padding: const EdgeInsets.fromLTRB(
                                  16,
                                  12,
                                  16,
                                  12,
                                ),
                                itemCount: meetings.length,
                                separatorBuilder: (_, __) =>
                                    const Divider(height: 16),
                                itemBuilder: (_, i) {
                                  final m = meetings[i];

                                  return Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      LabelValueRow(
                                        label: 'Loại cuộc họp:',
                                        value: m['ten_lcuochop'] ?? '',
                                      ),
                                      LayoutBuilder(
                                        builder: (context, constraints) {
                                          final maxW =
                                              constraints.maxWidth *
                                              0.80; // pill tối đa 97% chiều ngang
                                          return Row(
                                            children: [
                                              const Text(
                                                'Chủ đề: ',
                                                style: TextStyle(
                                                  fontSize: 13,
                                                  color: Colors.grey,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                              ),
                                              const Spacer(),
                                              ConstrainedBox(
                                                constraints: BoxConstraints(
                                                  maxWidth: maxW,
                                                ),
                                                child: Container(
                                                  padding:
                                                      const EdgeInsets.symmetric(
                                                        horizontal: 12,
                                                        vertical: 6,
                                                      ),
                                                  decoration: BoxDecoration(
                                                    color: Colors.grey.shade300,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          8,
                                                        ),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: Colors.green
                                                            .withOpacity(0.12),
                                                        blurRadius: 6,
                                                        offset: const Offset(
                                                          0,
                                                          2,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  child: Row(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    children: [
                                                      Flexible(
                                                        child: Text(
                                                          m['ten_cuochop'] ??
                                                              '',
                                                          maxLines: 2,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style:
                                                              const TextStyle(
                                                                color: Colors
                                                                    .black87,
                                                                fontSize: 12.5,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600,
                                                                height: 1.1,
                                                              ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          );
                                        },
                                      ),
                                      SizedBox(height: 4),

                                      LayoutBuilder(
                                        builder: (context, constraints) {
                                          final maxW =
                                              constraints.maxWidth *
                                              0.80; // pill tối đa 97% chiều ngang
                                          return Row(
                                            children: [
                                              const Text(
                                                'Giờ bắt đầu - kết thúc: ',
                                                style: TextStyle(
                                                  fontSize: 13,
                                                  color: Colors.grey,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                              ),
                                              const Spacer(),
                                              ConstrainedBox(
                                                constraints: BoxConstraints(
                                                  maxWidth: maxW,
                                                ),
                                                child: Container(
                                                  padding:
                                                      const EdgeInsets.symmetric(
                                                        horizontal: 12,
                                                        vertical: 6,
                                                      ),
                                                  decoration: BoxDecoration(
                                                    color:
                                                        Colors.green.shade300,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          8,
                                                        ),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: Colors.green
                                                            .withOpacity(0.12),
                                                        blurRadius: 6,
                                                        offset: const Offset(
                                                          0,
                                                          2,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  child: Row(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    children: [
                                                      Flexible(
                                                        child: Text(
                                                          '${m['gio_bd'] ?? ''} - ${m['gio_kt'] ?? ''}',
                                                          maxLines: 2,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style:
                                                              const TextStyle(
                                                                color: Colors
                                                                    .black87,
                                                                fontSize: 12.5,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600,
                                                                height: 1.1,
                                                              ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          );
                                        },
                                      ),
                                    ],
                                  );
                                },
                              ),
                      ),
                    ],
                  ),
          ),
        ],
      ),

      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
          child: Row(
            children: [
              // Tháng trước
              Expanded(
                child: OutlinedButton(
                  onPressed: () =>
                      ref.read(calendarProvider.notifier).previousMonth(),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    textStyle: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  child: const Text(
                    'Tháng trước',
                    style: TextStyle(color: Colors.black87),
                  ),
                ),
              ),
              const SizedBox(width: 12),

              // Hôm nay (màu xanh, chữ trắng)
              Expanded(
                child: ElevatedButton(
                  onPressed: () => ref
                      .read(calendarProvider.notifier)
                      .setMonthYear(DateTime.now()),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue.shade300, // nền xanh
                    foregroundColor: Colors.white, // chữ trắng
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    textStyle: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  child: const Text('Hôm nay'),
                ),
              ),
              const SizedBox(width: 12),

              // Tháng sau
              Expanded(
                child: OutlinedButton(
                  onPressed: () =>
                      ref.read(calendarProvider.notifier).nextMonth(),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    textStyle: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  child: const Text(
                    'Tháng sau',
                    style: TextStyle(color: Colors.black87),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
