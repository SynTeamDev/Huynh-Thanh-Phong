import 'package:chinhquyen_app/core/widgets/custom_appbar_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class QuanLyCuocHopAdd extends ConsumerStatefulWidget {
  const QuanLyCuocHopAdd({super.key});

  @override
  ConsumerState<QuanLyCuocHopAdd> createState() => _QuanLyCuocHopAddState();
}

class _QuanLyCuocHopAddState extends ConsumerState<QuanLyCuocHopAdd> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBarWidget(title: "Thêm mới",),
      body: Center(child: Text('Add')),
    );
  }
}
