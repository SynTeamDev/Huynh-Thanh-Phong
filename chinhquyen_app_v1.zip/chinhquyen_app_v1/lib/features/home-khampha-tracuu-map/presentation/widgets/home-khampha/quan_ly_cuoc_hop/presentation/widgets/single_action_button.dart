import 'dart:ui'; // 👈 cần cho ImageFilter.blur
import 'package:flutter/material.dart';

import '../../../../../../../../core/widgets/loading_widget.dart';

typedef AsyncCallback = Future<void> Function();

class SingleActionButton extends StatefulWidget {
  const SingleActionButton({
    super.key,
    required this.onPressedAsync,
    required this.child,
    this.size = 56,
    this.borderRadius = 16,
    this.heroTag,
    this.semanticsLabel,
  });

  final AsyncCallback onPressedAsync;
  final Widget child;
  final double size;
  final double borderRadius;
  final Object? heroTag;
  final String? semanticsLabel;

  @override
  State<SingleActionButton> createState() => _SingleActionButtonState();
}

class _SingleActionButtonState extends State<SingleActionButton> {
  bool _busy = false;

  Future<void> _handleTap() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await widget.onPressedAsync();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final button = ClipRRect(
      borderRadius: BorderRadius.circular(widget.borderRadius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Material(
          color: Colors.blue.shade100.withOpacity(0.65),
          elevation: 10,
          shadowColor: Colors.black26,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(widget.borderRadius),
          ),
          child: InkWell(
            onTap: _handleTap,
            borderRadius: BorderRadius.circular(widget.borderRadius),
            child: SizedBox(
              width: widget.size,
              height: widget.size,
              child: Center(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 200),
                  child: _busy
                      ? const SizedBox(
                          key: ValueKey('spinner'),
                          width: 20,
                          height: 20,
                          child: LoadingWidget(),
                        )
                      : SizedBox(
                          key: const ValueKey('child'),
                          child: widget.child,
                        ),
                ),
              ),
            ),
          ),
        ),
      ),
    );

    final semantics = Semantics(
      button: true,
      label: widget.semanticsLabel ?? 'Thao tác',
      child: button,
    );

    return widget.heroTag != null
        ? Hero(tag: widget.heroTag!, child: semantics)
        : semantics;
  }
}
