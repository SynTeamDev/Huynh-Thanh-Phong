import 'package:freezed_annotation/freezed_annotation.dart';

part 'dv_hanh_chinh_cong_model.freezed.dart';
part 'dv_hanh_chinh_cong_model.g.dart';

@freezed
class DVHanhChinhCongModel with _$DVHanhChinhCongModel {
  const factory DVHanhChinhCongModel({
    String? i_ma_hccong,
    DateTime? i_ngay_ct,
    int? i_status,
    int? i_user_id_current,
  }) = _DVHanhChinhCongModel;

  factory DVHanhChinhCongModel.fromJson(Map<String, dynamic> json) =>
      _$DVHanhChinhCongModelFromJson(json);
}
