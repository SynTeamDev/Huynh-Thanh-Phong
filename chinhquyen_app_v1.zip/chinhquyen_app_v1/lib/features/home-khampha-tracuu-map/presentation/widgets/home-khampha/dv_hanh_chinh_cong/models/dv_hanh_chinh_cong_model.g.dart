// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dv_hanh_chinh_cong_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$DVHanhChinhCongModelImpl _$$DVHanhChinhCongModelImplFromJson(
  Map<String, dynamic> json,
) => _$DVHanhChinhCongModelImpl(
  i_ma_hccong: json['i_ma_hccong'] as String?,
  i_ngay_ct: json['i_ngay_ct'] == null
      ? null
      : DateTime.parse(json['i_ngay_ct'] as String),
  i_status: (json['i_status'] as num?)?.toInt(),
  i_user_id_current: (json['i_user_id_current'] as num?)?.toInt(),
);

Map<String, dynamic> _$$DVHanhChinhCongModelImplToJson(
  _$DVHanhChinhCongModelImpl instance,
) => <String, dynamic>{
  'i_ma_hccong': instance.i_ma_hccong,
  'i_ngay_ct': instance.i_ngay_ct?.toIso8601String(),
  'i_status': instance.i_status,
  'i_user_id_current': instance.i_user_id_current,
};
