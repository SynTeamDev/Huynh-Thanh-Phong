// import 'dart:io';

// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:file_picker/file_picker.dart';

// import '../../../../../../../../core/network/api_provider.dart';
// import '../../../../../../../../core/widgets/custom_appbar_widget.dart';
// import '../../../../../../../../core/widgets/custom_snackbar_widget.dart';
// import '../../../../../../../../core/widgets/form/input_field_widget.dart';
// import '../../../../../../../../core/widgets/loading_widget.dart';
// import '../../models/attachment_model.dart';
// import '../../models/phan_anh_gop_y_model.dart';
// import 'attachment_multi_tile.dart';
// import 'attachment_picker.dart';
// import 'attachment_single_tile.dart';

// class PhanAnhGopYAdd extends ConsumerStatefulWidget {
//   const PhanAnhGopYAdd({super.key});

//   @override
//   ConsumerState<PhanAnhGopYAdd> createState() => _PhanAnhGopYAddState();
// }

// class _PhanAnhGopYAddState extends ConsumerState<PhanAnhGopYAdd> {
//   final _formKey = GlobalKey<FormState>();
//   final GlobalKey comboboxKey = GlobalKey();
//   bool _isSaving = false;
//   bool hasError = false;
//   final ScrollController _scrollController = ScrollController();
//   bool _showScrollToTopButton = false;

//   final TextEditingController _tieuDeController = TextEditingController();
//   final FocusNode _tieuDeFocus = FocusNode();
//   final TextEditingController _noiDungController = TextEditingController();
//   final FocusNode _noiDungFocus = FocusNode();
//   final TextEditingController _diaDiemController = TextEditingController();
//   final FocusNode _diaDiemFocus = FocusNode();

//   final _picker = ImagePicker();
//   final List<PendingAttachment> _pending = [];
//   static const int _maxBytes = 10 * 1024 * 1024; // 10MB

//   @override
//   void initState() {
//     super.initState();
//     _scrollController.addListener(() {
//       if (_scrollController.offset >= 300 && !_showScrollToTopButton) {
//         setState(() => _showScrollToTopButton = true);
//       } else if (_scrollController.offset < 300 && _showScrollToTopButton) {
//         setState(() => _showScrollToTopButton = false);
//       }
//     });
//   }

//   @override
//   void dispose() {
//     _scrollController.dispose();
//     _tieuDeFocus.dispose();
//     _noiDungFocus.dispose();
//     _diaDiemFocus.dispose();
//     super.dispose();
//   }

//   void focusAndScrollTo(FocusNode focusNode) {
//     if (!focusNode.hasPrimaryFocus) {
//       focusNode.requestFocus();
//     }
//     if (focusNode.context != null && focusNode.context!.mounted) {
//       Scrollable.ensureVisible(
//         focusNode.context!,
//         duration: const Duration(milliseconds: 500),
//         curve: Curves.easeInOut,
//       );
//     }
//   }

//   Future<void> _submitForm() async {
//     if (_tieuDeController.text.trim().isEmpty) {
//       showSnack(context, '❌ Vui lòng nhập Tiêu đề!');
//       focusAndScrollTo(_tieuDeFocus);
//       return;
//     }

//     if (_noiDungController.text.trim().isEmpty) {
//       showSnack(context, '❌ Vui lòng nhập Nội dung!');
//       focusAndScrollTo(_noiDungFocus);
//       return;
//     }

//     if (_diaDiemController.text.trim().isEmpty) {
//       showSnack(context, '❌ Vui lòng nhập Địa điểm!');
//       focusAndScrollTo(_diaDiemFocus);
//       return;
//     }

//     setState(() => _isSaving = true);
//     try {
//       // 👉 Check số lượng file ngay trước khi upload
//       if (_pending.length > 5) {
//         showSnack(context, '❌ Chỉ chọn tối đa 5 tệp');
//         return;
//       }

//       //! SINGLE chỉ lấy 1 file nếu có
//       //String attachedUrl = '';
//       // if (_pending.isNotEmpty) {
//       //   final a = _pending.first;
//       //   final url = await ref.read(apiServiceProvider).uploadFile(a.file);
//       //   if (url == null || url.isEmpty) {
//       //     showSnack(context, '❌ Upload thất bại: ${a.name}');
//       //     return;
//       //   }
//       //   //! full url
//       //   attachedUrl = url; // http://host:port/phananh/xxx.ext
//       //   //! lưu theo dạng /phananh/1755082252355_d5125da06e56409fb302b13d5c3ce451.mp4
//       //   //   attachedUrl = Uri.parse(url).path;
//       // }
//       // final request = PhanAnhGopYModel(
//       //   i_tieu_de: _tieuDeController.text.trim(),
//       //   i_noi_dung: _noiDungController.text.trim(),
//       //   i_dia_diem: _diaDiemController.text.trim(),
//       //   i_dinh_kem: attachedUrl, // 👈 chỉ 1 URL hoặc rỗng
//       // );

//       //! MULTI
//       final files = _pending.map((x) => x.file as File).toList();
//       final urls = await ref.read(apiServiceProvider).uploadMultiFiles(files);
//       if (urls.isEmpty) {
//         showSnack(context, '❌ Upload thất bại');
//         return;
//       }
//       final csv = urls.join(';'); // hoặc '|', ',' tuỳ server
//       final request = PhanAnhGopYModel(
//         i_tieu_de: _tieuDeController.text.trim(),
//         i_noi_dung: _noiDungController.text.trim(),
//         i_dia_diem: _diaDiemController.text.trim(),
//         i_dinh_kem: csv, // 👈 1 string chứa nhiều URL
//       );

//       final success = await ref.read(apiServiceProvider).insertPhanAnh(request);
//       if (!mounted) return;

//       if (success) {
//         setState(_pending.clear); // clear preview
//         Navigator.pop(context, true);
//       } else {
//         showSnack(context, '❌ Gửi ý kiến thất bại');
//       }
//     } catch (e) {
//       showSnack(context, '❌ Lỗi: $e');
//     } finally {
//       if (mounted) setState(() => _isSaving = false);
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: CustomAppBarWidget(title: "Gửi ý kiến góp ý"),
//       body: GestureDetector(
//         onTap: () => FocusScope.of(context).unfocus(),
//         child: Scrollbar(
//           controller:
//               _scrollController, // ✅ Gắn controller để bấm nút scroll về top
//           thumbVisibility: true,
//           thickness: 6,
//           radius: const Radius.circular(10),
//           child: Padding(
//             padding: const EdgeInsets.all(16),
//             child: Form(
//               key: _formKey,
//               child: ListView(
//                 controller:
//                     _scrollController, // ✅ Gắn controller để bấm nút scroll về top
//                 children: [
//                   InputFieldWidget(
//                     label: 'Tiêu đề',
//                     showRequiredAsterisk: true, // ✅ Bật dấu *
//                     focusNode: _tieuDeFocus,
//                     controller: _tieuDeController,
//                     hintText: '-- --',
//                     onChanged: (_) => setState(() {}),
//                   ),
//                   const SizedBox(height: 5),

//                   InputFieldWidget(
//                     label: 'Nội dung',
//                     showRequiredAsterisk: true, // ✅ Bật dấu *
//                     focusNode: _noiDungFocus,
//                     controller: _noiDungController,
//                     hintText: '-- --',
//                     onChanged: (_) => setState(() {}),
//                     height: 96, // ✅ tùy chỉnh cao hơn
//                     maxLines: 5, // ✅ Cho phép xuống dòng
//                     minLines: 3, // ✅ Giữ chiều cao phù hợp
//                   ),
//                   const SizedBox(height: 5),

//                   InputFieldWidget(
//                     label: 'Địa điểm',
//                     showRequiredAsterisk: true, // ✅ Bật dấu *
//                     focusNode: _diaDiemFocus,
//                     controller: _diaDiemController,
//                     hintText: '-- --',
//                     onChanged: (_) => setState(() {}),
//                   ),

//                   const SizedBox(height: 10),

//                   // 👉 Khung đính kèm ngay dưới Địa điểm
//                   AttachmentPicker(
//                     onPickPhoto: () async {
//                       final picked = await _picker.pickImage(
//                         source: ImageSource.gallery,
//                         imageQuality: 90,
//                       );
//                       if (picked == null) return;

//                       final f = File(picked.path);
//                       final size = await f.length();
//                       if (size > _maxBytes) {
//                         showSnack(context, '❌ Ảnh vượt quá 10MB');
//                         return;
//                       }

//                       setState(() {
//                         //  setState(_pending.clear); //! single thì clear
//                         _pending.add(
//                           PendingAttachment(
//                             type: AttachType.image,
//                             file: f,
//                             name: picked.name,
//                             size: size,
//                           ),
//                         );
//                       });
//                     },
//                     onPickVideo: () async {
//                       final picked = await _picker.pickVideo(
//                         source: ImageSource.gallery,
//                       );
//                       if (picked == null) return;

//                       final f = File(picked.path);
//                       final size = await f.length();
//                       if (size > _maxBytes) {
//                         showSnack(context, '❌ Video vượt quá 10MB');
//                         return;
//                       }

//                       setState(() {
//                         // setState(_pending.clear); //! single thì clear
//                         _pending.add(
//                           PendingAttachment(
//                             type: AttachType.video,
//                             file: f,
//                             name: picked.name,
//                             size: size,
//                           ),
//                         );
//                       });
//                     },
//                     onPickFile: () async {
//                       final result = await FilePicker.platform.pickFiles(
//                         allowMultiple: false,
//                       );
//                       if (result == null || result.files.single.path == null)
//                         return;

//                       final f = File(result.files.single.path!);
//                       final size = await f.length();
//                       if (size > _maxBytes) {
//                         showSnack(context, '❌ File vượt quá 10MB');
//                         return;
//                       }

//                       setState(() {
//                         //  setState(_pending.clear); //! single thì clear
//                         _pending.add(
//                           PendingAttachment(
//                             type: AttachType.file,
//                             file: f,
//                             name: result.files.single.name,
//                             size: size,
//                           ),
//                         );
//                       });
//                     },
//                   ),
//                   //!single
//                   // if (_pending.isNotEmpty) ...[
//                   //   const SizedBox(height: 12),
//                   //   Container(
//                   //     padding: const EdgeInsets.all(12),
//                   //     decoration: BoxDecoration(
//                   //       color: const Color(0xFFF6FAFF),
//                   //       borderRadius: BorderRadius.circular(10),
//                   //       border: Border.all(color: const Color(0xFFB3D4FF)),
//                   //     ),
//                   //     child: Column(
//                   //       crossAxisAlignment: CrossAxisAlignment.start,
//                   //       children: [
//                   //         const Text(
//                   //           'Đã chọn:',
//                   //           style: TextStyle(fontWeight: FontWeight.w600),
//                   //         ),
//                   //         const SizedBox(height: 8),

//                   //         // ✅ chỉ hiển thị 1 file
//                   //         AttachmentSingleTile(
//                   //           attachment: _pending.first,
//                   //           onRemove: () => setState(_pending.clear),
//                   //         ),
//                   //       ],
//                   //     ),
//                   //   ),
//                   // ],

//                   //! multi
//                   if (_pending.isNotEmpty) ...[
//                     const SizedBox(height: 12),
//                     Container(
//                       padding: const EdgeInsets.all(12),
//                       decoration: BoxDecoration(
//                         color: const Color(0xFFF6FAFF),
//                         borderRadius: BorderRadius.circular(10),
//                         border: Border.all(color: const Color(0xFFB3D4FF)),
//                       ),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           const Text(
//                             'Đã chọn:',
//                             style: TextStyle(fontWeight: FontWeight.w600),
//                           ),
//                           const SizedBox(height: 8),
//                           Wrap(
//                             spacing: 10,
//                             runSpacing: 10,
//                             children: List.generate(_pending.length, (i) {
//                               final a = _pending[i];
//                               return AttachmentMultiTile(
//                                 attachment: a,
//                                 onRemove: () {
//                                   setState(() => _pending.removeAt(i));
//                                 },
//                               );
//                             }),
//                           ),
//                           const SizedBox(height: 8),
//                           Align(
//                             alignment: Alignment.centerRight,
//                             child: TextButton.icon(
//                               onPressed: () => setState(_pending.clear),
//                               icon: const Icon(
//                                 Icons.delete_outline,
//                                 color: Colors.red,
//                               ),
//                               label: const Text(
//                                 'Xoá tất cả',
//                                 style: TextStyle(color: Colors.red),
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ],

//                   const SizedBox(height: 15),
//                   ElevatedButton(
//                     style: ElevatedButton.styleFrom(
//                       minimumSize: const Size(double.infinity, 48),
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(12),
//                       ),
//                       backgroundColor: Colors.blueAccent,
//                     ),
//                     onPressed: _onSaveClick,
//                     child: _isSaving
//                         ? const SizedBox(
//                             width: 24,
//                             height: 24,
//                             child: LoadingWidget(),
//                           )
//                         : const Text(
//                             'Gửi ý kiến góp ý',
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontWeight: FontWeight.bold,
//                             ),
//                           ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   void _onSaveClick() {
//     if (_isSaving) return;
//     _submitForm();
//   }
// }
