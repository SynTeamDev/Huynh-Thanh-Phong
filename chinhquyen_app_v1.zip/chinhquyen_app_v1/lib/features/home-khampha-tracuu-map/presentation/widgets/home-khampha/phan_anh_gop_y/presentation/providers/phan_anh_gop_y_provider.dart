import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../../../core/network/api_provider.dart';

//! State lấy danh sách
final phananhgopyListProvider =
    StateNotifierProvider<PhanAnhGopYListNotifier, List<Map<String, dynamic>>>(
      (ref) => PhanAnhGopYListNotifier(ref),
    );

//! Api lazy loading
class PhanAnhGopYListNotifier
    extends StateNotifier<List<Map<String, dynamic>>> {
  PhanAnhGopYListNotifier(this.ref) : super([]) {
    fetchPhanAnhGopYList();
  }

  final Ref ref;
  int _pageIndex = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  Future<void> fetchPhanAnhGopYList() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;

    final result = await ref
        .read(apiServiceProvider)
        .fetchPhanAnh(pageIndex: _pageIndex);

    if (result.isEmpty) {
      _hasMore = false;
    } else {
      state = [...state, ...result];
      _pageIndex++;
    }

    _isLoading = false;
  }
}
