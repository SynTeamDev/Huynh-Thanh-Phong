import 'dart:io';

enum AttachType { image, video, file }

class PendingAttachment {
  final AttachType type;
  final File file;
  final String name;
  final int size;
  PendingAttachment({
    required this.type,
    required this.file,
    required this.name,
    required this.size,
  });
}
