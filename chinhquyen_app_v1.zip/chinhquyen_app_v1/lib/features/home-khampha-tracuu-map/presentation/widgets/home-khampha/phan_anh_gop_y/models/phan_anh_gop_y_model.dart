import 'package:freezed_annotation/freezed_annotation.dart';

part 'phan_anh_gop_y_model.freezed.dart';
part 'phan_anh_gop_y_model.g.dart';

@freezed
class PhanAnhGopYModel with _$PhanAnhGopYModel {
  const factory PhanAnhGopYModel({
    String? i_tieu_de,
    String? i_noi_dung,
    String? i_dia_diem,
    String? i_dinh_kem,
  }) = _PhanAnhGopYModel;

  factory PhanAnhGopYModel.fromJson(Map<String, dynamic> json) =>
      _$PhanAnhGopYModelFromJson(json);
}
