// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'dv_hanh_chinh_cong_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
  'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models',
);

DVHanhChinhCongModel _$DVHanhChinhCongModelFromJson(Map<String, dynamic> json) {
  return _DVHanhChinhCongModel.fromJson(json);
}

/// @nodoc
mixin _$DVHanhChinhCongModel {
  String? get i_ma_hccong => throw _privateConstructorUsedError;
  DateTime? get i_ngay_ct => throw _privateConstructorUsedError;
  int? get i_status => throw _privateConstructorUsedError;
  int? get i_user_id_current => throw _privateConstructorUsedError;

  /// Serializes this DVHanhChinhCongModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of DVHanhChinhCongModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $DVHanhChinhCongModelCopyWith<DVHanhChinhCongModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DVHanhChinhCongModelCopyWith<$Res> {
  factory $DVHanhChinhCongModelCopyWith(
    DVHanhChinhCongModel value,
    $Res Function(DVHanhChinhCongModel) then,
  ) = _$DVHanhChinhCongModelCopyWithImpl<$Res, DVHanhChinhCongModel>;
  @useResult
  $Res call({
    String? i_ma_hccong,
    DateTime? i_ngay_ct,
    int? i_status,
    int? i_user_id_current,
  });
}

/// @nodoc
class _$DVHanhChinhCongModelCopyWithImpl<
  $Res,
  $Val extends DVHanhChinhCongModel
>
    implements $DVHanhChinhCongModelCopyWith<$Res> {
  _$DVHanhChinhCongModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of DVHanhChinhCongModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? i_ma_hccong = freezed,
    Object? i_ngay_ct = freezed,
    Object? i_status = freezed,
    Object? i_user_id_current = freezed,
  }) {
    return _then(
      _value.copyWith(
            i_ma_hccong: freezed == i_ma_hccong
                ? _value.i_ma_hccong
                : i_ma_hccong // ignore: cast_nullable_to_non_nullable
                      as String?,
            i_ngay_ct: freezed == i_ngay_ct
                ? _value.i_ngay_ct
                : i_ngay_ct // ignore: cast_nullable_to_non_nullable
                      as DateTime?,
            i_status: freezed == i_status
                ? _value.i_status
                : i_status // ignore: cast_nullable_to_non_nullable
                      as int?,
            i_user_id_current: freezed == i_user_id_current
                ? _value.i_user_id_current
                : i_user_id_current // ignore: cast_nullable_to_non_nullable
                      as int?,
          )
          as $Val,
    );
  }
}

/// @nodoc
abstract class _$$DVHanhChinhCongModelImplCopyWith<$Res>
    implements $DVHanhChinhCongModelCopyWith<$Res> {
  factory _$$DVHanhChinhCongModelImplCopyWith(
    _$DVHanhChinhCongModelImpl value,
    $Res Function(_$DVHanhChinhCongModelImpl) then,
  ) = __$$DVHanhChinhCongModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({
    String? i_ma_hccong,
    DateTime? i_ngay_ct,
    int? i_status,
    int? i_user_id_current,
  });
}

/// @nodoc
class __$$DVHanhChinhCongModelImplCopyWithImpl<$Res>
    extends _$DVHanhChinhCongModelCopyWithImpl<$Res, _$DVHanhChinhCongModelImpl>
    implements _$$DVHanhChinhCongModelImplCopyWith<$Res> {
  __$$DVHanhChinhCongModelImplCopyWithImpl(
    _$DVHanhChinhCongModelImpl _value,
    $Res Function(_$DVHanhChinhCongModelImpl) _then,
  ) : super(_value, _then);

  /// Create a copy of DVHanhChinhCongModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? i_ma_hccong = freezed,
    Object? i_ngay_ct = freezed,
    Object? i_status = freezed,
    Object? i_user_id_current = freezed,
  }) {
    return _then(
      _$DVHanhChinhCongModelImpl(
        i_ma_hccong: freezed == i_ma_hccong
            ? _value.i_ma_hccong
            : i_ma_hccong // ignore: cast_nullable_to_non_nullable
                  as String?,
        i_ngay_ct: freezed == i_ngay_ct
            ? _value.i_ngay_ct
            : i_ngay_ct // ignore: cast_nullable_to_non_nullable
                  as DateTime?,
        i_status: freezed == i_status
            ? _value.i_status
            : i_status // ignore: cast_nullable_to_non_nullable
                  as int?,
        i_user_id_current: freezed == i_user_id_current
            ? _value.i_user_id_current
            : i_user_id_current // ignore: cast_nullable_to_non_nullable
                  as int?,
      ),
    );
  }
}

/// @nodoc
@JsonSerializable()
class _$DVHanhChinhCongModelImpl implements _DVHanhChinhCongModel {
  const _$DVHanhChinhCongModelImpl({
    this.i_ma_hccong,
    this.i_ngay_ct,
    this.i_status,
    this.i_user_id_current,
  });

  factory _$DVHanhChinhCongModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$DVHanhChinhCongModelImplFromJson(json);

  @override
  final String? i_ma_hccong;
  @override
  final DateTime? i_ngay_ct;
  @override
  final int? i_status;
  @override
  final int? i_user_id_current;

  @override
  String toString() {
    return 'DVHanhChinhCongModel(i_ma_hccong: $i_ma_hccong, i_ngay_ct: $i_ngay_ct, i_status: $i_status, i_user_id_current: $i_user_id_current)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DVHanhChinhCongModelImpl &&
            (identical(other.i_ma_hccong, i_ma_hccong) ||
                other.i_ma_hccong == i_ma_hccong) &&
            (identical(other.i_ngay_ct, i_ngay_ct) ||
                other.i_ngay_ct == i_ngay_ct) &&
            (identical(other.i_status, i_status) ||
                other.i_status == i_status) &&
            (identical(other.i_user_id_current, i_user_id_current) ||
                other.i_user_id_current == i_user_id_current));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
    runtimeType,
    i_ma_hccong,
    i_ngay_ct,
    i_status,
    i_user_id_current,
  );

  /// Create a copy of DVHanhChinhCongModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$DVHanhChinhCongModelImplCopyWith<_$DVHanhChinhCongModelImpl>
  get copyWith =>
      __$$DVHanhChinhCongModelImplCopyWithImpl<_$DVHanhChinhCongModelImpl>(
        this,
        _$identity,
      );

  @override
  Map<String, dynamic> toJson() {
    return _$$DVHanhChinhCongModelImplToJson(this);
  }
}

abstract class _DVHanhChinhCongModel implements DVHanhChinhCongModel {
  const factory _DVHanhChinhCongModel({
    final String? i_ma_hccong,
    final DateTime? i_ngay_ct,
    final int? i_status,
    final int? i_user_id_current,
  }) = _$DVHanhChinhCongModelImpl;

  factory _DVHanhChinhCongModel.fromJson(Map<String, dynamic> json) =
      _$DVHanhChinhCongModelImpl.fromJson;

  @override
  String? get i_ma_hccong;
  @override
  DateTime? get i_ngay_ct;
  @override
  int? get i_status;
  @override
  int? get i_user_id_current;

  /// Create a copy of DVHanhChinhCongModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$DVHanhChinhCongModelImplCopyWith<_$DVHanhChinhCongModelImpl>
  get copyWith => throw _privateConstructorUsedError;
}
