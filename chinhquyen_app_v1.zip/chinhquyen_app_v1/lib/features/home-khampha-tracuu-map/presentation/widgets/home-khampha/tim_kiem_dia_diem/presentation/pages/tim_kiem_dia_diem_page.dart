import 'package:chinhquyen_app/core/widgets/loading_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:ionicons/ionicons.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../../../../../../core/utils/delay_btn_helper.dart';
import '../../../../../../../../core/widgets/custom_appbar_widget.dart';
import '../../../../../providers/map_location_provider.dart';
import '../providers/tim_kiem_dia_diem_provider.dart';
import '../widgets/tim_kiem_dia_diem_filter.dart';

class TimKiemDiaDiemPage extends ConsumerStatefulWidget {
  const TimKiemDiaDiemPage({super.key, this.title = ''});
  final String title;

  @override
  ConsumerState<TimKiemDiaDiemPage> createState() => _TimKiemDiaDiemPageState();
}

class _TimKiemDiaDiemPageState extends ConsumerState<TimKiemDiaDiemPage> {
  GoogleMapController? _mapController;
  final Set<Marker> _markers = {};
  final ScrollController _listCtrl = ScrollController();
  String? _selectedMa;

  DateTime? _ngayCt1, _ngayCt2;
  String? _ma_lhhd, _ten_location;

  @override
  void initState() {
    super.initState();
    _listCtrl.addListener(_onListScroll);

    _initDatesToDefault();
    final filter = ref.read(timkiemddFilterStateProvider);
    if (filter != null) _applyFilterFromTuple(filter);
  }

  @override
  void dispose() {
    _mapController?.dispose();
    _listCtrl.dispose();
    super.dispose();
  }

  void _initDatesToDefault() {
    final now = DateTime.now();
    _ngayCt1 = DateTime(now.year, now.month - 6, 1);
    _ngayCt2 = DateTime(now.year, now.month + 2, 0);
  }

  void _applyFilterFromTuple((DateTime, DateTime, String?, String?) filter) {
    final (ngayCt1, ngayCt2, ma_lhhd, ten_location) = filter;
    _ngayCt1 = ngayCt1;
    _ngayCt2 = ngayCt2;
    _ma_lhhd = ma_lhhd;
    _ten_location = ten_location;
  }

  Future<void> _onRefreshPressed() async {
    if (!GlobalButtonDisableHelper.isDisabled) {
      GlobalButtonDisableHelper.disableTemporarily(seconds: 1);
      setState(() {
        _initDatesToDefault();
        _ma_lhhd = _ten_location = null;
      });
      ref.read(timkiemddFilterStateProvider.notifier).state = null;

      // ✅ Quan trọng: trigger lại gọi API
      ref.invalidate(timkiemddListProvider);
    }
  }

  Future<void> _onFilterPressed() async {
    if (!GlobalButtonDisableHelper.isDisabled) {
      GlobalButtonDisableHelper.disableTemporarily(seconds: 1);
      final result = await TimKiemDiaDiemFilter(
        initialFromDate: _ngayCt1 ?? DateTime.now(),
        initialToDate: _ngayCt2 ?? DateTime.now(),
        initialValues: (_ma_lhhd, _ten_location),
      ).show(context);

      if (result != null) {
        ref.read(timkiemddFilterStateProvider.notifier).state = result;
        setState(() => _applyFilterFromTuple(result));
        // ✅ Quan trọng: trigger lại gọi API
        ref.invalidate(timkiemddListProvider);
      }
    }
  }

  void _onListScroll() {
    if (_listCtrl.position.pixels >= _listCtrl.position.maxScrollExtent - 100) {
      ref.read(timkiemddListProvider.notifier).fetchTimKiemDDList();
    }
  }

  double _toDouble(dynamic v) {
    if (v == null) return 0;
    if (v is num) return v.toDouble();
    if (v is String) return double.tryParse(v) ?? 0;
    return 0;
  }

  String _distanceKm(Position me, double lat, double lng) {
    final d = Geolocator.distanceBetween(me.latitude, me.longitude, lat, lng);
    if (d < 1000) return '${d.toStringAsFixed(0)} m';
    return '${(d / 1000).toStringAsFixed(1)} km';
    // Bạn có thể cache nếu danh sách rất dài
  }

  Future<void> _animateTo(LatLng target, {double zoom = 17}) async {
    await _mapController?.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: target, zoom: zoom),
      ),
    );
  }

  void _setMarkers(Position me, {Map<String, dynamic>? place}) {
    final set = <Marker>{
      Marker(
        markerId: const MarkerId('current'),
        position: LatLng(me.latitude, me.longitude),
        infoWindow: const InfoWindow(title: 'Bạn đang ở đây'),
      ),
    };

    if (place != null) {
      final lat = _toDouble(place['tdy']);
      final lng = _toDouble(place['tdx']);
      set.add(
        Marker(
          markerId: MarkerId('sel_${place['ma_location']}'),
          position: LatLng(lat, lng),
          infoWindow: InfoWindow(
            title: (place['ten_location'] ?? '').toString(),
            snippet: (place['dia_chi'] ?? '').toString(),
          ),
        ),
      );
    }

    setState(() {
      _markers
        ..clear()
        ..addAll(set);
    });
  }

  Future<void> _goToPlace(Map<String, dynamic> item, Position me) async {
    final lat = _toDouble(item['tdy']);
    final lng = _toDouble(item['tdx']);
    setState(() => _selectedMa = (item['ma_location'] ?? '').toString());
    _setMarkers(me, place: item);

    await _animateTo(LatLng(lat, lng)); // có thể bỏ vì _drawRoute đã fit bounds
  }

  void _goToCurrentLocation(Position me) {
    _animateTo(LatLng(me.latitude, me.longitude), zoom: 16);
    _setMarkers(me);
  }

  Future<void> _openDirections(double lat, double lng, String label) async {
    // Ưu tiên mở app Google Maps (Android)
    final appUri = Uri.parse('google.navigation:q=$lat,$lng&mode=d');
    if (await canLaunchUrl(appUri)) {
      await launchUrl(appUri, mode: LaunchMode.externalApplication);
      return;
    }
    // Fallback: mở web Google Maps
    final webUri = Uri.parse(
      'https://www.google.com/maps/dir/?api=1&destination=$lat,$lng&travelmode=driving',
    );
    await launchUrl(webUri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final locationAsync = ref.watch(locationProvider);
    final list = ref.watch(timkiemddListProvider);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBarWidget(
        title: widget.title.isEmpty ? 'Tìm kiếm địa điểm' : widget.title,
        actions: [
          IconButton(
            icon: const Icon(Ionicons.refresh, color: Colors.blue),
            onPressed: () {
              _onRefreshPressed();
            },
          ),
          IconButton(
            icon: const Icon(Ionicons.search_outline, color: Colors.blue),
            onPressed: () {
              _onFilterPressed();
            },
          ),
        ],
      ),
      body: locationAsync.when(
        loading: () => const LoadingWidget(),
        error: (e, _) => Center(child: Text('Lỗi định vị: $e')),
        data: (me) {
          final myLatLng = LatLng(me.latitude, me.longitude);

          if (_markers.isEmpty) _setMarkers(me);

          return Stack(
            children: [
              GoogleMap(
                onMapCreated: (controller) => _mapController = controller,
                initialCameraPosition: CameraPosition(
                  target: myLatLng,
                  zoom: 16,
                ),
                markers: _markers,
                myLocationEnabled: true,
                myLocationButtonEnabled: false,
              ),

              // Nút về vị trí hiện tại
              Positioned(
                bottom: 100,
                right: 4,
                child: FloatingActionButton(
                  onPressed: () => _goToCurrentLocation(me),
                  backgroundColor: Colors.white,
                  shape: const CircleBorder(),
                  elevation: 2,
                  child: const Icon(Icons.my_location, color: Colors.blue),
                ),
              ),

              // Panel danh sách địa điểm — UI mới dạng card
              DraggableScrollableSheet(
                initialChildSize: 0.35,
                minChildSize: 0.14,
                maxChildSize: 0.7,
                builder: (context, _) {
                  return ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(16),
                    ),
                    child: Material(
                      color: Colors.white,
                      elevation: 12,
                      child: Column(
                        children: [
                          const SizedBox(height: 8),
                          Container(
                            width: 36,
                            height: 4,
                            decoration: BoxDecoration(
                              color: Colors.black26,
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            'Danh sách địa điểm',
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                            ),
                          ),
                          const SizedBox(height: 2),

                          // Danh sách thẻ
                          Expanded(
                            child: ListView.builder(
                              controller: _listCtrl,
                              padding: const EdgeInsets.only(
                                left: 12,
                                right: 12,
                                bottom: 12,
                              ),
                              itemCount: list.length,
                              itemBuilder: (context, i) {
                                final item = list[i];
                                final ma = (item['ma_location'] ?? '')
                                    .toString();
                                final ten = (item['ten_location'] ?? '')
                                    .toString();
                                final diaChi = (item['dia_chi'] ?? '')
                                    .toString();
                                final lat = _toDouble(item['tdy']);
                                final lng = _toDouble(item['tdx']);
                                final selected = ma == _selectedMa;
                                final distance = _distanceKm(
                                  me,
                                  lat,
                                  lng,
                                ); // hiển thị khoảng cách

                                return Card(
                                  elevation: selected ? 6 : 2,
                                  color: Colors.white, // 👈 nền trắng
                                  shadowColor: Colors.black26,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16),
                                    side: BorderSide(
                                      color: selected
                                          ? Colors.blue
                                          : Colors
                                                .transparent, // 👈 viền xanh khi chọn
                                      width: 1.2,
                                    ),
                                  ),
                                  margin: const EdgeInsets.symmetric(
                                    vertical: 2,
                                  ),
                                  child: InkWell(
                                    borderRadius: BorderRadius.circular(16),
                                    onTap: () => _goToPlace(item, me),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 12,
                                        vertical: 8,
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              CircleAvatar(
                                                radius: 18,
                                                backgroundColor:
                                                    Colors.blue.shade50,
                                                child: const Icon(
                                                  Icons.place,
                                                  color: Colors.blue,
                                                ),
                                              ),
                                              const SizedBox(width: 12),
                                              Expanded(
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Text(
                                                      ten,
                                                      maxLines: 2,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style: const TextStyle(
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        fontSize: 15,
                                                      ),
                                                    ),
                                                    const SizedBox(height: 4),
                                                    Text(
                                                      diaChi,
                                                      maxLines: 2,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style: const TextStyle(
                                                        color: Colors.black54,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              const SizedBox(width: 8),
                                              Container(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                      horizontal: 8,
                                                      vertical: 4,
                                                    ),
                                                decoration: BoxDecoration(
                                                  color: Colors.blue.shade50,
                                                  borderRadius:
                                                      BorderRadius.circular(8),
                                                ),
                                                child: Text(
                                                  distance,
                                                  style: const TextStyle(
                                                    color: Colors.blue,
                                                    fontWeight: FontWeight.w600,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          const SizedBox(height: 4),

                                          // 🔵 Hai nút xanh
                                          Row(
                                            children: [
                                              Expanded(
                                                child: ElevatedButton.icon(
                                                  onPressed: () =>
                                                      _openDirections(
                                                        lat,
                                                        lng,
                                                        ten,
                                                      ),
                                                  icon: const Icon(
                                                    Ionicons.map_outline,
                                                  ),
                                                  label: const Text(
                                                    'Chỉ đường',
                                                  ),
                                                  style: ElevatedButton.styleFrom(
                                                    backgroundColor:
                                                        Colors.blue, // nền xanh
                                                    foregroundColor: Colors
                                                        .white, // chữ trắng
                                                    elevation: 0,
                                                    shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                            12,
                                                          ),
                                                    ),
                                                    padding:
                                                        const EdgeInsets.symmetric(
                                                          vertical: 12,
                                                        ),
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(width: 8),
                                              Expanded(
                                                child: ElevatedButton.icon(
                                                  onPressed: () =>
                                                      _goToPlace(item, me),
                                                  icon: const Icon(
                                                    Icons
                                                        .center_focus_strong_outlined,
                                                  ),
                                                  label: const Text('Tới đây'),
                                                  style: ElevatedButton.styleFrom(
                                                    backgroundColor:
                                                        Colors.blue,
                                                    foregroundColor:
                                                        Colors.white,
                                                    elevation: 0,
                                                    shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                            12,
                                                          ),
                                                    ),
                                                    padding:
                                                        const EdgeInsets.symmetric(
                                                          vertical: 12,
                                                        ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
          );
        },
      ),
    );
  }
}
