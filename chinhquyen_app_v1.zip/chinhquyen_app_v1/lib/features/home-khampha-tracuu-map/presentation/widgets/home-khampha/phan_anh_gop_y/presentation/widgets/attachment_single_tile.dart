//! single
import 'package:flutter/material.dart';

import '../../models/attachment_model.dart';

class AttachmentSingleTile extends StatelessWidget {
  const AttachmentSingleTile({
    required this.attachment,
    required this.onRemove,
  });
  final PendingAttachment attachment;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    switch (attachment.type) {
      case AttachType.image:
        return Stack(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.file(
                attachment.file,
                width: double.infinity,
                height: 180,
                fit: BoxFit.cover,
              ),
            ),
            Positioned(
              right: -8,
              top: -8,
              child: IconButton(
                onPressed: onRemove,
                icon: const Icon(
                  Icons.cancel,
                  size: 22,
                  color: Colors.redAccent,
                ),
                padding: EdgeInsets.zero,
              ),
            ),
          ],
        );

      case AttachType.video:
        return _infoBox(
          context,
          icon: Icons.videocam_outlined,
          title: attachment.name,
          subtitle: _fmtSize(attachment.size),
          onRemove: onRemove,
        );

      default: // file
        return _infoBox(
          context,
          icon: Icons.insert_drive_file_outlined,
          title: attachment.name,
          subtitle: _fmtSize(attachment.size),
          onRemove: onRemove,
        );
    }
  }

  // Thẻ thông tin cho video/file
  Widget _infoBox(
    BuildContext context, {
    required IconData icon,
    required String title,
    String? subtitle,
    required VoidCallback onRemove,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFB3D4FF)),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Icon(icon, size: 26, color: Colors.blue),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
                if (subtitle != null)
                  Text(
                    subtitle,
                    style: const TextStyle(fontSize: 12, color: Colors.black54),
                  ),
              ],
            ),
          ),
          IconButton(
            onPressed: onRemove,
            icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
          ),
        ],
      ),
    );
  }
}

String _fmtSize(int bytes) {
  if (bytes < 1024) return '$bytes B';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(0)} KB';
  return '${(bytes / 1024 / 1024).toStringAsFixed(1)} MB';
} //!
