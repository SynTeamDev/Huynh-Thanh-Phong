import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../../../core/shared/base_filter.dart';
import '../../../../../../../../core/widgets/form/combobox_field_widget.dart';
import '../../../../../../../../core/widgets/form/popup_search_field_widget.dart';

class DanhBaCoQuanFilter
    extends BaseFilter<(DateTime, DateTime, String?, String?, String?)> {
  final (String?, String?, String?)? initialValues;

  const DanhBaCoQuanFilter({
    super.key,
    required super.initialFromDate,
    required super.initialToDate,
    this.initialValues,
    // ẩn ngày tháng
    super.showDateFields = false,
  });

  @override
  ConsumerState<DanhBaCoQuanFilter> createState() =>
      _DanhBaCoQuanFilterConsumerState();
}

class _DanhBaCoQuanFilterConsumerState
    extends
        BaseFilterState<
          (DateTime, DateTime, String?, String?, String?),
          DanhBaCoQuanFilter
        > {
  String? ma_loai, ma_ttp, ma_phuongxa;

  @override
  void initState() {
    super.initState();

    final initial = widget.initialValues;
    if (initial != null) {
      ma_loai = initial.$1;
      ma_ttp = initial.$2;
      ma_phuongxa = initial.$3;
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  List<Widget> buildFilterFields() {
    return [
      ComboboxFieldWidget(
        label: 'Loại',
        tableName: 'dmloaiphone',
        selectedValue: ma_loai,
        onChanged: (value) {
          setState(() {
            ma_loai = value;
          });
        },
        isCode: false,
      ),
      const SizedBox(height: 5),
      PopupSearchFieldWidget(
        label: 'Tỉnh thành phố',
        tableName: 'dmttp',
        selectedValue: ma_ttp,
        onChanged: (value) {
          setState(() {
            ma_ttp = value;
          });
        },
        isCode: false,
      ),
      const SizedBox(height: 5),
      PopupSearchFieldWidget(
        label: 'Phường xã',
        tableName: 'dmphuongxa',
        selectedValue: ma_phuongxa,
        onChanged: (value) {
          setState(() {
            ma_phuongxa = value;
          });
        },
        isCode: false,
      ),
    ];
  }

  @override
  (DateTime, DateTime, String?, String?, String?) getFilterResult() {
    return (fromDate, toDate, ma_loai, ma_ttp, ma_phuongxa);
  }
}
