//! multi
import 'package:flutter/material.dart';

import '../../models/attachment_model.dart';

class AttachmentMultiTile extends StatelessWidget {
  const AttachmentMultiTile({required this.attachment, required this.onRemove});
  final PendingAttachment attachment;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    Widget body;
    switch (attachment.type) {
      case AttachType.image:
        body = ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.file(
            attachment.file,
            width: 84,
            height: 84,
            fit: BoxFit.cover,
          ),
        );
        break;
      case AttachType.video:
        body = _box(Icons.videocam_outlined, attachment.name);
        break;
      default:
        body = _box(Icons.insert_drive_file_outlined, attachment.name);
    }

    return Stack(
      children: [
        body,
        Positioned(
          right: -8,
          top: -8,
          child: IconButton(
            onPressed: onRemove,
            icon: const Icon(Icons.cancel, size: 20, color: Colors.redAccent),
            padding: EdgeInsets.zero,
          ),
        ),
      ],
    );
  }

  Widget _box(IconData icon, String name) {
    return Container(
      width: 180,
      constraints: const BoxConstraints(minHeight: 64),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFB3D4FF)),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Icon(icon, size: 24, color: Colors.blue),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              name,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }
}
