import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';

class ExpandableActionMenu extends StatefulWidget {
  const ExpandableActionMenu({
    super.key,
    required this.onAdd,
    required this.onEdit,
    required this.onDelete,
    this.onApprove,
    this.showApprove = false, // chỉ điều khiển nút DUYỆT
  });

  final VoidCallback onAdd;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback? onApprove;

  final bool showApprove;

  @override
  State<ExpandableActionMenu> createState() => _ExpandableActionMenuState();
}

class _ExpandableActionMenuState extends State<ExpandableActionMenu>
    with SingleTickerProviderStateMixin {
  bool _open = false;

  late final AnimationController _ctl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 260),
  );
  late final Animation<double> _anim = CurvedAnimation(
    parent: _ctl,
    curve: Curves.easeOutCubic,
  );

  void _toggle() {
    setState(() => _open = !_open);
    if (_open)
      _ctl.forward();
    else
      _ctl.reverse();
  }

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // 3 nút mặc định + Duyệt (nếu bật)
    final actions = <_ActionItem>[
      _ActionItem(
        'Thêm',
        Ionicons.add,
        Colors.white,
        Colors.blue,
        widget.onAdd,
      ),
      _ActionItem(
        'Sửa',
        Ionicons.pencil_outline,
        Colors.white,
        Colors.blue,
        widget.onEdit,
      ),
      _ActionItem(
        'Xoá',
        Ionicons.trash_bin_outline,
        Colors.white,
        Colors.blue,
        widget.onDelete,
      ),
      if (widget.showApprove)
        _ActionItem(
          'Duyệt',
          Ionicons.checkbox_outline,
          Colors.white,
          Colors.blue,
          widget.onApprove ?? () {},
        ), // nếu chưa truyền callback thì noop
    ];

    final offsets = _computeOffsets(actions.length);

    return SizedBox(
      width: 260,
      height: 260,
      child: Stack(
        alignment: Alignment.bottomRight,
        children: [
          // Panel kính mờ bo tròn
          Positioned(
            right: 8,
            bottom: 8,
            child: IgnorePointer(
              ignoring: !_open,
              child: AnimatedOpacity(
                duration: const Duration(milliseconds: 180),
                opacity: _open ? 1 : 0,
                child: GestureDetector(
                  onTap: _toggle,
                  child: _GlassPanel(width: 230, height: 230),
                ),
              ),
            ),
          ),

          // Nút con
          for (int i = 0; i < actions.length; i++)
            _GlassMiniButton(
              label: actions[i].label,
              icon: actions[i].icon,
              color: actions[i].bg,
              iconColor: actions[i].fg,
              visible: _open,
              animation: _anim,
              offset: offsets[i],
              onTap: () {
                _toggle();
                actions[i].onTap();
              },
            ),

          // Nút chính
          _MainGlassFab(
            onPressed: _toggle,
            child: AnimatedRotation(
              duration: const Duration(milliseconds: 180),
              turns: _open ? 0.125 : 0.0,
              child: const Icon(Icons.add_rounded, size: 28),
            ),
          ),
        ],
      ),
    );
  }

  // Offsets phân bố theo hình quạt 90° (từ hướng lên đến hướng trái)
  // Trả về khoảng cách DƯƠNG theo bội số 56px: dx (từ mép phải), dy (từ mép dưới)
  List<Offset> _computeOffsets(int n) {
    if (n <= 0) return const [];
    const double radius = 2.0; // bán kính ~ 2 * 56px
    final List<Offset> out = [];
    const double startDeg = 90, endDeg = 180;
    final double step = n == 1 ? 0 : (endDeg - startDeg) / (n - 1);

    for (int i = 0; i < n; i++) {
      final double rad = (startDeg + step * i) * pi / 180.0;
      // cos(90..180) âm -> lấy -cos để dx dương; sin(90..180) đã dương
      final double dx = -radius * cos(rad); // >= 0
      final double dy = radius * sin(rad); // >= 0
      out.add(Offset(dx, dy));
    }
    return out;
  }
}

/* ---------- UI sub-widgets ---------- */

class _GlassPanel extends StatelessWidget {
  const _GlassPanel({required this.width, required this.height});
  final double width;
  final double height;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          width: width,
          height: height,
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.10),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.white.withOpacity(0.22)),
            boxShadow: const [
              BoxShadow(
                blurRadius: 18,
                offset: Offset(0, 10),
                color: Colors.white,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MainGlassFab extends StatelessWidget {
  const _MainGlassFab({required this.onPressed, required this.child});
  final VoidCallback onPressed;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Material(
          color: Colors.blue.shade100,
          elevation: 8,
          shadowColor: Colors.black26,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: onPressed,
            child: SizedBox(width: 56, height: 56, child: Center(child: child)),
          ),
        ),
      ),
    );
  }
}

class _GlassMiniButton extends StatelessWidget {
  const _GlassMiniButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.iconColor,
    required this.visible,
    required this.animation,
    required this.offset,
    required this.onTap,
  });

  final String label; // không dùng để hiển thị, chỉ dùng cho tooltip/semantics
  final IconData icon;
  final Color color, iconColor;
  final bool visible;
  final Animation<double> animation;
  final Offset offset; // tính theo bội số 56px
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (context, _) {
        final px = 56.0;
        return Positioned(
          right: 16 + (px * offset.dx),
          bottom: 16 + (px * offset.dy),
          child: IgnorePointer(
            ignoring: !visible,
            child: Opacity(
              opacity: visible ? animation.value : 0,
              child: Transform.scale(
                scale: animation.value.clamp(0.85, 1.0),
                child: Tooltip(
                  // tuỳ chọn: bỏ nếu không muốn tooltip
                  message: label,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.85),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: const [
                        BoxShadow(
                          blurRadius: 8,
                          offset: Offset(0, 4),
                          color: Colors.black26,
                        ),
                      ],
                    ),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: onTap,
                      child: SizedBox(
                        width: 44,
                        height: 44,
                        child: Icon(icon, color: iconColor, size: 22),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _ActionItem {
  _ActionItem(this.label, this.icon, this.bg, this.fg, this.onTap);
  final String label;
  final IconData icon;
  final Color bg, fg;
  final VoidCallback onTap;
}
