// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'phan_anh_gop_y_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
  'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models',
);

PhanAnhGopYModel _$PhanAnhGopYModelFromJson(Map<String, dynamic> json) {
  return _PhanAnhGopYModel.fromJson(json);
}

/// @nodoc
mixin _$PhanAnhGopYModel {
  String? get i_tieu_de => throw _privateConstructorUsedError;
  String? get i_noi_dung => throw _privateConstructorUsedError;
  String? get i_dia_diem => throw _privateConstructorUsedError;
  String? get i_dinh_kem => throw _privateConstructorUsedError;

  /// Serializes this PhanAnhGopYModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of PhanAnhGopYModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $PhanAnhGopYModelCopyWith<PhanAnhGopYModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PhanAnhGopYModelCopyWith<$Res> {
  factory $PhanAnhGopYModelCopyWith(
    PhanAnhGopYModel value,
    $Res Function(PhanAnhGopYModel) then,
  ) = _$PhanAnhGopYModelCopyWithImpl<$Res, PhanAnhGopYModel>;
  @useResult
  $Res call({
    String? i_tieu_de,
    String? i_noi_dung,
    String? i_dia_diem,
    String? i_dinh_kem,
  });
}

/// @nodoc
class _$PhanAnhGopYModelCopyWithImpl<$Res, $Val extends PhanAnhGopYModel>
    implements $PhanAnhGopYModelCopyWith<$Res> {
  _$PhanAnhGopYModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of PhanAnhGopYModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? i_tieu_de = freezed,
    Object? i_noi_dung = freezed,
    Object? i_dia_diem = freezed,
    Object? i_dinh_kem = freezed,
  }) {
    return _then(
      _value.copyWith(
            i_tieu_de: freezed == i_tieu_de
                ? _value.i_tieu_de
                : i_tieu_de // ignore: cast_nullable_to_non_nullable
                      as String?,
            i_noi_dung: freezed == i_noi_dung
                ? _value.i_noi_dung
                : i_noi_dung // ignore: cast_nullable_to_non_nullable
                      as String?,
            i_dia_diem: freezed == i_dia_diem
                ? _value.i_dia_diem
                : i_dia_diem // ignore: cast_nullable_to_non_nullable
                      as String?,
            i_dinh_kem: freezed == i_dinh_kem
                ? _value.i_dinh_kem
                : i_dinh_kem // ignore: cast_nullable_to_non_nullable
                      as String?,
          )
          as $Val,
    );
  }
}

/// @nodoc
abstract class _$$PhanAnhGopYModelImplCopyWith<$Res>
    implements $PhanAnhGopYModelCopyWith<$Res> {
  factory _$$PhanAnhGopYModelImplCopyWith(
    _$PhanAnhGopYModelImpl value,
    $Res Function(_$PhanAnhGopYModelImpl) then,
  ) = __$$PhanAnhGopYModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({
    String? i_tieu_de,
    String? i_noi_dung,
    String? i_dia_diem,
    String? i_dinh_kem,
  });
}

/// @nodoc
class __$$PhanAnhGopYModelImplCopyWithImpl<$Res>
    extends _$PhanAnhGopYModelCopyWithImpl<$Res, _$PhanAnhGopYModelImpl>
    implements _$$PhanAnhGopYModelImplCopyWith<$Res> {
  __$$PhanAnhGopYModelImplCopyWithImpl(
    _$PhanAnhGopYModelImpl _value,
    $Res Function(_$PhanAnhGopYModelImpl) _then,
  ) : super(_value, _then);

  /// Create a copy of PhanAnhGopYModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? i_tieu_de = freezed,
    Object? i_noi_dung = freezed,
    Object? i_dia_diem = freezed,
    Object? i_dinh_kem = freezed,
  }) {
    return _then(
      _$PhanAnhGopYModelImpl(
        i_tieu_de: freezed == i_tieu_de
            ? _value.i_tieu_de
            : i_tieu_de // ignore: cast_nullable_to_non_nullable
                  as String?,
        i_noi_dung: freezed == i_noi_dung
            ? _value.i_noi_dung
            : i_noi_dung // ignore: cast_nullable_to_non_nullable
                  as String?,
        i_dia_diem: freezed == i_dia_diem
            ? _value.i_dia_diem
            : i_dia_diem // ignore: cast_nullable_to_non_nullable
                  as String?,
        i_dinh_kem: freezed == i_dinh_kem
            ? _value.i_dinh_kem
            : i_dinh_kem // ignore: cast_nullable_to_non_nullable
                  as String?,
      ),
    );
  }
}

/// @nodoc
@JsonSerializable()
class _$PhanAnhGopYModelImpl implements _PhanAnhGopYModel {
  const _$PhanAnhGopYModelImpl({
    this.i_tieu_de,
    this.i_noi_dung,
    this.i_dia_diem,
    this.i_dinh_kem,
  });

  factory _$PhanAnhGopYModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$PhanAnhGopYModelImplFromJson(json);

  @override
  final String? i_tieu_de;
  @override
  final String? i_noi_dung;
  @override
  final String? i_dia_diem;
  @override
  final String? i_dinh_kem;

  @override
  String toString() {
    return 'PhanAnhGopYModel(i_tieu_de: $i_tieu_de, i_noi_dung: $i_noi_dung, i_dia_diem: $i_dia_diem, i_dinh_kem: $i_dinh_kem)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PhanAnhGopYModelImpl &&
            (identical(other.i_tieu_de, i_tieu_de) ||
                other.i_tieu_de == i_tieu_de) &&
            (identical(other.i_noi_dung, i_noi_dung) ||
                other.i_noi_dung == i_noi_dung) &&
            (identical(other.i_dia_diem, i_dia_diem) ||
                other.i_dia_diem == i_dia_diem) &&
            (identical(other.i_dinh_kem, i_dinh_kem) ||
                other.i_dinh_kem == i_dinh_kem));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode =>
      Object.hash(runtimeType, i_tieu_de, i_noi_dung, i_dia_diem, i_dinh_kem);

  /// Create a copy of PhanAnhGopYModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$PhanAnhGopYModelImplCopyWith<_$PhanAnhGopYModelImpl> get copyWith =>
      __$$PhanAnhGopYModelImplCopyWithImpl<_$PhanAnhGopYModelImpl>(
        this,
        _$identity,
      );

  @override
  Map<String, dynamic> toJson() {
    return _$$PhanAnhGopYModelImplToJson(this);
  }
}

abstract class _PhanAnhGopYModel implements PhanAnhGopYModel {
  const factory _PhanAnhGopYModel({
    final String? i_tieu_de,
    final String? i_noi_dung,
    final String? i_dia_diem,
    final String? i_dinh_kem,
  }) = _$PhanAnhGopYModelImpl;

  factory _PhanAnhGopYModel.fromJson(Map<String, dynamic> json) =
      _$PhanAnhGopYModelImpl.fromJson;

  @override
  String? get i_tieu_de;
  @override
  String? get i_noi_dung;
  @override
  String? get i_dia_diem;
  @override
  String? get i_dinh_kem;

  /// Create a copy of PhanAnhGopYModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$PhanAnhGopYModelImplCopyWith<_$PhanAnhGopYModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
