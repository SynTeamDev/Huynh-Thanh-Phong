import 'package:freezed_annotation/freezed_annotation.dart';

part 'quan_ly_cuoc_hop_model.freezed.dart';
part 'quan_ly_cuoc_hop_model.g.dart';

@freezed
class QuanLyCuocHopModel with _$QuanLyCuocHopModel {
  const factory QuanLyCuocHopModel({
    String? i_ten_cuochop,
    String? i_ten_cuochop2,
    String? i_noi_dung,
    String? i_tieu_de,
    String? i_ma_lcuochop,
    DateTime? i_ngay_hop,
    String? i_gio_bd,
    String? i_gio_kt,
    String? i_dia_chi,
    String? i_ds_chutri,
    String? i_ds_nguoithamgia,
    int? i_user_id_current,
  }) = _QuanLyCuocHopModel;

  factory QuanLyCuocHopModel.fromJson(Map<String, dynamic> json) =>
      _$QuanLyCuocHopModelFromJson(json);
}

