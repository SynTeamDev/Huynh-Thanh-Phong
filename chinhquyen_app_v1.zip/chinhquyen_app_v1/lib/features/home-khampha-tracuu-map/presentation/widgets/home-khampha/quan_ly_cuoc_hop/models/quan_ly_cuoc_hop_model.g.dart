// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'quan_ly_cuoc_hop_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$QuanLyCuocHopModelImpl _$$QuanLyCuocHopModelImplFromJson(
  Map<String, dynamic> json,
) => _$QuanLyCuocHopModelImpl(
  i_ten_cuochop: json['i_ten_cuochop'] as String?,
  i_ten_cuochop2: json['i_ten_cuochop2'] as String?,
  i_noi_dung: json['i_noi_dung'] as String?,
  i_tieu_de: json['i_tieu_de'] as String?,
  i_ma_lcuochop: json['i_ma_lcuochop'] as String?,
  i_ngay_hop: json['i_ngay_hop'] == null
      ? null
      : DateTime.parse(json['i_ngay_hop'] as String),
  i_gio_bd: json['i_gio_bd'] as String?,
  i_gio_kt: json['i_gio_kt'] as String?,
  i_dia_chi: json['i_dia_chi'] as String?,
  i_ds_chutri: json['i_ds_chutri'] as String?,
  i_ds_nguoithamgia: json['i_ds_nguoithamgia'] as String?,
  i_user_id_current: (json['i_user_id_current'] as num?)?.toInt(),
);

Map<String, dynamic> _$$QuanLyCuocHopModelImplToJson(
  _$QuanLyCuocHopModelImpl instance,
) => <String, dynamic>{
  'i_ten_cuochop': instance.i_ten_cuochop,
  'i_ten_cuochop2': instance.i_ten_cuochop2,
  'i_noi_dung': instance.i_noi_dung,
  'i_tieu_de': instance.i_tieu_de,
  'i_ma_lcuochop': instance.i_ma_lcuochop,
  'i_ngay_hop': instance.i_ngay_hop?.toIso8601String(),
  'i_gio_bd': instance.i_gio_bd,
  'i_gio_kt': instance.i_gio_kt,
  'i_dia_chi': instance.i_dia_chi,
  'i_ds_chutri': instance.i_ds_chutri,
  'i_ds_nguoithamgia': instance.i_ds_nguoithamgia,
  'i_user_id_current': instance.i_user_id_current,
};
