import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../../../core/network/api_provider.dart';

//! State lưu giá trị filter
final timkiemddFilterStateProvider =
    StateProvider<(DateTime, DateTime, String?, String?)?>((ref) => null);
//! State lấy danh sách
final timkiemddListProvider =
    StateNotifierProvider<
      TimKiemDiaDiemListNotifier,
      List<Map<String, dynamic>>
    >((ref) => TimKiemDiaDiemListNotifier(ref));

//! Api lazy loading
class TimKiemDiaDiemListNotifier
    extends StateNotifier<List<Map<String, dynamic>>> {
  TimKiemDiaDiemListNotifier(this.ref) : super([]) {
    fetchTimKiemDDList();
  }

  final Ref ref;
  int _pageIndex = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  Future<void> fetchTimKiemDDList() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;

    final filter = ref.read(timkiemddFilterStateProvider);
    final (ngay_ct1, ngay_ct2, ma_lhhd, ten_location) =
        filter ?? (null, null, null, null);

    final result = await ref
        .read(apiServiceProvider)
        .fetchDSTKDiaDiem(
          pageIndex: _pageIndex,
          ngay_ct1: ngay_ct1,
          ngay_ct2: ngay_ct2,
          ma_lhhd: ma_lhhd,
          ten_location: ten_location,
        );

    if (result.isEmpty) {
      _hasMore = false;
    } else {
      state = [...state, ...result];
      _pageIndex++;
    }

    _isLoading = false;
  }
}
