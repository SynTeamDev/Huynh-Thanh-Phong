import 'package:chinhquyen_app/core/widgets/custom_snackbar_widget.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../../../../core/widgets/custom_appbar_widget.dart';
import 'qr_scanner.dart';

class CheckinHoiNghiPage extends StatefulWidget {
  const CheckinHoiNghiPage({super.key, this.title = ''});
  final String title;

  @override
  State<CheckinHoiNghiPage> createState() => _CheckinHoiNghiPageState();
}

class _CheckinHoiNghiPageState extends State<CheckinHoiNghiPage> {
  @override
  void initState() {
    super.initState();
    // chạy sau khi build xong frame đầu tiên
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _startScan();
    });
  }

  Future<void> _startScan() async {
    final qr = await QrScanner.scan(context);
    if (qr != null) {
      final uri = Uri.tryParse(qr);

      if (uri != null && (uri.isScheme("http") || uri.isScheme("https"))) {
        if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
          showSnack(context, 'Không mở được link: $qr');
        }
      } else {
        showSnack(context, 'QR: $qr');
      }
    }
    // 👉 Nếu muốn quay lại sau khi quét xong thì:
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBarWidget(title: widget.title),
      body: const Center(child: Text("Đang mở camera để quét QR...")),
    );
  }
}
