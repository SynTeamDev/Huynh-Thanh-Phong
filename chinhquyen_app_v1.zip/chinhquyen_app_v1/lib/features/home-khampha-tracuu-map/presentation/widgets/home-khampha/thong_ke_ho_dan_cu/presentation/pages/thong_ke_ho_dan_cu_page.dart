import 'package:chinhquyen_app/core/widgets/custom_appbar_widget.dart';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class ThongKeHoDanCuPage extends StatefulWidget {
  const ThongKeHoDanCuPage({super.key, this.title = ''});
  final String title;

  @override
  State<ThongKeHoDanCuPage> createState() => _ThongKeHoDanCuPageState();
}

class _ThongKeHoDanCuPageState extends State<ThongKeHoDanCuPage> {
  Metric _selected = Metric.age; // mặc định: Độ tuổi

  @override
  Widget build(BuildContext context) {
    final data = _dataFor(_selected);
    final total = data.fold<num>(0, (s, e) => s + e.value);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBarWidget(
        title: widget.title.isEmpty ? 'Thống kê hộ dân cư' : widget.title,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _FilterChipsBar(
                selected: _selected,
                onSelected: (m) => setState(() => _selected = m),
              ),
              const SizedBox(height: 12),

              _ChartCard(
                title: _titleFor(_selected),
                child: SfCircularChart(
                  title: ChartTitle(
                    text: '',
                  ), // title đã hiển thị bên ngoài card
                  legend: const Legend(
                    isVisible: true,
                    position: LegendPosition.bottom,
                    overflowMode: LegendItemOverflowMode.wrap,
                  ),
                  tooltipBehavior: TooltipBehavior(enable: true),
                  annotations: <CircularChartAnnotation>[
                    CircularChartAnnotation(
                      widget: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            _formatNumber(total.toInt()),
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 18,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  series: [
                    DoughnutSeries<_Datum, String>(
                      dataSource: data,
                      xValueMapper: (d, _) => d.label,
                      yValueMapper: (d, _) => d.value,
                      pointColorMapper: (d, _) => d.color,
                      dataLabelMapper: (d, _) => _formatNumber(d.value),
                      dataLabelSettings: const DataLabelSettings(
                        isVisible: true,
                        textStyle: TextStyle(fontSize: 12),
                      ),
                      innerRadius: '48%',
                      radius: '90%',
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              _ChartCard(
                title: _barTitleFor(_selected),
                child: SfCartesianChart(
                  primaryXAxis: CategoryAxis(
                    majorGridLines: const MajorGridLines(width: 0),
                    labelStyle: const TextStyle(fontSize: 12),
                  ),
                  primaryYAxis: NumericAxis(
                    axisLine: const AxisLine(width: 0),
                    majorTickLines: const MajorTickLines(size: 0),
                    labelStyle: const TextStyle(fontSize: 12),
                  ),
                  tooltipBehavior: TooltipBehavior(enable: true),
                  series: [
                    ColumnSeries<_Datum, String>(
                      dataSource: data,
                      xValueMapper: (d, _) => d.label,
                      yValueMapper: (d, _) => d.value,
                      pointColorMapper: (d, _) => d.color,
                      dataLabelSettings: const DataLabelSettings(
                        isVisible: true,
                        textStyle: TextStyle(fontSize: 11),
                      ),
                      borderRadius: const BorderRadius.all(Radius.circular(6)),
                      width: 0.7,
                      spacing: 0.2,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/* -------------------------- Filter chips (top) -------------------------- */

class _FilterChipsBar extends StatelessWidget {
  const _FilterChipsBar({required this.selected, required this.onSelected});

  final Metric selected;
  final ValueChanged<Metric> onSelected;

  @override
  Widget build(BuildContext context) {
    final items = const <_ChipItem>[
      _ChipItem('Thường trú/ Tạm trú', Metric.residence),
      _ChipItem('Độ tuổi', Metric.age),
      _ChipItem('Tôn giáo', Metric.religion),
      _ChipItem('Giới tính', Metric.gender),
      _ChipItem('Trình độ văn hóa', Metric.education),
    ];

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: items.map((it) {
        final isSel = it.metric == selected;
        return ChoiceChip(
          label: Text(
            it.label,
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: isSel ? Colors.white : Colors.black87,
            ),
          ),
          selected: isSel,
          onSelected: (_) => onSelected(it.metric),
          showCheckmark: false,
          selectedColor: Colors.blue, // hồng/đỏ giống ảnh
          backgroundColor: const Color(0xFFF2F3F5), // xám nhạt
          shape: const StadiumBorder(),
          labelPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 0),
          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          visualDensity: const VisualDensity(horizontal: -2, vertical: -2),
        );
      }).toList(),
    );
  }
}

class _ChipItem {
  final String label;
  final Metric metric;
  const _ChipItem(this.label, this.metric);
}

/* ------------------------------ Card shell ------------------------------ */

class _ChartCard extends StatelessWidget {
  const _ChartCard({required this.title, required this.child});
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
          ),
          const SizedBox(height: 8),
          SizedBox(height: 280, child: child),
        ],
      ),
    );
  }
}

/* ------------------------------ Data models ----------------------------- */

enum Metric { residence, age, religion, gender, education }

class _Datum {
  final String label;
  final int value;
  final Color color;
  const _Datum(this.label, this.value, this.color);
}

String _titleFor(Metric m) {
  switch (m) {
    case Metric.age:
      return 'Thống kê về độ tuổi';
    case Metric.gender:
      return 'Thống kê giới tính';
    case Metric.religion:
      return 'Thống kê tôn giáo';
    case Metric.residence:
      return 'Thống kê thường trú / tạm trú';
    case Metric.education:
      return 'Thống kê trình độ văn hóa';
  }
}

String _barTitleFor(Metric m) {
  switch (m) {
    case Metric.age:
      return 'Biểu đồ cột theo nhóm tuổi';
    case Metric.gender:
      return 'Biểu đồ cột theo giới tính';
    case Metric.religion:
      return 'Biểu đồ cột theo tôn giáo';
    case Metric.residence:
      return 'Biểu đồ cột theo nơi cư trú';
    case Metric.education:
      return 'Biểu đồ cột theo trình độ';
  }
}

/* ---------------------------- Mock data sets ---------------------------- */

List<_Datum> _dataFor(Metric m) {
  switch (m) {
    case Metric.age:
      return const [
        _Datum('Trẻ sơ sinh', 820, Color(0xFF5C6BC0)),
        _Datum('Trẻ vào lớp 1', 3717, Color(0xFF3F51B5)),
        _Datum('Thanh niên NVQS', 3836, Color(0xFF64B5F6)),
        _Datum('Người già', 3717, Color(0xFFFFE082)),
        _Datum('Khác', 1678, Color(0xFFFFA726)),
      ];
    case Metric.gender:
      return const [
        _Datum('Nam', 6200, Color(0xFF42A5F5)),
        _Datum('Nữ', 5780, Color(0xFFAB47BC)),
        _Datum('Khác', 90, Color(0xFFFFA726)),
      ];
    case Metric.religion:
      return const [
        _Datum('Không tôn giáo', 6500, Color(0xFF90CAF9)),
        _Datum('Phật giáo', 2400, Color(0xFFFFCC80)),
        _Datum('Công giáo', 1900, Color(0xFFCE93D8)),
        _Datum('Khác', 1189, Color(0xFFA5D6A7)),
      ];
    case Metric.residence:
      return const [
        _Datum('Thường trú', 9250, Color(0xFF64B5F6)),
        _Datum('Tạm trú', 2739, Color(0xFFFFA726)),
      ];
    case Metric.education:
      return const [
        _Datum('Tiểu học', 2100, Color(0xFFFFCC80)),
        _Datum('THCS', 3400, Color(0xFF81D4FA)),
        _Datum('THPT', 2800, Color(0xFFA5D6A7)),
        _Datum('CĐ/ĐH', 1800, Color(0xFFCE93D8)),
        _Datum('Sau ĐH', 350, Color(0xFF5C6BC0)),
      ];
  }
}

/* ------------------------------- Utilities ------------------------------ */

String _formatNumber(int n) {
  final s = n.toString();
  final buf = StringBuffer();
  for (int i = 0; i < s.length; i++) {
    final pos = s.length - i;
    buf.write(s[i]);
    if (pos > 1 && pos % 3 == 1) buf.write(',');
  }
  return buf.toString();
}
