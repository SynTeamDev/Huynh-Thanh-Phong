import 'package:chinhquyen_app/core/widgets/custom_appbar_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:ionicons/ionicons.dart';
import '../../../../../../../../core/utils/date_helper.dart';
import '../../../../../../../../core/utils/delay_btn_helper.dart';
import '../../../../../../../../core/widgets/form/label_value_row.dart';
import '../../../quan_ly_cuoc_hop/presentation/widgets/single_action_button.dart';
import '../providers/phan_anh_gop_y_provider.dart';

class PhanAnhGopYPage extends ConsumerStatefulWidget {
  const PhanAnhGopYPage({super.key, this.title = ''});
  final String title;

  @override
  ConsumerState<PhanAnhGopYPage> createState() => _PhanAnhGopYPageState();
}

class _PhanAnhGopYPageState extends ConsumerState<PhanAnhGopYPage> {
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  Future<void> _onRefreshPressed() async {
    if (!GlobalButtonDisableHelper.isDisabled) {
      GlobalButtonDisableHelper.disableTemporarily(seconds: 1);
      setState(() {});

      // ✅ Quan trọng: trigger lại gọi API
      ref.invalidate(phananhgopyListProvider);
    }
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 100) {
      ref.read(phananhgopyListProvider.notifier).fetchPhanAnhGopYList();
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final phanAnhList = ref.watch(phananhgopyListProvider);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBarWidget(
        title: widget.title,
        actions: [
          IconButton(
            icon: const Icon(Ionicons.refresh, color: Colors.blue),
            onPressed: () {
              _onRefreshPressed();
            },
          ),
        ],
      ),
      body: Scrollbar(
        controller: _scrollController,
        thumbVisibility: true,
        thickness: 6,
        radius: const Radius.circular(10),
        child: ListView.builder(
          controller: _scrollController,
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
          itemCount: phanAnhList.length,
          itemBuilder: (context, index) {
            final item = phanAnhList[index];
            return Container(
              margin: const EdgeInsets.only(bottom: 2),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.8),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade200),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  LayoutBuilder(
                    builder: (context, constraints) {
                      final maxW =
                          constraints.maxWidth *
                          0.80; // pill tối đa 97% chiều ngang
                      return Row(
                        children: [
                          const Text(
                            'Tiêu đề: ',
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.grey,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const Spacer(),
                          ConstrainedBox(
                            constraints: BoxConstraints(maxWidth: maxW),
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(8),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.green.withOpacity(0.12),
                                    blurRadius: 6,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Flexible(
                                    child: Text(
                                      item['tieu_de'] ?? '',
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: Colors.black87,
                                        fontSize: 12.5,
                                        fontWeight: FontWeight.w600,
                                        height: 1.1,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),

                  LabelValueRow(
                    label: '',
                    labelWidget: RichText(
                      textAlign: TextAlign.left,
                      text: TextSpan(
                        style: const TextStyle(fontSize: 13),
                        children: [
                          const TextSpan(
                            text: 'Ngày tạo: ',
                            style: TextStyle(
                              color: Colors.grey, // 👈 Chữ xám
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          TextSpan(
                            text: formatDate(item['ngay_tao']),
                            style: const TextStyle(
                              color: Colors.black87,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    value: '',
                    valueWidget: Align(
                      alignment: Alignment.centerRight,
                      child: Row(
                        mainAxisSize: MainAxisSize
                            .min, // ✅ không chiếm full width -> đỡ tràn
                        children: [
                          const Text(
                            'Trạng thái: ',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Flexible(
                            // ✅ cho phép badge co lại trong ô bên phải
                            child: _StatusBadgeCompact(
                              status: item['status'].toString(),
                            ),
                          ),
                        ],
                      ),
                    ),

                    maxHeight: 32,
                  ),
                ],
              ),
            );
          },
        ),
      ),

      floatingActionButton: SingleActionButton(
        onPressedAsync: _onAdd, // 👈 truyền thẳng hàm async
        child: const Icon(Icons.add, size: 28, color: Colors.black87),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }

  Future<void> _onAdd() async {
    final result = await context.push('/phananhgopyAdd');
    if (result == true) {
      _onRefreshPressed(); // ✅ Làm mới sau khi thêm thành công
    }
  }
}

class _StatusBadgeCompact extends StatelessWidget {
  const _StatusBadgeCompact({required this.status});
  final String status;

  @override
  Widget build(BuildContext context) {
    // map status -> text & color
    String text;
    Color color;
    switch (status) {
      case '1':
        text = 'Mới tạo';
        color = Colors.green;
        break;
      case '2':
        text = 'Đã tiếp nhận';
        color = Colors.blue;
        break;
      case '3':
        text = 'Đã phê duyệt';
        color = Colors.amber;
        break;
      default:
        text = 'Không xác định';
        color = Colors.grey;
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        // Giới hạn tối đa theo không gian thực tế của cột phải
        final maxW = constraints.maxWidth; // cột phải
        final cap = maxW * 0.999; // badge tối đa 60% ô phải (tuỳ chỉnh)

        return ConstrainedBox(
          constraints: BoxConstraints(maxWidth: cap),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis, // ✅ cắt gọn
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        );
      },
    );
  }
}
