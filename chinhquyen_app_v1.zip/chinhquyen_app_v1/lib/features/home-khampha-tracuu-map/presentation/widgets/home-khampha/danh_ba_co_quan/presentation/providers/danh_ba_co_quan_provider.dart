import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../../../core/network/api_provider.dart';

//! State lưu giá trị filter
final danhbacoquanFilterStateProvider =
    StateProvider<(DateTime, DateTime, String?, String?, String?)?>(
      (ref) => null,
    );
//! State lấy danh sách
final danhbacoquanListProvider =
    StateNotifierProvider<DanhBaCoQuanListNotifier, List<Map<String, dynamic>>>(
      (ref) => DanhBaCoQuanListNotifier(ref),
    );

//! Api lazy loading
class DanhBaCoQuanListNotifier
    extends StateNotifier<List<Map<String, dynamic>>> {
  DanhBaCoQuanListNotifier(this.ref) : super([]) {
    fetchDanhBaCoQuanList();
  }

  final Ref ref;
  int _pageIndex = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  Future<void> fetchDanhBaCoQuanList() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;

    final filter = ref.read(danhbacoquanFilterStateProvider);
    final (ngay_ct1, ngay_ct2, ma_loai, ma_ttp, ma_phuongxa) =
        filter ?? (null, null, null, null, null);

    final result = await ref
        .read(apiServiceProvider)
        .fetchDanhBaCoQuan(
          pageIndex: _pageIndex,
          ngay_ct1: ngay_ct1,
          ngay_ct2: ngay_ct2,
          ma_loai: ma_loai,
          ma_ttp: ma_ttp,
          ma_phuongxa: ma_phuongxa,
        );

    if (result.isEmpty) {
      _hasMore = false;
    } else {
      state = [...state, ...result];
      _pageIndex++;
    }

    _isLoading = false;
  }
}
