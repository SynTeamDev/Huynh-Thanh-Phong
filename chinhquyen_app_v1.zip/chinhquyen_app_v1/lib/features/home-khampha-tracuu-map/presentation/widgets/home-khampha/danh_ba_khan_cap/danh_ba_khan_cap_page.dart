import 'package:chinhquyen_app/core/widgets/custom_appbar_widget.dart';
import 'package:flutter/material.dart';

import '../../../../../../core/utils/handle_tel_call.dart';

class DanhBaKhanCapPage extends StatelessWidget {
  const DanhBaKhanCapPage({super.key, this.title = ''});
  final String title;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBarWidget(
        title: title.isEmpty ? 'Danh bạ khẩn cấp' : title,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Hàng nút gọi nhanh
              Wrap(
                spacing: 12,
                runSpacing: 12,
                children: const [
                  _EmergencyChip(
                    label: 'Công an',
                    number: '113',
                    bg: Color(0xFFE3F2FD),
                    fg: Color(0xFF1565C0),
                    icon: Icons.local_police,
                  ),
                  _EmergencyChip(
                    label: 'Cứu hoả',
                    number: '114',
                    bg: Color(0xFFFFEBEE),
                    fg: Color(0xFFC62828),
                    icon: Icons.local_fire_department,
                  ),
                  _EmergencyChip(
                    label: 'Cấp cứu',
                    number: '115',
                    bg: Color(0xFFE8F5E9),
                    fg: Color(0xFF2E7D32),
                    icon: Icons.medical_services_outlined,
                  ),
                ],
              ),
              const SizedBox(height: 16),

              const Text(
                'Danh sách',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
              ),
              const SizedBox(height: 12),

              // Danh sách thẻ đẹp
              const _EmergencyCard(
                title: 'Công an',
                subtitle: 'Gọi khẩn cấp khi có trộm cướp, gây rối trật tự...',
                number: '113',
                startColor: Color(0xFFE3F2FD),
                endColor: Color(0xFFBBDEFB),
                icon: Icons.local_police,
                iconBg: Color(0xFF1565C0),
              ),
              const SizedBox(height: 12),
              const _EmergencyCard(
                title: 'Cứu hoả',
                subtitle: 'Báo cháy, cứu nạn – cứu hộ liên quan đến hoả hoạn',
                number: '114',
                startColor: Color(0xFFFFEBEE),
                endColor: Color(0xFFFFCDD2),
                icon: Icons.local_fire_department,
                iconBg: Color(0xFFC62828),
              ),
              const SizedBox(height: 12),
              const _EmergencyCard(
                title: 'Cấp cứu',
                subtitle: 'Tai nạn, cấp cứu y tế, cần hỗ trợ xe cứu thương',
                number: '115',
                startColor: Color(0xFFE8F5E9),
                endColor: Color(0xFFC8E6C9),
                icon: Icons.medical_services_outlined,
                iconBg: Color(0xFF2E7D32),
              ),

              const SizedBox(height: 16),
              Text(
                'Chỉ sử dụng các số này trong trường hợp khẩn cấp.',
                style: TextStyle(color: Colors.grey[700], fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Chip gọi nhanh
class _EmergencyChip extends StatelessWidget {
  const _EmergencyChip({
    required this.label,
    required this.number,
    required this.bg,
    required this.fg,
    required this.icon,
  });

  final String label;
  final String number;
  final Color bg;
  final Color fg;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: bg,
      borderRadius: BorderRadius.circular(24),
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: () => handleTelCall(number),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 18, color: fg),
              const SizedBox(width: 8),
              Text(
                '$label',
                style: TextStyle(color: fg, fontWeight: FontWeight.w600),
              ),
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  number,
                  style: TextStyle(color: fg, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Thẻ danh sách đẹp
class _EmergencyCard extends StatelessWidget {
  const _EmergencyCard({
    required this.title,
    required this.subtitle,
    required this.number,
    required this.startColor,
    required this.endColor,
    required this.icon,
    required this.iconBg,
  });

  final String title;
  final String subtitle;
  final String number;
  final Color startColor;
  final Color endColor;
  final IconData icon;
  final Color iconBg;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => handleTelCall(number),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        height: 92,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [startColor, endColor],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          children: [
            // Icon tròn
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(color: iconBg, shape: BoxShape.circle),
              child: Icon(icon, color: Colors.white, size: 26),
            ),
            const SizedBox(width: 12),

            // Text
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: Colors.grey.shade800,
                      fontSize: 12.5,
                      height: 1.2,
                    ),
                  ),
                ],
              ),
            ),

            // Nút gọi
            ElevatedButton.icon(
              onPressed: () => handleTelCall(number),
              icon: const Icon(Icons.call, size: 18),
              label: Text('Gọi $number'),
              style: ElevatedButton.styleFrom(
                elevation: 0,
                foregroundColor: Colors.white,
                backgroundColor: Colors.black87,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 10,
                ),
                textStyle: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
