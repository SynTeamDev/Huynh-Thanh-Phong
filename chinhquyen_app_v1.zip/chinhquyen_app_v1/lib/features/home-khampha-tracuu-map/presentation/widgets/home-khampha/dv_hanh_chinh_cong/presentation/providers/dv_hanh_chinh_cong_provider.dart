import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../../../core/network/api_provider.dart';

//! State lưu giá trị filter
final dvhanhchinhcongFilterStateProvider =
    StateProvider<(DateTime, DateTime, String?)?>((ref) => null);
//! State lấy danh sách
final dvhanhchinhcongListProvider =
    StateNotifierProvider<
      DVHanhChinhCongListNotifier,
      List<Map<String, dynamic>>
    >((ref) => DVHanhChinhCongListNotifier(ref));

//! Api lazy loading
class DVHanhChinhCongListNotifier
    extends StateNotifier<List<Map<String, dynamic>>> {
  DVHanhChinhCongListNotifier(this.ref) : super([]) {
    fetchDVHanhChinhCongList();
  }

  final Ref ref;
  int _pageIndex = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  Future<void> fetchDVHanhChinhCongList() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;

    final filter = ref.read(dvhanhchinhcongFilterStateProvider);
    final (ngay_ct1, ngay_ct2, ma_hccong) = filter ?? (null, null, null);

    final result = await ref
        .read(apiServiceProvider)
        .fetchDVHanhChinhCong(
          pageIndex: _pageIndex,
          ngay_ct1: ngay_ct1,
          ngay_ct2: ngay_ct2,
          ma_hccong: ma_hccong,
        );

    if (result.isEmpty) {
      _hasMore = false;
    } else {
      state = [...state, ...result];
      _pageIndex++;
    }

    _isLoading = false;
  }
}
