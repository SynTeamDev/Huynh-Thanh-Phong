import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';

class AttachmentPicker extends StatelessWidget {
  const AttachmentPicker({
    super.key,
    this.onPickPhoto,
    this.onPickVideo,
    this.onPickFile,
  });

  final VoidCallback? onPickPhoto;
  final VoidCallback? onPickVideo;
  final VoidCallback? onPickFile;

  @override
  Widget build(BuildContext context) {
    return DottedBorder(
      color: const Color(0xFFB3D4FF), // xanh nhạt viền
      dashPattern: const [6, 4],
      borderType: BorderType.RRect,
      radius: const Radius.circular(10),
      strokeWidth: 2,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: const Color(0xFFF6FAFF), // nền xanh nhạt
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.only(left: 2, bottom: 6),
              child: Text(
                'Đính kèm văn bản, hình ảnh:',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _ActionChip(
                  assetPath: 'assets/icons/attach_picture.png',
                  label: 'Photo',
                  color: Colors.orange,
                  onTap: onPickPhoto,
                ),
                const SizedBox(width: 30),
                _ActionChip(
                  assetPath: 'assets/icons/attach_video.png',
                  label: 'Video',
                  color: Colors.red,
                  onTap: onPickVideo,
                ),
                const SizedBox(width: 30),
                _ActionChip(
                  assetPath: 'assets/icons/attach_folder.png',
                  label: 'File',
                  color: Colors.blue,
                  onTap: onPickFile,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionChip extends StatelessWidget {
  const _ActionChip({
    this.assetPath,
    required this.label,
    required this.color,
    this.onTap,
  });

  final String? assetPath; // icon từ asset
  final String label;
  final Color color;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: onTap,
      child: Row(
        children: [
          Image.asset(assetPath!, width: 22, height: 22),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
