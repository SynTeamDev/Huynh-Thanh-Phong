// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'quan_ly_cuoc_hop_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
  'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models',
);

QuanLyCuocHopModel _$QuanLyCuocHopModelFromJson(Map<String, dynamic> json) {
  return _QuanLyCuocHopModel.fromJson(json);
}

/// @nodoc
mixin _$QuanLyCuocHopModel {
  String? get i_ten_cuochop => throw _privateConstructorUsedError;
  String? get i_ten_cuochop2 => throw _privateConstructorUsedError;
  String? get i_noi_dung => throw _privateConstructorUsedError;
  String? get i_tieu_de => throw _privateConstructorUsedError;
  String? get i_ma_lcuochop => throw _privateConstructorUsedError;
  DateTime? get i_ngay_hop => throw _privateConstructorUsedError;
  String? get i_gio_bd => throw _privateConstructorUsedError;
  String? get i_gio_kt => throw _privateConstructorUsedError;
  String? get i_dia_chi => throw _privateConstructorUsedError;
  String? get i_ds_chutri => throw _privateConstructorUsedError;
  String? get i_ds_nguoithamgia => throw _privateConstructorUsedError;
  int? get i_user_id_current => throw _privateConstructorUsedError;

  /// Serializes this QuanLyCuocHopModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of QuanLyCuocHopModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $QuanLyCuocHopModelCopyWith<QuanLyCuocHopModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $QuanLyCuocHopModelCopyWith<$Res> {
  factory $QuanLyCuocHopModelCopyWith(
    QuanLyCuocHopModel value,
    $Res Function(QuanLyCuocHopModel) then,
  ) = _$QuanLyCuocHopModelCopyWithImpl<$Res, QuanLyCuocHopModel>;
  @useResult
  $Res call({
    String? i_ten_cuochop,
    String? i_ten_cuochop2,
    String? i_noi_dung,
    String? i_tieu_de,
    String? i_ma_lcuochop,
    DateTime? i_ngay_hop,
    String? i_gio_bd,
    String? i_gio_kt,
    String? i_dia_chi,
    String? i_ds_chutri,
    String? i_ds_nguoithamgia,
    int? i_user_id_current,
  });
}

/// @nodoc
class _$QuanLyCuocHopModelCopyWithImpl<$Res, $Val extends QuanLyCuocHopModel>
    implements $QuanLyCuocHopModelCopyWith<$Res> {
  _$QuanLyCuocHopModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of QuanLyCuocHopModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? i_ten_cuochop = freezed,
    Object? i_ten_cuochop2 = freezed,
    Object? i_noi_dung = freezed,
    Object? i_tieu_de = freezed,
    Object? i_ma_lcuochop = freezed,
    Object? i_ngay_hop = freezed,
    Object? i_gio_bd = freezed,
    Object? i_gio_kt = freezed,
    Object? i_dia_chi = freezed,
    Object? i_ds_chutri = freezed,
    Object? i_ds_nguoithamgia = freezed,
    Object? i_user_id_current = freezed,
  }) {
    return _then(
      _value.copyWith(
            i_ten_cuochop: freezed == i_ten_cuochop
                ? _value.i_ten_cuochop
                : i_ten_cuochop // ignore: cast_nullable_to_non_nullable
                      as String?,
            i_ten_cuochop2: freezed == i_ten_cuochop2
                ? _value.i_ten_cuochop2
                : i_ten_cuochop2 // ignore: cast_nullable_to_non_nullable
                      as String?,
            i_noi_dung: freezed == i_noi_dung
                ? _value.i_noi_dung
                : i_noi_dung // ignore: cast_nullable_to_non_nullable
                      as String?,
            i_tieu_de: freezed == i_tieu_de
                ? _value.i_tieu_de
                : i_tieu_de // ignore: cast_nullable_to_non_nullable
                      as String?,
            i_ma_lcuochop: freezed == i_ma_lcuochop
                ? _value.i_ma_lcuochop
                : i_ma_lcuochop // ignore: cast_nullable_to_non_nullable
                      as String?,
            i_ngay_hop: freezed == i_ngay_hop
                ? _value.i_ngay_hop
                : i_ngay_hop // ignore: cast_nullable_to_non_nullable
                      as DateTime?,
            i_gio_bd: freezed == i_gio_bd
                ? _value.i_gio_bd
                : i_gio_bd // ignore: cast_nullable_to_non_nullable
                      as String?,
            i_gio_kt: freezed == i_gio_kt
                ? _value.i_gio_kt
                : i_gio_kt // ignore: cast_nullable_to_non_nullable
                      as String?,
            i_dia_chi: freezed == i_dia_chi
                ? _value.i_dia_chi
                : i_dia_chi // ignore: cast_nullable_to_non_nullable
                      as String?,
            i_ds_chutri: freezed == i_ds_chutri
                ? _value.i_ds_chutri
                : i_ds_chutri // ignore: cast_nullable_to_non_nullable
                      as String?,
            i_ds_nguoithamgia: freezed == i_ds_nguoithamgia
                ? _value.i_ds_nguoithamgia
                : i_ds_nguoithamgia // ignore: cast_nullable_to_non_nullable
                      as String?,
            i_user_id_current: freezed == i_user_id_current
                ? _value.i_user_id_current
                : i_user_id_current // ignore: cast_nullable_to_non_nullable
                      as int?,
          )
          as $Val,
    );
  }
}

/// @nodoc
abstract class _$$QuanLyCuocHopModelImplCopyWith<$Res>
    implements $QuanLyCuocHopModelCopyWith<$Res> {
  factory _$$QuanLyCuocHopModelImplCopyWith(
    _$QuanLyCuocHopModelImpl value,
    $Res Function(_$QuanLyCuocHopModelImpl) then,
  ) = __$$QuanLyCuocHopModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({
    String? i_ten_cuochop,
    String? i_ten_cuochop2,
    String? i_noi_dung,
    String? i_tieu_de,
    String? i_ma_lcuochop,
    DateTime? i_ngay_hop,
    String? i_gio_bd,
    String? i_gio_kt,
    String? i_dia_chi,
    String? i_ds_chutri,
    String? i_ds_nguoithamgia,
    int? i_user_id_current,
  });
}

/// @nodoc
class __$$QuanLyCuocHopModelImplCopyWithImpl<$Res>
    extends _$QuanLyCuocHopModelCopyWithImpl<$Res, _$QuanLyCuocHopModelImpl>
    implements _$$QuanLyCuocHopModelImplCopyWith<$Res> {
  __$$QuanLyCuocHopModelImplCopyWithImpl(
    _$QuanLyCuocHopModelImpl _value,
    $Res Function(_$QuanLyCuocHopModelImpl) _then,
  ) : super(_value, _then);

  /// Create a copy of QuanLyCuocHopModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? i_ten_cuochop = freezed,
    Object? i_ten_cuochop2 = freezed,
    Object? i_noi_dung = freezed,
    Object? i_tieu_de = freezed,
    Object? i_ma_lcuochop = freezed,
    Object? i_ngay_hop = freezed,
    Object? i_gio_bd = freezed,
    Object? i_gio_kt = freezed,
    Object? i_dia_chi = freezed,
    Object? i_ds_chutri = freezed,
    Object? i_ds_nguoithamgia = freezed,
    Object? i_user_id_current = freezed,
  }) {
    return _then(
      _$QuanLyCuocHopModelImpl(
        i_ten_cuochop: freezed == i_ten_cuochop
            ? _value.i_ten_cuochop
            : i_ten_cuochop // ignore: cast_nullable_to_non_nullable
                  as String?,
        i_ten_cuochop2: freezed == i_ten_cuochop2
            ? _value.i_ten_cuochop2
            : i_ten_cuochop2 // ignore: cast_nullable_to_non_nullable
                  as String?,
        i_noi_dung: freezed == i_noi_dung
            ? _value.i_noi_dung
            : i_noi_dung // ignore: cast_nullable_to_non_nullable
                  as String?,
        i_tieu_de: freezed == i_tieu_de
            ? _value.i_tieu_de
            : i_tieu_de // ignore: cast_nullable_to_non_nullable
                  as String?,
        i_ma_lcuochop: freezed == i_ma_lcuochop
            ? _value.i_ma_lcuochop
            : i_ma_lcuochop // ignore: cast_nullable_to_non_nullable
                  as String?,
        i_ngay_hop: freezed == i_ngay_hop
            ? _value.i_ngay_hop
            : i_ngay_hop // ignore: cast_nullable_to_non_nullable
                  as DateTime?,
        i_gio_bd: freezed == i_gio_bd
            ? _value.i_gio_bd
            : i_gio_bd // ignore: cast_nullable_to_non_nullable
                  as String?,
        i_gio_kt: freezed == i_gio_kt
            ? _value.i_gio_kt
            : i_gio_kt // ignore: cast_nullable_to_non_nullable
                  as String?,
        i_dia_chi: freezed == i_dia_chi
            ? _value.i_dia_chi
            : i_dia_chi // ignore: cast_nullable_to_non_nullable
                  as String?,
        i_ds_chutri: freezed == i_ds_chutri
            ? _value.i_ds_chutri
            : i_ds_chutri // ignore: cast_nullable_to_non_nullable
                  as String?,
        i_ds_nguoithamgia: freezed == i_ds_nguoithamgia
            ? _value.i_ds_nguoithamgia
            : i_ds_nguoithamgia // ignore: cast_nullable_to_non_nullable
                  as String?,
        i_user_id_current: freezed == i_user_id_current
            ? _value.i_user_id_current
            : i_user_id_current // ignore: cast_nullable_to_non_nullable
                  as int?,
      ),
    );
  }
}

/// @nodoc
@JsonSerializable()
class _$QuanLyCuocHopModelImpl implements _QuanLyCuocHopModel {
  const _$QuanLyCuocHopModelImpl({
    this.i_ten_cuochop,
    this.i_ten_cuochop2,
    this.i_noi_dung,
    this.i_tieu_de,
    this.i_ma_lcuochop,
    this.i_ngay_hop,
    this.i_gio_bd,
    this.i_gio_kt,
    this.i_dia_chi,
    this.i_ds_chutri,
    this.i_ds_nguoithamgia,
    this.i_user_id_current,
  });

  factory _$QuanLyCuocHopModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$QuanLyCuocHopModelImplFromJson(json);

  @override
  final String? i_ten_cuochop;
  @override
  final String? i_ten_cuochop2;
  @override
  final String? i_noi_dung;
  @override
  final String? i_tieu_de;
  @override
  final String? i_ma_lcuochop;
  @override
  final DateTime? i_ngay_hop;
  @override
  final String? i_gio_bd;
  @override
  final String? i_gio_kt;
  @override
  final String? i_dia_chi;
  @override
  final String? i_ds_chutri;
  @override
  final String? i_ds_nguoithamgia;
  @override
  final int? i_user_id_current;

  @override
  String toString() {
    return 'QuanLyCuocHopModel(i_ten_cuochop: $i_ten_cuochop, i_ten_cuochop2: $i_ten_cuochop2, i_noi_dung: $i_noi_dung, i_tieu_de: $i_tieu_de, i_ma_lcuochop: $i_ma_lcuochop, i_ngay_hop: $i_ngay_hop, i_gio_bd: $i_gio_bd, i_gio_kt: $i_gio_kt, i_dia_chi: $i_dia_chi, i_ds_chutri: $i_ds_chutri, i_ds_nguoithamgia: $i_ds_nguoithamgia, i_user_id_current: $i_user_id_current)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$QuanLyCuocHopModelImpl &&
            (identical(other.i_ten_cuochop, i_ten_cuochop) ||
                other.i_ten_cuochop == i_ten_cuochop) &&
            (identical(other.i_ten_cuochop2, i_ten_cuochop2) ||
                other.i_ten_cuochop2 == i_ten_cuochop2) &&
            (identical(other.i_noi_dung, i_noi_dung) ||
                other.i_noi_dung == i_noi_dung) &&
            (identical(other.i_tieu_de, i_tieu_de) ||
                other.i_tieu_de == i_tieu_de) &&
            (identical(other.i_ma_lcuochop, i_ma_lcuochop) ||
                other.i_ma_lcuochop == i_ma_lcuochop) &&
            (identical(other.i_ngay_hop, i_ngay_hop) ||
                other.i_ngay_hop == i_ngay_hop) &&
            (identical(other.i_gio_bd, i_gio_bd) ||
                other.i_gio_bd == i_gio_bd) &&
            (identical(other.i_gio_kt, i_gio_kt) ||
                other.i_gio_kt == i_gio_kt) &&
            (identical(other.i_dia_chi, i_dia_chi) ||
                other.i_dia_chi == i_dia_chi) &&
            (identical(other.i_ds_chutri, i_ds_chutri) ||
                other.i_ds_chutri == i_ds_chutri) &&
            (identical(other.i_ds_nguoithamgia, i_ds_nguoithamgia) ||
                other.i_ds_nguoithamgia == i_ds_nguoithamgia) &&
            (identical(other.i_user_id_current, i_user_id_current) ||
                other.i_user_id_current == i_user_id_current));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
    runtimeType,
    i_ten_cuochop,
    i_ten_cuochop2,
    i_noi_dung,
    i_tieu_de,
    i_ma_lcuochop,
    i_ngay_hop,
    i_gio_bd,
    i_gio_kt,
    i_dia_chi,
    i_ds_chutri,
    i_ds_nguoithamgia,
    i_user_id_current,
  );

  /// Create a copy of QuanLyCuocHopModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$QuanLyCuocHopModelImplCopyWith<_$QuanLyCuocHopModelImpl> get copyWith =>
      __$$QuanLyCuocHopModelImplCopyWithImpl<_$QuanLyCuocHopModelImpl>(
        this,
        _$identity,
      );

  @override
  Map<String, dynamic> toJson() {
    return _$$QuanLyCuocHopModelImplToJson(this);
  }
}

abstract class _QuanLyCuocHopModel implements QuanLyCuocHopModel {
  const factory _QuanLyCuocHopModel({
    final String? i_ten_cuochop,
    final String? i_ten_cuochop2,
    final String? i_noi_dung,
    final String? i_tieu_de,
    final String? i_ma_lcuochop,
    final DateTime? i_ngay_hop,
    final String? i_gio_bd,
    final String? i_gio_kt,
    final String? i_dia_chi,
    final String? i_ds_chutri,
    final String? i_ds_nguoithamgia,
    final int? i_user_id_current,
  }) = _$QuanLyCuocHopModelImpl;

  factory _QuanLyCuocHopModel.fromJson(Map<String, dynamic> json) =
      _$QuanLyCuocHopModelImpl.fromJson;

  @override
  String? get i_ten_cuochop;
  @override
  String? get i_ten_cuochop2;
  @override
  String? get i_noi_dung;
  @override
  String? get i_tieu_de;
  @override
  String? get i_ma_lcuochop;
  @override
  DateTime? get i_ngay_hop;
  @override
  String? get i_gio_bd;
  @override
  String? get i_gio_kt;
  @override
  String? get i_dia_chi;
  @override
  String? get i_ds_chutri;
  @override
  String? get i_ds_nguoithamgia;
  @override
  int? get i_user_id_current;

  /// Create a copy of QuanLyCuocHopModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$QuanLyCuocHopModelImplCopyWith<_$QuanLyCuocHopModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
