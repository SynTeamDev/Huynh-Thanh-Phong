import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../../../core/shared/base_filter.dart';
import '../../../../../../../../core/widgets/form/combobox_field_widget.dart';
import '../../../../../../../../core/widgets/form/input_field_widget.dart';

class QLCuocHopFilter
    extends BaseFilter<(DateTime, DateTime, String?, String?, String?)> {
  final (String?, String?, String?)? initialValues;

  const QLCuocHopFilter({
    super.key,
    required super.initialFromDate,
    required super.initialToDate,
    this.initialValues,
    // ẩn ngày tháng
    //super.showDateFields = false,
  });

  @override
  ConsumerState<QLCuocHopFilter> createState() =>
      _QLCuocHopFilterConsumerState();
}

class _QLCuocHopFilterConsumerState
    extends
        BaseFilterState<
          (DateTime, DateTime, String?, String?, String?),
          QLCuocHopFilter
        > {
  String? _ma_lcuochop, _dia_chi, status;
  late TextEditingController _dia_chiController;

  @override
  void initState() {
    super.initState();
    _dia_chiController = TextEditingController();

    final initial = widget.initialValues;
    if (initial != null) {
      _ma_lcuochop = initial.$1;
      _dia_chi = initial.$2;
      status = initial.$3;

      _dia_chiController.text = _dia_chi ?? '';
    }
  }

  @override
  void dispose() {
    _dia_chiController.dispose();
    super.dispose();
  }

  @override
  List<Widget> buildFilterFields() {
    return [
      ComboboxFieldWidget(
        label: 'Loại cuộc họp',
        tableName: 'dmlcuochop',
        selectedValue: _ma_lcuochop,
        onChanged: (value) {
          setState(() {
            _ma_lcuochop = value;
          });
        },
        isCode: false,
      ),
      const SizedBox(height: 5),
      InputFieldWidget(
        label: 'Địa điểm',
        controller: _dia_chiController,
        hintText: 'Nhập địa điểm',
        onChanged: (value) {
          setState(() {
            _dia_chi = value;
          });
        },
      ),
      const SizedBox(height: 5),
      ComboboxFieldWidget(
        label: 'Trạng thái',
        tableName: 'ttqlcuochop',
        selectedValue: status,
        onChanged: (value) {
          setState(() {
            status = value;
          });
        },
        isCode: false,
      ),
    ];
  }

  @override
  (DateTime, DateTime, String?, String?, String?) getFilterResult() {
    return (fromDate, toDate, _ma_lcuochop, _dia_chi, status);
  }
}
