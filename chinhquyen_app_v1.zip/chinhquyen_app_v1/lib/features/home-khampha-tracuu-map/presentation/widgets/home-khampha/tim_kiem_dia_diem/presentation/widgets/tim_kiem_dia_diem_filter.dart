import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../../../core/shared/base_filter.dart';
import '../../../../../../../../core/widgets/form/input_field_widget.dart';
import '../../../../../../../../core/widgets/form/popup_search_field_widget.dart';

class TimKiemDiaDiemFilter
    extends BaseFilter<(DateTime, DateTime, String?, String?)> {
  final (String?, String?)? initialValues;

  const TimKiemDiaDiemFilter({
    super.key,
    required super.initialFromDate,
    required super.initialToDate,
    this.initialValues,
    // ẩn ngày tháng
    super.showDateFields = false,
  });

  @override
  ConsumerState<TimKiemDiaDiemFilter> createState() =>
      _TimKiemDiaDiemFilterConsumerState();
}

class _TimKiemDiaDiemFilterConsumerState
    extends
        BaseFilterState<
          (DateTime, DateTime, String?, String?),
          TimKiemDiaDiemFilter
        > {
  String? ma_lhhd, ten_location;
  late TextEditingController _ten_locationController;

  @override
  void initState() {
    super.initState();
    _ten_locationController = TextEditingController();

    final initial = widget.initialValues;
    if (initial != null) {
      ma_lhhd = initial.$1;
      ten_location = initial.$2;

      _ten_locationController.text = ten_location ?? '';
    }
  }

  @override
  void dispose() {
    _ten_locationController.dispose();
    super.dispose();
  }

  @override
  List<Widget> buildFilterFields() {
    return [
      PopupSearchFieldWidget(
        label: 'Loại hình hoạt động',
        tableName: 'dmlhhd',
        selectedValue: ma_lhhd,
        onChanged: (value) {
          setState(() {
            ma_lhhd = value;
          });
        },
        isCode: false,
      ),
      const SizedBox(height: 5),
      InputFieldWidget(
        label: 'Tên địa điểm',
        controller: _ten_locationController,
        hintText: 'Nhập tên địa điểm',
        onChanged: (value) {
          setState(() {
            ten_location = value;
          });
        },
      ),
    ];
  }

  @override
  (DateTime, DateTime, String?, String?) getFilterResult() {
    return (fromDate, toDate, ma_lhhd, ten_location);
  }
}
