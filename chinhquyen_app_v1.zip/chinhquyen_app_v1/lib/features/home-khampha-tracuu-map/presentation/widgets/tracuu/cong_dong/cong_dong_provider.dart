import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../core/network/api_provider.dart';

//! State lưu giá trị filter
final congdongFilterStateProvider =
    StateProvider<(DateTime, DateTime, String?)?>((ref) => null);
//! State lấy danh sách
final congdongListProvider =
    StateNotifierProvider<CongDongListNotifier, List<Map<String, dynamic>>>(
      (ref) => CongDongListNotifier(ref),
    );

//! Api lazy loading
class CongDongListNotifier extends StateNotifier<List<Map<String, dynamic>>> {
  CongDongListNotifier(this.ref) : super([]) {
    fetchCongDongList();
  }

  final Ref ref;
  int _pageIndex = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  Future<void> fetchCongDongList() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;

    final filter = ref.read(congdongFilterStateProvider);
    final (ngay_ct1, ngay_ct2, ten_location) = filter ?? (null, null, null);

    final result = await ref
        .read(apiServiceProvider)
        .fetchDSCongDong(
          pageIndex: _pageIndex,
          ngay_ct1: ngay_ct1,
          ngay_ct2: ngay_ct2,
          ten_location: ten_location,
        );

    if (result.isEmpty) {
      _hasMore = false;
    } else {
      state = [...state, ...result];
      _pageIndex++;
    }

    _isLoading = false;
  }
}
