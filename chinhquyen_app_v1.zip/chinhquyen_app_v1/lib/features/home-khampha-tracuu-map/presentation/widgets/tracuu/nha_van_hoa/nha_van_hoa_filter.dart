import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../core/shared/base_filter.dart';
import '../../../../../../core/widgets/form/input_field_widget.dart';

class NhaVanHoaFilter extends BaseFilter<(DateTime, DateTime, String?)> {
  final (String?,)? initialValues;

  const NhaVanHoaFilter({
    super.key,
    required super.initialFromDate,
    required super.initialToDate,
    this.initialValues,
    // ẩn ngày tháng
    super.showDateFields = false,
  });

  @override
  ConsumerState<NhaVanHoaFilter> createState() =>
      _NhaVanHoaFilterConsumerState();
}

class _NhaVanHoaFilterConsumerState
    extends BaseFilterState<(DateTime, DateTime, String?), NhaVanHoaFilter> {
  String? ten_location;
  late TextEditingController _ten_locationController;

  @override
  void initState() {
    super.initState();
    _ten_locationController = TextEditingController();

    final initial = widget.initialValues;
    if (initial != null) {
      ten_location = initial.$1;

      _ten_locationController.text = ten_location ?? '';
    }
  }

  @override
  void dispose() {
    _ten_locationController.dispose();
    super.dispose();
  }

  @override
  List<Widget> buildFilterFields() {
    return [
      InputFieldWidget(
        label: 'Tên địa điểm',
        controller: _ten_locationController,
        hintText: 'Nhập tên địa điểm',
        onChanged: (value) {
          setState(() {
            ten_location = value;
          });
        },
      ),
    ];
  }

  @override
  (DateTime, DateTime, String?) getFilterResult() {
    return (fromDate, toDate, ten_location);
  }
}
