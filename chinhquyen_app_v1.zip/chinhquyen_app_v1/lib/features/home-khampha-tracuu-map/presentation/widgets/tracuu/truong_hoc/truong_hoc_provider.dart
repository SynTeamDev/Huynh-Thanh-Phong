import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../core/network/api_provider.dart';

//! State lưu giá trị filter
final truonghocFilterStateProvider =
    StateProvider<(DateTime, DateTime, String?)?>((ref) => null);
//! State lấy danh sách
final truonghocListProvider =
    StateNotifierProvider<TruongHocListNotifier, List<Map<String, dynamic>>>(
      (ref) => TruongHocListNotifier(ref),
    );

//! Api lazy loading
class TruongHocListNotifier extends StateNotifier<List<Map<String, dynamic>>> {
  TruongHocListNotifier(this.ref) : super([]) {
    fetchTruongHocList();
  }

  final Ref ref;
  int _pageIndex = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  Future<void> fetchTruongHocList() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;

    final filter = ref.read(truonghocFilterStateProvider);
    final (ngay_ct1, ngay_ct2, ten_location) = filter ?? (null, null, null);

    final result = await ref
        .read(apiServiceProvider)
        .fetchDSTruongHoc(
          pageIndex: _pageIndex,
          ngay_ct1: ngay_ct1,
          ngay_ct2: ngay_ct2,
          ten_location: ten_location,
        );

    if (result.isEmpty) {
      _hasMore = false;
    } else {
      state = [...state, ...result];
      _pageIndex++;
    }

    _isLoading = false;
  }
}
