import 'package:chinhquyen_app/core/widgets/custom_appbar_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:ionicons/ionicons.dart';

import '../../../../../../core/utils/delay_btn_helper.dart';
import '../../../../../../core/utils/handle_tel_call.dart';
import '../../../../../../core/widgets/form/phone_picker_row.dart';
import 'nha_van_hoa_filter.dart';
import 'nha_van_hoa_provider.dart';

class NhaVanHoaPage extends ConsumerStatefulWidget {
  const NhaVanHoaPage({super.key, this.title = ''});
  final String title;

  @override
  ConsumerState<NhaVanHoaPage> createState() => _NhaVanHoaPageState();
}

class _NhaVanHoaPageState extends ConsumerState<NhaVanHoaPage> {
  final ScrollController _scrollController = ScrollController();

  DateTime? _ngayCt1, _ngayCt2;
  String? _ten_location;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);

    _initDatesToDefault();
    final filter = ref.read(nhavanhoaFilterStateProvider);
    if (filter != null) _applyFilterFromTuple(filter);
  }

  void _initDatesToDefault() {
    final now = DateTime.now();
    _ngayCt1 = DateTime(now.year, now.month - 6, 1);
    _ngayCt2 = DateTime(now.year, now.month + 2, 0);
  }

  void _applyFilterFromTuple((DateTime, DateTime, String?) filter) {
    final (ngayCt1, ngayCt2, ten_location) = filter;
    _ngayCt1 = ngayCt1;
    _ngayCt2 = ngayCt2;

    _ten_location = ten_location;
  }

  Future<void> _onRefreshPressed() async {
    if (!GlobalButtonDisableHelper.isDisabled) {
      GlobalButtonDisableHelper.disableTemporarily(seconds: 1);
      setState(() {
        _initDatesToDefault();
        _ten_location = null;
      });
      ref.read(nhavanhoaFilterStateProvider.notifier).state = null;

      // ✅ Quan trọng: trigger lại gọi API
      ref.invalidate(nhavanhoaListProvider);
    }
  }

  Future<void> _onFilterPressed() async {
    if (!GlobalButtonDisableHelper.isDisabled) {
      GlobalButtonDisableHelper.disableTemporarily(seconds: 1);
      final result = await NhaVanHoaFilter(
        initialFromDate: _ngayCt1 ?? DateTime.now(),
        initialToDate: _ngayCt2 ?? DateTime.now(),
        initialValues: (_ten_location,),
      ).show(context);

      if (result != null) {
        ref.read(nhavanhoaFilterStateProvider.notifier).state = result;
        setState(() => _applyFilterFromTuple(result));
        // ✅ Quan trọng: trigger lại gọi API
        ref.invalidate(nhavanhoaListProvider);
      }
    }
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 100) {
      ref.read(nhavanhoaListProvider.notifier).fetchNhaVanHoaList();
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final nhavanhoaList = ref.watch(nhavanhoaListProvider);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBarWidget(
        title: widget.title,
        actions: [
          IconButton(
            icon: const Icon(Ionicons.refresh, color: Colors.blue),
            onPressed: () {
              _onRefreshPressed();
            },
          ),
          IconButton(
            icon: const Icon(Ionicons.search_outline, color: Colors.blue),
            onPressed: () {
              _onFilterPressed();
            },
          ),
        ],
      ),
      body: Scrollbar(
        controller: _scrollController,
        thumbVisibility: true,
        thickness: 6,
        radius: const Radius.circular(10),
        child: ListView.builder(
          controller: _scrollController,
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
          itemCount: nhavanhoaList.length,
          itemBuilder: (context, index) {
            final item = nhavanhoaList[index];
            return Container(
              margin: const EdgeInsets.only(bottom: 2),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.8),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade200),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Dòng 1: Loại
                  PhonePickerRow(
                    label: '',
                    labelWidget: RichText(
                      textAlign: TextAlign.left,
                      text: TextSpan(
                        style: const TextStyle(fontSize: 13),
                        children: [
                          const TextSpan(
                            text: 'Liên hệ:',
                            style: TextStyle(
                              color: Colors.grey, // 👈 Chữ xám
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    phones: [item['dien_thoai'] ?? ''],
                    onCall: (phone) => handleTelCall(phone),
                  ),
                  const SizedBox(height: 2),

                  // Dòng 2: Địa điểm (pill bên phải, tự co – không tràn)
                  LayoutBuilder(
                    builder: (context, constraints) {
                      final maxW =
                          constraints.maxWidth *
                          0.80; // pill tối đa 97% chiều ngang
                      return Row(
                        children: [
                          const Text(
                            'Địa điểm: ',
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.grey,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const Spacer(),
                          ConstrainedBox(
                            constraints: BoxConstraints(maxWidth: maxW),
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.blue.shade400,
                                borderRadius: BorderRadius.circular(8),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.green.withOpacity(0.12),
                                    blurRadius: 6,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(
                                    Icons.place_rounded,
                                    size: 14,
                                    color: Colors.white,
                                  ),
                                  const SizedBox(width: 6),
                                  Flexible(
                                    child: Text(
                                      item['ten_location'] ?? '',
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 12.5,
                                        fontWeight: FontWeight.w600,
                                        height: 1.1,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                  const SizedBox(height: 2),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Địa chỉ: ',
                        style: TextStyle(
                          fontSize: 13,
                          color: Colors.grey,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          item['dia_chi'] ?? '',
                          style: const TextStyle(
                            fontSize: 13,
                            color: Colors.black87,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Website: ',
                        style: TextStyle(
                          fontSize: 13,
                          color: Colors.grey,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          item['linkweb'] ?? '',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.black87,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
