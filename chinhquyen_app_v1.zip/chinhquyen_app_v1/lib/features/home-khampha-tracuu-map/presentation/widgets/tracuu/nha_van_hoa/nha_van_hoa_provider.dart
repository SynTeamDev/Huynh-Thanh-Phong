import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../core/network/api_provider.dart';

//! State lưu giá trị filter
final nhavanhoaFilterStateProvider =
    StateProvider<(DateTime, DateTime, String?)?>((ref) => null);
//! State lấy danh sách
final nhavanhoaListProvider =
    StateNotifierProvider<NhaVanHoaListNotifier, List<Map<String, dynamic>>>(
      (ref) => NhaVanHoaListNotifier(ref),
    );

//! Api DSNhaVanHoa lazy loading
class NhaVanHoaListNotifier extends StateNotifier<List<Map<String, dynamic>>> {
  NhaVanHoaListNotifier(this.ref) : super([]) {
    fetchNhaVanHoaList();
  }

  final Ref ref;
  int _pageIndex = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  Future<void> fetchNhaVanHoaList() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;

    final filter = ref.read(nhavanhoaFilterStateProvider);
    final (ngay_ct1, ngay_ct2, ten_location) = filter ?? (null, null, null);

    final result = await ref
        .read(apiServiceProvider)
        .fetchDSNhaVanHoa(
          pageIndex: _pageIndex,
          ngay_ct1: ngay_ct1,
          ngay_ct2: ngay_ct2,
          ten_location: ten_location,
        );

    if (result.isEmpty) {
      _hasMore = false;
    } else {
      state = [...state, ...result];
      _pageIndex++;
    }

    _isLoading = false;
  }
}
