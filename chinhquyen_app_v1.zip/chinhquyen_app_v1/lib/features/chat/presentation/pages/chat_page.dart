import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/widgets/custom_appbar_widget.dart';
import '../providers/chat_provider.dart';
import '../widgets/doan_chat_list.dart';
import '../widgets/nhom_chat_list.dart';
import '../widgets/search_box.dart';

class ChatPage extends ConsumerStatefulWidget {
  const ChatPage({super.key, this.title = ''});
  final String title;
  @override
  ConsumerState<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends ConsumerState<ChatPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBarWidget(
        title: widget.title,
        actions: [
          IconButton(
            icon: const Icon(Icons.open_in_new),
            onPressed: () {
              context.push('/create-group');
            },
          ),
        ],
      ),
      body: Column(
        children: [
          const SizedBox(height: 12),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: SearchBox(),
          ),
          const SizedBox(height: 12),

          // ==== TAB: Hội thoại - Nhóm ====
          TabBar(
            controller: _tabController,
            labelColor: Colors.blue,
            unselectedLabelColor: Colors.black54,
            indicatorColor: Colors.blue,
            tabs: const [
              Tab(text: 'Đoạn chat'),
              Tab(text: 'Nhóm'),
            ],
          ),

          // ==== TAB CONTENT ====
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [const DoanChatList(), const NhomChatList()],
            ),
          ),
        ],
      ),
    );
  }
}
