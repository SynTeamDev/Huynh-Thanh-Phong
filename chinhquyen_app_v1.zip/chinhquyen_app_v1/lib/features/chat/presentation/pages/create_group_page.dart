import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/network/api_provider.dart';
import '../../../../core/widgets/custom_snackbar_widget.dart';
import '../../../../core/widgets/row_appbar_widget.dart';
import '../../../auth/presentation/providers/profile_provider.dart';
import '../providers/chat_provider.dart';
import '../providers/filtered_providers.dart';
import '../widgets/search_box.dart';

class CreateGroupPage extends ConsumerStatefulWidget {
  const CreateGroupPage({super.key});

  @override
  ConsumerState<CreateGroupPage> createState() => _CreateGroupPageState();
}

class _CreateGroupPageState extends ConsumerState<CreateGroupPage> {
  final TextEditingController _groupNameController = TextEditingController();
  final List<int> _selectedUserIds = [];
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 100) {
      ref.read(doanchatListProvider.notifier).fetchDoanChatList();
    }
  }

  @override
  void dispose() {
    _groupNameController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final users = ref.watch(filteredDoanChatProvider);

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            //! Appbar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
              child: Row(
                children: [
                  const Expanded(child: RowAppbarWidget(text: 'Tạo nhóm mới')),
                  TextButton(
                    onPressed: _selectedUserIds.length < 2
                        ? null
                        : () async {
                            final groupName = _groupNameController.text.trim();
                            if (groupName.isEmpty) {
                              showSnack(context, "Vui lòng nhập tên nhóm");
                              return;
                            }

                            final createdBy = getUserId(ref);

                            await ref
                                .read(apiServiceProvider)
                                .createGroupChat(
                                  groupName: groupName,
                                  createdBy: createdBy!,
                                  userIds: _selectedUserIds,
                                );

                            if (context.mounted) {
                              //! ✅ Quan trọng: trigger lại gọi API (cần thiết)
                              Future.microtask(() {
                                ref.invalidate(doanchatListProvider);
                                ref.invalidate(nhomchatListProvider);
                              });
                              Navigator.pop(
                                context,
                              ); // hoặc chuyển hướng sang chat
                            }
                          },
                    style: TextButton.styleFrom(
                      foregroundColor: _selectedUserIds.length < 2
                          ? Colors.grey
                          : Colors.blueAccent,
                    ),
                    child: const Text(
                      'Tạo',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),

            //! Tên nhóm
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
              child: TextField(
                controller: _groupNameController,
                decoration: InputDecoration(
                  hintText: 'Đặt tên nhóm',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                ),
              ),
            ),

            //! Tìm kiếm
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              child: SearchBox(),
            ),

            const Divider(height: 0),

            //! Gợi ý
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              child: Row(
                children: [
                  Text(
                    'Gợi ý',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ],
              ),
            ),

            //! Danh sách user
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                itemCount: users.length,
                itemBuilder: (_, index) {
                  final user = users[index];
                  final userId = user['user_id'];
                  final nickname = user['nickname'] ?? '';
                  final username = user['username'] ?? '';
                  final selected = _selectedUserIds.contains(userId);

                  return ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                    leading: const CircleAvatar(child: Icon(Icons.person)),
                    title: Text(nickname),
                    subtitle: Text(
                      "($username)",
                      style: const TextStyle(fontSize: 12),
                    ),
                    trailing: Checkbox(
                      value: selected,
                      activeColor: Colors.blue, // ✅ màu xanh
                      onChanged: (_) {
                        setState(() {
                          selected
                              ? _selectedUserIds.remove(userId)
                              : _selectedUserIds.add(userId);
                        });
                      },
                    ),
                    onTap: () {
                      setState(() {
                        selected
                            ? _selectedUserIds.remove(userId)
                            : _selectedUserIds.add(userId);
                      });
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
