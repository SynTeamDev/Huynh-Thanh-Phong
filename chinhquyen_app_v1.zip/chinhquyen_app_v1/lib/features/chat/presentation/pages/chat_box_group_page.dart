import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:ionicons/ionicons.dart';

import '../../../../core/network/chat_service.dart';
import '../../../../core/widgets/row_appbar_widget.dart';
import '../../../auth/presentation/providers/profile_provider.dart';
import '../providers/chat_helper.dart';
import '../providers/chat_provider.dart';

class ChatBoxGroupPage extends ConsumerStatefulWidget {
  final int groupId;
  final String title;

  const ChatBoxGroupPage({
    super.key,
    required this.groupId,
    required this.title,
  });

  @override
  ConsumerState<ChatBoxGroupPage> createState() => _ChatBoxGroupPageState();
}

class _ChatBoxGroupPageState extends ConsumerState<ChatBoxGroupPage> {
  final _controller = TextEditingController();
  final _scrollCtrl = ScrollController();

  late final ChatService _chatService;

  /// Lưu ý:
  /// - _userId: có thể là số (id nội bộ)
  /// - _userName: mã đăng nhập/người dùng, ví dụ "SYN0005" -> MATCH cột Sender của proc
  late final String _userId;
  late final String _userName;

  bool _joined = false;
  bool _mounted = true;

  @override
  void initState() {
    super.initState();
    _chatService = ref.read(chatServiceProvider);
    _userId = getUserId(ref).toString();
    _userName = getUsername(ref).toString(); // 👈 so khớp với Sender trong proc

    _scrollCtrl.addListener(_onScroll);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_joined) return;

    _chatService.connect(userId: _userId).then((_) async {
      // JoinGroup(userId, groupId)
      await _chatService.connection.invoke(
        'JoinGroup',
        args: [_userId, widget.groupId],
      );

      // Lắng nghe tin nhắn nhóm: (senderId, groupId, message, senderName)
      _chatService.addGroupListener(_groupMessageHandler);

      // Load lịch sử lần đầu
      ref.read(chatGroupContentListProvider(widget.groupId).notifier).refresh();

      if (_mounted) setState(() => _joined = true);
      _jumpToBottom();
    });
  }

  void _groupMessageHandler(
    String senderId,
    int groupId,
    String message,
    String senderName,
  ) {
    if (!_mounted || groupId != widget.groupId) return;

    // ⛔️ BỎ QUA tin do chính mình vừa gửi (server echo)
    if (senderId == _userName) return;

    ref
        .read(chatGroupContentListProvider(widget.groupId).notifier)
        .addIncoming({
          'Sender': senderId,
          'Message': message,
          'GroupId': groupId,
          'Timestamp': DateTime.now().toIso8601String(),
        });

    _jumpToBottom();
  }

  void _onScroll() {
    // reverse: true => kéo lên trên (xem tin cũ) thì pixels tăng dần đến maxScrollExtent
    final pos = _scrollCtrl.position;
    if (pos.pixels >= pos.maxScrollExtent - 120) {
      ref
          .read(chatGroupContentListProvider(widget.groupId).notifier)
          .fetchMore();
    }
  }

  void _sendMessage() {
    final text = _controller.text.trim();
    if (text.isEmpty || !_joined) return;

    _chatService.sendGroupMessage(_userName, widget.groupId, text);

    ref
        .read(chatGroupContentListProvider(widget.groupId).notifier)
        .addIncoming({
          'Sender': _userName,
          'Message': text,
          'GroupId': widget.groupId,
          'Timestamp': DateTime.now().toIso8601String(),
        });

    _controller.clear();
    _jumpToBottom(instant: true); // ✅ thấy ngay tin vừa gửi

    ref.invalidate(lastMessageGroupPreviewProvider(widget.groupId.toString()));
  }

  void _jumpToBottom({bool instant = false}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_mounted || !_scrollCtrl.hasClients) return;
      if (instant) {
        _scrollCtrl.jumpTo(0); // reverse:true => đáy = offset 0
      } else {
        _scrollCtrl.animateTo(
          0,
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _mounted = false;
    _controller.dispose();
    _scrollCtrl.dispose();

    _chatService.connection.invoke(
      'LeaveGroup',
      args: [_userId, widget.groupId],
    );
    _chatService.removeGroupListener(_groupMessageHandler);

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final messages = ref.watch(chatGroupContentListProvider(widget.groupId));

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              RowAppbarWidget(
                text: widget.title,
                // actions: [
                //   IconButton(
                //     icon: const Icon(Ionicons.call),
                //     onPressed: () {},
                //     tooltip: 'Gọi audio',
                //   ),
                //   IconButton(
                //     icon: const Icon(Ionicons.videocam),
                //     onPressed: () {},
                //     tooltip: 'Gọi video',
                //   ),
                // ],
              ),
              const SizedBox(height: 12),

              Expanded(
                child: ListView.builder(
                  controller: _scrollCtrl,
                  reverse: true, // tin mới ở DƯỚI
                  itemCount: messages.length,
                  itemBuilder: (_, i) {
                    final m = messages[i];
                    final text = (m['Message'] ?? '').toString();

                    // --- Sender hiện tại & của tin "mới hơn" (DESC) ---
                    String norm(String? s) => (s ?? '').trim();
                    final senderRaw = norm(
                      (m['Sender'] ?? m['SenderId']).toString(),
                    );
                    final newer = (i > 0) ? messages[i - 1] : null;
                    final newerSenderRaw = norm(
                      ((newer?['Sender'] ?? newer?['SenderId']).toString()),
                    );

                    bool eqIgnoreCase(String a, String b) =>
                        a.toLowerCase() == b.toLowerCase();

                    // ✅ isMe: khớp theo userId HOẶC username (không phân biệt hoa/thường)
                    final isMe =
                        senderRaw == _userId ||
                        eqIgnoreCase(senderRaw, _userName);

                    final curTs = parseTs(m['Timestamp']);
                    final newerTs = (i > 0)
                        ? parseTs(newer?['Timestamp'])
                        : null;

                    // ---------- Divider giữa khi cách >=10' hoặc khác ngày ----------
                    bool showDivider = false;
                    String dividerText = '';

                    if (curTs != null && newerTs != null) {
                      final bool crossDay = !isSameDay(newerTs, curTs);
                      final bool crossBucket =
                          tenMinBucket(newerTs) != tenMinBucket(curTs);

                      if (crossDay || crossBucket) {
                        showDivider = true;
                        // Label theo mốc 10' (đẹp & nhất quán)
                        dividerText = timeLabel(floorToTenMin(curTs));
                      }
                    }

                    // ---------- "bubble cuối của dãy" để hiện HH:mm ----------
                    bool isStartOfBlock = false;
                    if (curTs != null) {
                      if (i == 0) {
                        isStartOfBlock = true;
                      } else if (newerTs != null) {
                        final gapSec = (newerTs.difference(
                          curTs,
                        )).inSeconds.abs();
                        final newSegment =
                            !eqIgnoreCase(newerSenderRaw, senderRaw) ||
                            !isSameDay(newerTs, curTs) ||
                            gapSec >= 600;
                        if (newSegment) isStartOfBlock = true;
                      }
                    }

                    // ---------- Liền kề (<10', cùng Sender, cùng ngày) ----------
                    final contiguousPrev = (curTs != null && newerTs != null)
                        ? eqIgnoreCase(newerSenderRaw, senderRaw) &&
                              isSameDay(newerTs, curTs) &&
                              (newerTs.difference(curTs)).inSeconds.abs() < 600
                        : false;

                    final topMargin = contiguousPrev ? 2.0 : 8.0;
                    final radius = BorderRadius.only(
                      topLeft: Radius.circular(
                        isMe ? 12 : (contiguousPrev ? 6 : 12),
                      ),
                      topRight: Radius.circular(
                        isMe ? (contiguousPrev ? 6 : 12) : 12,
                      ),
                      bottomLeft: Radius.circular(12),
                      bottomRight: Radius.circular(12),
                    );

                    final maxBubbleWidth =
                        MediaQuery.of(context).size.width * 0.75;
                    // --- constants cho bố cục đẹp & đều ---
                    const double kAvatarRadius = 16;
                    const double kAvatarGap =
                        8; // khoảng cách avatar <-> bubble
                    const double kSidePadding = 2; // padding hai bên màn hình
                    final double kAvatarSlotW = kAvatarRadius * 2 + kAvatarGap;

                    // phần tử CŨ HƠN (theo thứ tự DESC)
                    final older = (i < messages.length - 1)
                        ? messages[i + 1]
                        : null;
                    final olderTs = (older != null)
                        ? parseTs(older['Timestamp'])
                        : null;
                    final olderSender = older?['Sender']?.toString();

                    // Bubble ĐẦU của dãy (ở TRÊN cụm)
                    bool isTopOfBlock = false;
                    if (curTs != null) {
                      if (i == messages.length - 1) {
                        isTopOfBlock = true;
                      } else if (olderTs != null) {
                        final sameDayTop = isSameDay(olderTs, curTs);
                        final sameBucketTop =
                            tenMinBucket(olderTs) == tenMinBucket(curTs);
                        final sameSenderTop =
                            (olderSender == m['Sender']?.toString());

                        final newSegmentTop =
                            !sameSenderTop || !sameDayTop || !sameBucketTop;
                        if (newSegmentTop) isTopOfBlock = true;
                      }
                    }

                    // avatar chỉ hiện ở tin đầu dãy
                    final bool showAvatar =
                        isTopOfBlock; // ✅ avatar ở bong bóng đầu dãy (trên)

                    // slot avatar: có/không vẫn giữ cùng bề rộng để bố cục không xô lệch
                    Widget _avatarSlot({
                      required bool mine,
                      required bool visible,
                    }) {
                      return SizedBox(
                        width: kAvatarSlotW,
                        child: visible
                            ? Align(
                                alignment:
                                    Alignment.center, // căn giữa theo chiều dọc
                                child: CircleAvatar(
                                  radius: kAvatarRadius,
                                  backgroundColor: mine
                                      ? const Color(0xFFD2E3FC)
                                      : const Color(0xFFE0E0E0),
                                  child: Icon(
                                    Icons.person,
                                    size:
                                        kAvatarRadius, // icon vừa khít vòng tròn
                                    color: Colors.black54,
                                  ),
                                ),
                              )
                            : const SizedBox.shrink(),
                      );
                    }

                    // Trước khi return Column(...) thêm 2 biến này (đặt ngay sau khi có isMe, senderRaw, isTopOfBlock...):
                    final bool isGroupChat = true; // hoặc truyền từ widget
                    final String displayName =
                        senderRaw; // fallback nếu chưa có map
                    final bool showSenderHeader =
                        isGroupChat &&
                        !isMe &&
                        isTopOfBlock; // chỉ hiện ở đầu cụm người khác

                    // === UI ===
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        if (showDivider) timeDivider(dividerText),

                        // bubble (trái cho người khác, phải cho mình)
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 0),
                          child: Row(
                            mainAxisAlignment: isMe
                                ? MainAxisAlignment.end
                                : MainAxisAlignment.start,
                            children: [
                              if (!isMe)
                                _avatarSlot(mine: false, visible: showAvatar),

                              ConstrainedBox(
                                constraints: BoxConstraints(
                                  maxWidth: maxBubbleWidth,
                                ),

                                child: Container(
                                  margin: EdgeInsets.only(
                                    top: topMargin,
                                    bottom: 2,
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 12,
                                    vertical: 8,
                                  ),
                                  decoration: BoxDecoration(
                                    color: isMe
                                        ? const Color(0xFFE8F0FE)
                                        : const Color(0xFFF2F2F2),
                                    borderRadius: radius,
                                  ),
                                  // ⬇️ thay Text(...) bằng Column có header tên + nội dung
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      if (showSenderHeader)
                                        Padding(
                                          padding: const EdgeInsets.only(
                                            bottom: 2,
                                          ),
                                          child: Text(
                                            displayName, // ví dụ “Khai Nguyễn”
                                            style: const TextStyle(
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.green,
                                            ),
                                          ),
                                        ),
                                      Text(
                                        text,
                                        style: const TextStyle(
                                          fontSize: 15,
                                          height: 1.25, // dễ đọc hơn
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        // dòng giờ (căn theo bên gửi/nhận) – bỏ avatar slot vì bạn không dùng avatar ở đây
                        if (isStartOfBlock && curTs != null)
                          Padding(
                            padding: EdgeInsets.only(
                              left: isMe
                                  ? kSidePadding
                                  : (kSidePadding + kAvatarSlotW),
                              right: isMe ? kSidePadding : kSidePadding,
                              bottom: 6,
                              top: 2,
                            ),
                            child: ConstrainedBox(
                              constraints: BoxConstraints(
                                maxWidth: maxBubbleWidth,
                              ),
                              child: Text(
                                hhmm(curTs),
                                textAlign: isMe
                                    ? TextAlign.right
                                    : TextAlign.left,
                                style: TextStyle(
                                  fontSize: 11,
                                  color: Colors.black.withOpacity(0.55),
                                ),
                              ),
                            ),
                          ),
                      ],
                    );
                  },
                ),
              ),
              // ====== DROP-IN: thay cho block Padding(...) hiện tại ======
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      // emoji / đính kèm tuỳ bạn dùng
                      // IconButton(
                      //   icon: const Icon(Icons.image_rounded),
                      //   onPressed: () {}, // TODO
                      // ),
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF6F7FB),
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: const Color(0xFFE5E7EB)),
                          ),
                          child: TextField(
                            controller: _controller,
                            minLines: 1,
                            maxLines: 5, // auto-grow
                            keyboardType: TextInputType.multiline,
                            textInputAction: TextInputAction.newline,
                            decoration: const InputDecoration(
                              hintText: 'Nhập tin nhắn...',
                              border: InputBorder.none,
                              isDense: true,
                            ),
                            onSubmitted: (_) => _sendMessage(),
                          ),
                        ),
                      ),

                      const SizedBox(width: 8),

                      // Nút Send: đổi icon/màu theo trạng thái nhập
                      ValueListenableBuilder<TextEditingValue>(
                        valueListenable: _controller,
                        builder: (context, value, _) {
                          final canSend = value.text.trim().isNotEmpty;
                          return GestureDetector(
                            onTap: canSend ? _sendMessage : null,
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 180),
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(22),
                                gradient: canSend
                                    ? const LinearGradient(
                                        colors: [
                                          Color(0xFF60A5FA),
                                          Color(0xFF2563EB),
                                        ],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                      )
                                    : const LinearGradient(
                                        colors: [
                                          Color(0xFFE5E7EB),
                                          Color(0xFFD1D5DB),
                                        ],
                                      ),
                                boxShadow: canSend
                                    ? [
                                        BoxShadow(
                                          color: const Color(
                                            0xFF2563EB,
                                          ).withOpacity(0.25),
                                          blurRadius: 12,
                                          offset: const Offset(0, 4),
                                        ),
                                      ]
                                    : [],
                              ),
                              child: Icon(
                                // canSend ? Icons.send_rounded : Icons.mic_none_rounded,
                                canSend
                                    ? Icons.send_rounded
                                    : Icons.send_rounded,
                                color: canSend
                                    ? Colors.white
                                    : const Color(0xFF6B7280),
                              ),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
