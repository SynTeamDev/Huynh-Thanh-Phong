import 'dart:async';

import 'package:chinhquyen_app/core/network/chat_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:ionicons/ionicons.dart';
import '../../../../core/widgets/custom_snackbar_widget.dart';
import '../../../../core/widgets/row_appbar_widget.dart';
import '../../../auth/presentation/providers/profile_provider.dart';
import '../providers/chat_helper.dart';
import '../providers/chat_provider.dart';
import '../widgets/typing_widget.dart';

class ChatBoxPage extends ConsumerStatefulWidget {
  const ChatBoxPage({
    super.key,
    required this.receiverId,
    required this.title,
    required this.receiverUserName,
  });

  final int receiverId;
  final String title;
  final String receiverUserName;

  @override
  ConsumerState<ChatBoxPage> createState() => _ChatBoxPageState();
}

class _ChatBoxPageState extends ConsumerState<ChatBoxPage> {
  final _controller = TextEditingController();
  final _scrollCtrl = ScrollController();

  late final ChatService _chatService;
  late final String _userId;
  late final String _userName;

  late final bool _isSelfChat;

  //TODO: typing indicator
  Timer? _typingDebounce;
  final _focusNode = FocusNode();
  bool _typingSent = false;

  void _sendTypingTrue() {
    if (_typingSent) return;
    _typingSent = true;
    _chatService.sendTyping(_userId, widget.receiverId.toString(), true);
  }

  void _sendTypingFalse() {
    if (!_typingSent) return;
    _typingSent = false;
    _chatService.sendTyping(_userId, widget.receiverId.toString(), false);
  }

  void _onTextChanged(String _) {
    _sendTypingTrue();
    _typingDebounce?.cancel();
    _typingDebounce = Timer(
      const Duration(milliseconds: 1200),
      _sendTypingFalse,
    );
  } //!TODO: typing indicator

  @override
  void initState() {
    super.initState();

    final userId = getUserId(ref);
    final username = getUsername(ref);
    if (userId == null || username == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.of(context).pop();
        showSnack(context, 'Lỗi: Chưa đăng nhập hoặc chưa có thông tin user');
      });
      return;
    }

    _userId = userId.toString();
    _userName = username;
    _isSelfChat = (widget.receiverId.toString() == _userId);

    _chatService = ref.read(chatServiceProvider);
    _chatService.connect(userId: _userId);

    // Lắng nghe tin đến
    _chatService.addListener((sender, message) {
      final convPartnerId = widget.receiverId.toString();
      final isFromPartner = (sender == convPartnerId);
      final isFromMe = (sender == _userId);

      // Chỉ add nếu:
      // - Tin từ "đối tác" của cuộc chat hiện tại
      // - Và KHÔNG phải self-chat + do chính mình gửi (tránh double)
      if (isFromPartner && !(_isSelfChat && isFromMe)) {
        ref
            .read(chatContent1v1ListProvider(widget.receiverId).notifier)
            .addIncoming({
              'Sender': sender,
              'Receiver': _userId,
              'Message': message,
              'Timestamp': DateTime.now(),
            });
        _jumpToBottom();
      }
    });

    _scrollCtrl.addListener(_onScroll);

    // Lần đầu mở màn, refresh lịch sử cho chắc
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref
          .read(chatContent1v1ListProvider(widget.receiverId).notifier)
          .refresh();
    });
    //TODO: typing indicator
    _chatService.addTypingListener((sender, isTyping) {
      final partner = widget.receiverId.toString();
      if (sender == partner) {
        ref.read(partnerTypingProvider(widget.receiverId).notifier).state =
            isTyping;

        if (isTyping) {
          Future.delayed(const Duration(seconds: 3), () {
            final cur = ref.read(partnerTypingProvider(widget.receiverId));
            if (cur) {
              ref
                      .read(partnerTypingProvider(widget.receiverId).notifier)
                      .state =
                  false;
            }
          });
        }
      }
    });

    _focusNode.addListener(() {
      if (!_focusNode.hasFocus) _sendTypingFalse();
    });
    //!TODO: typing indicator
  }

  void _onScroll() {
    // reverse: true => kéo lên trên (xem tin cũ) thì pixels tăng dần đến maxScrollExtent
    final pos = _scrollCtrl.position;
    if (pos.pixels >= pos.maxScrollExtent - 120) {
      ref
          .read(chatContent1v1ListProvider(widget.receiverId).notifier)
          .fetchMore();
    }
  }

  void _sendMessage() {
    final text = _controller.text.trim();
    if (text.isEmpty) return;

    final receiverStr = widget.receiverId.toString();
    _chatService.sendMessage(_userId, receiverStr, text);

    // với list DESC + reverse:true => chèn vào đầu list để thấy ngay ở dưới
    ref
        .read(chatContent1v1ListProvider(widget.receiverId).notifier)
        .addIncoming({
          'Sender': _userId,
          'Receiver': receiverStr,
          'Message': text,
          'Timestamp': DateTime.now(),
        });

    _controller.clear();
    _jumpToBottom(); // về cuối (visual bottom) = offset 0 khi reverse:true

    ref.invalidate(lastMessagePreviewProvider(widget.receiverId.toString()));
  }

  void _jumpToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          0, // reverse:true => 0 là đáy (tin mới nhất)
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollCtrl.dispose();
    _chatService.disconnect();
    //TODO: typing indicator
    _typingDebounce?.cancel();
    _focusNode.dispose();
    //!TODO: typing indicator
    super.dispose();
  }



  @override
  Widget build(BuildContext context) {
    final messages = ref.watch(chatContent1v1ListProvider(widget.receiverId));
    // messages giữ nguyên thứ tự DESC (mới -> cũ)
    final isPartnerTyping = ref.watch(partnerTypingProvider(widget.receiverId));
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            RowAppbarWidget(
              text: widget.title,
              //TODO:
              actions: [
                IconButton(
                  icon: const Icon(Ionicons.call),
                  onPressed: () {},
                  tooltip: 'Gọi audio',
                ),
                IconButton(
                  icon: const Icon(Ionicons.videocam),
             onPressed: () {},
                  tooltip: 'Gọi video',
                ),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                controller: _scrollCtrl,
                reverse: true, // tin mới ở DƯỚI
                itemCount: messages.length,
                itemBuilder: (_, i) {
                  final m = messages[i];
                  final isMe = (m['Sender']?.toString() == _userId);
                  final text = m['Message']?.toString() ?? '';

                  final curTs = parseTs(
                    m['Timestamp'],
                  ); // time của bubble hiện tại
                  final newer = (i > 0)
                      ? messages[i - 1]
                      : null; // phần tử MỚI HƠN (DESC)
                  final newerTs = (i > 0) ? parseTs(newer?['Timestamp']) : null;
                  final newerSender = newer?['Sender']?.toString();

                  // ---------- Divider đúng mỗi 10' hoặc khác ngày ----------
                  bool showDivider = false;
                  String dividerText = '';

                  if (curTs != null && newerTs != null) {
                    final bool crossDay = !isSameDay(newerTs, curTs);
                    final bool crossBucket =
                        tenMinBucket(newerTs) != tenMinBucket(curTs);

                    if (crossDay || crossBucket) {
                      showDivider = true;
                      // Label theo mốc 10' (đẹp & nhất quán)
                      dividerText = timeLabel(floorToTenMin(curTs));
                    }
                  }

                  // ---------- "bubble cuối của dãy" để hiện HH:mm ----------
                  bool isStartOfBlock = false;
                  if (curTs != null) {
                    if (i == 0) {
                      isStartOfBlock = true;
                    } else if (newerTs != null) {
                      final sameDay = isSameDay(newerTs, curTs);
                      final sameBucket =
                          tenMinBucket(newerTs) == tenMinBucket(curTs);
                      final sameSender =
                          (newerSender == m['Sender']?.toString());

                      final newSegment = !sameSender || !sameDay || !sameBucket;
                      if (newSegment) isStartOfBlock = true;
                    }
                  }
                  // ---------- Group: liền kề (<10', cùng Sender, cùng ngày) ----------
                  final contiguousPrev = (curTs != null && newerTs != null)
                      ? (newerSender == m['Sender']?.toString()) &&
                            isSameDay(newerTs, curTs) &&
                            (tenMinBucket(newerTs) == tenMinBucket(curTs))
                      : false;

                  final topMargin = contiguousPrev ? 2.0 : 8.0;
                  final radius = BorderRadius.only(
                    topLeft: Radius.circular(
                      isMe ? 12 : (contiguousPrev ? 6 : 12),
                    ),
                    topRight: Radius.circular(
                      isMe ? (contiguousPrev ? 6 : 12) : 12,
                    ),
                    bottomLeft: Radius.circular(12),
                    bottomRight: Radius.circular(12),
                  );

                  // 👇 giới hạn bề ngang tối đa 75%
                  final maxBubbleWidth =
                      MediaQuery.of(context).size.width * 0.75;
                  // --- constants cho bố cục đẹp & đều ---
                  const double kAvatarRadius = 16;
                  const double kAvatarGap = 8; // khoảng cách avatar <-> bubble
                  const double kSidePadding = 2; // padding hai bên màn hình
                  final double kAvatarSlotW = kAvatarRadius * 2 + kAvatarGap;

                  // phần tử CŨ HƠN (theo thứ tự DESC)
                  final older = (i < messages.length - 1)
                      ? messages[i + 1]
                      : null;
                  final olderTs = (older != null)
                      ? parseTs(older['Timestamp'])
                      : null;
                  final olderSender = older?['Sender']?.toString();

                  // Bubble ĐẦU của dãy (ở TRÊN cụm)
                  bool isTopOfBlock = false;
                  if (curTs != null) {
                    if (i == messages.length - 1) {
                      isTopOfBlock = true;
                    } else if (olderTs != null) {
                      final sameDayTop = isSameDay(olderTs, curTs);
                      final sameBucketTop =
                          tenMinBucket(olderTs) == tenMinBucket(curTs);
                      final sameSenderTop =
                          (olderSender == m['Sender']?.toString());

                      final newSegmentTop =
                          !sameSenderTop || !sameDayTop || !sameBucketTop;
                      if (newSegmentTop) isTopOfBlock = true;
                    }
                  }

                  // avatar chỉ hiện ở tin đầu dãy
                  final bool showAvatar =
                      isTopOfBlock; // ✅ avatar ở bong bóng đầu dãy (trên)

                  // slot avatar: có/không vẫn giữ cùng bề rộng để bố cục không xô lệch
                  Widget _avatarSlot({
                    required bool mine,
                    required bool visible,
                  }) {
                    return SizedBox(
                      width: kAvatarSlotW,
                      child: visible
                          ? Align(
                              alignment:
                                  Alignment.center, // căn giữa theo chiều dọc
                              child: CircleAvatar(
                                radius: kAvatarRadius,
                                backgroundColor: mine
                                    ? const Color(0xFFD2E3FC)
                                    : const Color(0xFFE0E0E0),
                                child: Icon(
                                  Icons.person,
                                  size:
                                      kAvatarRadius, // icon vừa khít vòng tròn
                                  color: Colors.black54,
                                ),
                              ),
                            )
                          : const SizedBox.shrink(),
                    );
                  }

                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      if (showDivider) timeDivider(dividerText),

                      // HÀNG CHÍNH: (slot avatar) + bubble + (slot avatar)
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: kSidePadding,
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment:
                              CrossAxisAlignment.center, // avatar giữa bubble
                          mainAxisAlignment: isMe
                              ? MainAxisAlignment.end
                              : MainAxisAlignment.start,
                          children: [
                            if (!isMe)
                              _avatarSlot(mine: false, visible: showAvatar),

                            // bubble
                            ConstrainedBox(
                              constraints: BoxConstraints(
                                maxWidth: maxBubbleWidth,
                              ),
                              child: Container(
                                margin: EdgeInsets.only(
                                  top: topMargin,
                                  bottom: 2,
                                ),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 8,
                                ),
                                decoration: BoxDecoration(
                                  color: isMe
                                      ? const Color(0xFFE8F0FE)
                                      : const Color(0xFFF2F2F2),
                                  borderRadius: radius,
                                ),
                                child: Text(text),
                              ),
                            ),

                            if (isMe)
                              _avatarSlot(mine: true, visible: showAvatar),
                          ],
                        ),
                      ),

                      // DÒNG GIỜ: canh theo mép bubble, thụt lề bằng slot avatar + side padding
                      if (isStartOfBlock && curTs != null)
                        Padding(
                          padding: EdgeInsets.only(
                            left: isMe
                                ? kSidePadding
                                : (kSidePadding + kAvatarSlotW),
                            right: isMe
                                ? (kSidePadding + kAvatarSlotW)
                                : kSidePadding,
                            bottom: 6,
                            top: 2,
                          ),
                          child: ConstrainedBox(
                            constraints: BoxConstraints(
                              maxWidth: maxBubbleWidth,
                            ),
                            child: Text(
                              hhmm(curTs),
                              textAlign: isMe
                                  ? TextAlign.right
                                  : TextAlign.left,
                              style: TextStyle(
                                fontSize: 11,
                                color: Colors.black.withOpacity(0.55),
                              ),
                            ),
                          ),
                        ),
                    ],
                  );
                },
              ),
            ),

            if (isPartnerTyping)
              const Padding(
                padding: EdgeInsets.only(
                  left: 12,
                  right: 12,
                  bottom: 6,
                  top: 2,
                ),
                child: Align(
                  alignment:
                      Alignment.centerLeft, // hoặc chỉnh theo layout bubble
                  child: TypingWidget(),
                ),
              ),

            // ====== DROP-IN: thay cho block Padding(...) hiện tại ======
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    //TODO: emoji / đính kèm tuỳ bạn dùng
                    // IconButton(
                    //   icon: const Icon(Icons.image_rounded),
                    //   onPressed: () {}, // TODO
                    // ),
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF6F7FB),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: const Color(0xFFE5E7EB)),
                        ),
                        child: TextField(
                          controller: _controller,
                          focusNode: _focusNode, // 👈 thêm
                          minLines: 1,
                          maxLines: 5, // auto-grow
                          keyboardType: TextInputType.multiline,
                          textInputAction: TextInputAction.newline,
                          decoration: const InputDecoration(
                            hintText: 'Nhập tin nhắn...',
                            border: InputBorder.none,
                            isDense: true,
                          ),
                          onChanged: _onTextChanged, // 👈 thêm
                          onSubmitted: (_) => _sendMessage(),
                        ),
                      ),
                    ),

                    const SizedBox(width: 8),

                    // Nút Send: đổi icon/màu theo trạng thái nhập
                    ValueListenableBuilder<TextEditingValue>(
                      valueListenable: _controller,
                      builder: (context, value, _) {
                        final canSend = value.text.trim().isNotEmpty;
                        return GestureDetector(
                          onTap: canSend ? _sendMessage : null,
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 180),
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(22),
                              gradient: canSend
                                  ? const LinearGradient(
                                      colors: [
                                        Color(0xFF60A5FA),
                                        Color(0xFF2563EB),
                                      ],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    )
                                  : const LinearGradient(
                                      colors: [
                                        Color(0xFFE5E7EB),
                                        Color(0xFFD1D5DB),
                                      ],
                                    ),
                              boxShadow: canSend
                                  ? [
                                      BoxShadow(
                                        color: const Color(
                                          0xFF2563EB,
                                        ).withOpacity(0.25),
                                        blurRadius: 12,
                                        offset: const Offset(0, 4),
                                      ),
                                    ]
                                  : [],
                            ),
                            child: Icon(
                              // canSend ? Icons.send_rounded : Icons.mic_none_rounded,
                              canSend ? Icons.send_rounded : Icons.send_rounded,
                              color: canSend
                                  ? Colors.white
                                  : const Color(0xFF6B7280),
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
