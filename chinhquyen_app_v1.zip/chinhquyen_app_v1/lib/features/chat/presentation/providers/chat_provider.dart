import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/network/api_provider.dart';
import '../../../../core/network/chat_service.dart';
import '../../../auth/presentation/providers/profile_provider.dart';

final chatServiceProvider = Provider<ChatService>((ref) {
  return ChatService();
});

//! Api đoạn chat lazy loading
final doanchatListProvider =
    StateNotifierProvider<DoanChatListNotifier, List<Map<String, dynamic>>>(
      (ref) => DoanChatListNotifier(ref),
    );

class DoanChatListNotifier extends StateNotifier<List<Map<String, dynamic>>> {
  DoanChatListNotifier(this.ref) : super([]) {
    fetchDoanChatList();
  }

  final Ref ref;
  int _pageIndex = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  Future<void> fetchDoanChatList() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;

    final result = await ref
        .read(apiServiceProvider)
        .fetchDoanChat(pageIndex: _pageIndex);
    if (result.isEmpty) {
      _hasMore = false;
    } else {
      state = [...state, ...result];
      _pageIndex++;
    }

    _isLoading = false;
  }

  void refresh() {
    _pageIndex = 0;
    _hasMore = true;
    state = [];
    fetchDoanChatList();
  }
}

//! Api nhóm chat lazy loading
final nhomchatListProvider =
    StateNotifierProvider<NhomChatListNotifier, List<Map<String, dynamic>>>(
      (ref) => NhomChatListNotifier(ref),
    );

class NhomChatListNotifier extends StateNotifier<List<Map<String, dynamic>>> {
  NhomChatListNotifier(this.ref) : super([]) {
    fetchNhomChatList();
  }

  final Ref ref;
  int _pageIndex = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  Future<void> fetchNhomChatList() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;

    final result = await ref
        .read(apiServiceProvider)
        .fetchNhomChat(pageIndex: _pageIndex, userId: getUserIdRef(ref));
    if (result.isEmpty) {
      _hasMore = false;
    } else {
      state = [...state, ...result];
      _pageIndex++;
    }

    _isLoading = false;
  }

  void refresh() {
    _pageIndex = 0;
    _hasMore = true;
    state = [];
    fetchNhomChatList();
  }
}

//! Api chat message 1v1 lazy loading
final chatContent1v1ListProvider =
    StateNotifierProvider.family<
      ChatContent1v1ListNotifier,
      List<Map<String, dynamic>>,
      int
    >((ref, receiverId) => ChatContent1v1ListNotifier(ref, receiverId));

class ChatContent1v1ListNotifier
    extends StateNotifier<List<Map<String, dynamic>>> {
  ChatContent1v1ListNotifier(this.ref, this.receiverId) : super([]) {
    refresh(); // load trang đầu ngay khi khởi tạo theo receiver
  }

  final Ref ref;
  final int receiverId;

  int _pageIndex = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  //! Backend đang ORDER BY [Timestamp] DESC (mới -> cũ)
  /// => state cũng giữ DESC, phần tử index 0 là mới nhất
  Future<void> fetchMore() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;
    try {
      final senderId = getUserIdRef(ref).toString();

      final result = await ref
          .read(apiServiceProvider)
          .fetchChatMessageContent(
            pageIndex: _pageIndex,
            sender: senderId,
            receiver: receiverId.toString(),
          );

      if (result.isEmpty) {
        _hasMore = false;
      } else {
        // Nếu API trả DESC như SQL -> dùng trực tiếp.
        // Nếu API trả ASC thì đảo lại: final data = result.reversed.toList();
        final data = result;

        // Thêm các tin CŨ hơn vào CUỐI list để giữ tổng thể DESC.
        state = [...state, ...data];
        _pageIndex++;
      }
    } finally {
      _isLoading = false;
    }
  }

  /// Kéo-to-refresh hoặc mở phòng chat
  Future<void> refresh() async {
    _pageIndex = 0;
    _hasMore = true;
    state = [];
    await fetchMore();
  }

  /// Thêm message mới (realtime / tự gửi) -> phải PREPEND để hiện ngay ở đáy (reverse:true)
  void addIncoming(Map<String, dynamic> msg) {
    state = [msg, ...state];
  }

  // (Optional) chống trùng nhanh
  void addIncomingSafe(Map<String, dynamic> msg) {
    final key =
        '${msg['Sender']}_${msg['Receiver']}_${msg['Timestamp']}_${msg['Message']}';
    final exists = state.any(
      (m) =>
          '${m['Sender']}_${m['Receiver']}_${m['Timestamp']}_${m['Message']}' ==
          key,
    );
    if (!exists) state = [msg, ...state];
  }
}

//! Api chatGroupContentListProvider lazy loading
final chatGroupContentListProvider =
    StateNotifierProvider.family<
      ChatGroupContentListNotifier,
      List<Map<String, dynamic>>,
      int
    >((ref, groupId) => ChatGroupContentListNotifier(ref, groupId));

class ChatGroupContentListNotifier
    extends StateNotifier<List<Map<String, dynamic>>> {
  ChatGroupContentListNotifier(this.ref, this.groupId) : super([]) {
    refresh(); // tải trang đầu cho group này
  }

  final Ref ref;
  final int groupId;

  int _pageIndex = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  Future<void> fetchMore() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;
    try {
      final result = await ref
          .read(apiServiceProvider)
          .fetchGroupChatMessageContent(
            pageIndex: _pageIndex,
            groupId: groupId.toString(),
          );

      if (result.isEmpty) {
        _hasMore = false;
      } else {
        // Nếu API/SQL trả DESC (mới→cũ) thì dùng trực tiếp:
        final data = result;
        // Nếu API trả ASC (cũ→mới) thì đảo: final data = result.reversed.toList();

        // Thêm tin CŨ hơn vào CUỐI list để giữ tổng thể DESC
        state = [...state, ...data];
        _pageIndex++;
      }
    } finally {
      _isLoading = false;
    }
  }

  Future<void> refresh() async {
    _pageIndex = 0;
    _hasMore = true;
    state = [];
    await fetchMore();
  }

  /// Tin mới (realtime/đang gửi) -> PREPEND để hiện ngay ở đáy (reverse:true)
  void addIncoming(Map<String, dynamic> msg) {
    state = [msg, ...state];
  }

  /// (Tùy chọn) chống trùng
  void addIncomingSafe(Map<String, dynamic> msg) {
    final key =
        '${msg['Sender']}_${msg['GroupId']}_${msg['Timestamp']}_${msg['Message']}';
    final exists = state.any(
      (m) =>
          '${m['Sender']}_${m['GroupId']}_${m['Timestamp']}_${m['Message']}' ==
          key,
    );
    if (!exists) state = [msg, ...state];
  }
}

//! Trả về (text, fromMe) hoặc null nếu chưa có tin
final lastMessagePreviewProvider = FutureProvider.autoDispose
    .family<({String text, bool fromMe})?, String>((ref, otherId) async {
      // ✅ đừng .toString() trước khi check null
      final uid = getUserIdRef(ref).toString(); // hoặc getUserIdRef(ref)
      if (uid == null) return null;
      final myId = uid.toString();

      // Proc đã trả TOP 1 cho cả 2 chiều, chỉ cần gọi 1 lần
      final list = await ref
          .read(apiServiceProvider)
          .fetchLastMessageContent(sender: myId, receiver: otherId);

      if (list.isEmpty) return null;

      // Phòng khi API không sort (dù proc đã TOP 1)
      list.sort((a, b) {
        final ta =
            DateTime.tryParse((a['Timestamp'] ?? '').toString()) ??
            DateTime.fromMillisecondsSinceEpoch(0);
        final tb =
            DateTime.tryParse((b['Timestamp'] ?? '').toString()) ??
            DateTime.fromMillisecondsSinceEpoch(0);
        return tb.compareTo(ta); // desc
      });

      final latest = list.first;
      final fromMe = (latest['Sender']?.toString() ?? '') == myId;
      final text = (latest['Message'] ?? '').toString();

      return (text: text, fromMe: fromMe);
    });

//! Trả về (text, fromMe) hoặc null nếu chưa có tin
final lastMessageGroupPreviewProvider = FutureProvider.autoDispose
    .family<({String text, bool fromMe})?, String>((ref, otherGroupId) async {
      // ✅ đừng .toString() trước khi check null
      final uid = getUsernameRef(
        ref,
      ).toString(); //! do là group nên lấy username
      if (uid == null) return null;
      final myId = uid.toString();

      // Proc đã trả TOP 1 cho cả 2 chiều, chỉ cần gọi 1 lần
      final list = await ref
          .read(apiServiceProvider)
          .fetchGroupLastMessageContent(groupId: otherGroupId);

      if (list.isEmpty) return null;

      // Phòng khi API không sort (dù proc đã TOP 1)
      list.sort((a, b) {
        final ta =
            DateTime.tryParse((a['Timestamp'] ?? '').toString()) ??
            DateTime.fromMillisecondsSinceEpoch(0);
        final tb =
            DateTime.tryParse((b['Timestamp'] ?? '').toString()) ??
            DateTime.fromMillisecondsSinceEpoch(0);
        return tb.compareTo(ta); // desc
      });

      final latest = list.first;
      final fromMe = (latest['Sender']?.toString() ?? '') == myId;
      final text = (latest['Message'] ?? '').toString();

      return (text: text, fromMe: fromMe);
    });



//! Typing
final partnerTypingProvider = StateProvider.family<bool, int>(
  (ref, partnerId) => false,
);
