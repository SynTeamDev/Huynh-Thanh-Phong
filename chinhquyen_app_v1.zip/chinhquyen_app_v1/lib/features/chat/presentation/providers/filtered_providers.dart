import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'chat_provider.dart';
import 'search_query_provider.dart';

/// Lọc Đoạn chat: nickname | username | LastMessage (nếu có)
final filteredDoanChatProvider =
    Provider.autoDispose<List<Map<String, dynamic>>>((ref) {
      final q = ref.watch(chatSearchQueryProvider).trim();
      final list = ref.watch(doanchatListProvider); // <-- List<Map> thuần

      if (q.isEmpty) return list;
      final nq = normalizeVi(q);

      return list.where((chat) {
        final nickname = normalizeVi('${chat['nickname'] ?? ''}');
        final username = normalizeVi('${chat['username'] ?? ''}');

        return nickname.contains(nq) || username.contains(nq);
      }).toList();
    });

/// Lọc Nhóm: GroupName | Description (nếu có)
final filteredNhomChatProvider =
    Provider.autoDispose<List<Map<String, dynamic>>>((ref) {
      final q = ref.watch(chatSearchQueryProvider).trim();
      final list = ref.watch(nhomchatListProvider); // <-- List<Map> thuần

      if (q.isEmpty) return list;
      final nq = normalizeVi(q);

      return list.where((chat) {
        final name = normalizeVi('${chat['GroupName'] ?? ''}');
        return name.contains(nq);
      }).toList();
    });
