import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Query người dùng đang nhập
final chatSearchQueryProvider = StateProvider<String>((ref) => '');

/// (Tuỳ chọn) bỏ dấu tiếng Việt + về lowercase để tìm "không dấu"
String normalizeVi(String input) {
  const map = {
    'a': 'àáạảãâầấậẩẫăằắặẳẵ',
    'e': 'èéẹẻẽêềếệểễ',
    'i': 'ìíịỉĩ',
    'o': 'òóọỏõôồốộổỗơờớợởỡ',
    'u': 'ùúụủũưừứựửữ',
    'y': 'ỳýỵỷỹ',
    'd': 'đ',
  };
  var s = input.toLowerCase();
  map.forEach((ascii, accented) {
    for (final ch in accented.characters) {
      s = s.replaceAll(ch, ascii);
    }
  });
  return s;
}
