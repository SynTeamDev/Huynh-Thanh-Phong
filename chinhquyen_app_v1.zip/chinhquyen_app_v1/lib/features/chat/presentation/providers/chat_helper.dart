import 'package:flutter/material.dart';

DateTime? parseTs(dynamic v) {
  if (v == null) return null;
  try {
    return DateTime.parse(v.toString()).toLocal();
  } catch (_) {
    return null;
  }
}

bool isSameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

bool isYesterday(DateTime a, DateTime b) {
  final y = DateTime(b.year, b.month, b.day).subtract(const Duration(days: 1));
  return a.year == y.year && a.month == y.month && a.day == y.day;
}

String two(int n) => n.toString().padLeft(2, '0');
String hhmm(DateTime dt) => '${two(dt.hour)}:${two(dt.minute)}';

String timeLabel(DateTime dt) {
  final now = DateTime.now();
  final hhmm = '${two(dt.hour)}:${two(dt.minute)}';
  if (isSameDay(dt, now)) return '$hhmm, Hôm nay';
  if (isYesterday(dt, now)) return '$hhmm, Hôm qua';
  return '$hhmm ${two(dt.day)}/${two(dt.month)}/${dt.year}';
}

// Mốc 10 phút (tính theo bucket)
const int kTenMinSec = 600;
int tenMinBucket(DateTime dt) => dt.millisecondsSinceEpoch ~/ (kTenMinSec * 1000);
DateTime floorToTenMin(DateTime dt) =>
    DateTime(dt.year, dt.month, dt.day, dt.hour, (dt.minute ~/ 10) * 10);

Widget timeDivider(String text) {
  return Center(
    child: Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.45),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        text,
        style: const TextStyle(color: Colors.white, fontSize: 12),
      ),
    ),
  );
}
