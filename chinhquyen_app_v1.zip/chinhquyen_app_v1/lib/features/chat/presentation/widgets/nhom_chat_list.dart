import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/widgets/custom_snackbar_widget.dart';
import '../providers/chat_provider.dart';
import '../providers/filtered_providers.dart';

class NhomChatList extends ConsumerStatefulWidget {
  const NhomChatList({super.key});

  @override
  ConsumerState<NhomChatList> createState() => _NhomChatListState();
}

class _NhomChatListState extends ConsumerState<NhomChatList> {
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
    
    //! ✅ Quan trọng: trigger lại gọi API (cần thiết)
    Future.microtask(() {
      ref.invalidate(nhomchatListProvider);
    });
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 100) {
      ref.read(nhomchatListProvider.notifier).fetchNhomChatList();
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final chatList = ref.watch(filteredNhomChatProvider);

    return ListView.builder(
      controller: _scrollController,
      padding: EdgeInsets.zero,
      itemCount: chatList.length,
      itemBuilder: (context, index) {
        final chat = chatList[index];
        final GroupName = chat['GroupName'] ?? '';

        final groupIdStr = (chat['GroupId']).toString();
        final lastMsg = ref.watch(lastMessageGroupPreviewProvider(groupIdStr));

        return Theme(
          data: Theme.of(context).copyWith(
            splashColor: Colors.transparent,
            highlightColor: Colors.transparent,
            hoverColor: Colors.transparent,
          ),
          child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.group)),
            title: Text(
              GroupName.toString(),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            subtitle: lastMsg.when(
              data: (v) {
                final fallback = 'Bắt đầu trò chuyện nhóm $GroupName';
                if (v == null || v.text.trim().isEmpty) {
                  return Text(
                    fallback,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  );
                }
                final preview = '${v.fromMe ? 'Bạn: ' : ''}${v.text}';
                return Text(
                  preview,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                );
              },
              loading: () => Text(
                'Bắt đầu trò chuyện nhóm $GroupName',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              error: (_, __) => Text(
                'Bắt đầu trò chuyện nhóm $GroupName',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            trailing: const Icon(
              Icons.circle,
              size: 10,
              color: Colors.transparent,
            ),
            onTap: () {
              final groupId = chat['GroupId'];
              if (groupId is int && groupId > 0) {
                context.push(
                  '/chatboxgroup/$groupId?title=${Uri.encodeComponent(GroupName)}',
                );
              } else {
                // ✅ Xử lý fallback hoặc báo lỗi
                showSnack(context, 'Không thể mở cuộc trò chuyện.');
              }
            },
          ),
        );
      },
    );
  }
}
