import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class TypingWidget extends StatelessWidget {
  const TypingWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SizedBox(
        width: 27,
        height: 27,
        child: Lottie.asset('assets/json/Typing.json', fit: BoxFit.contain),
      ),
    );
  }
}
