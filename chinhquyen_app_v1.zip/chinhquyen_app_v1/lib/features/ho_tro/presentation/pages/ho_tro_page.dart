import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:ionicons/ionicons.dart';

import '../../../../config/env.dart';
import '../../../../core/utils/delay_btn_helper.dart';
import '../../../../core/utils/handle_tel_call.dart';
import '../../../../core/utils/permisson.dart';
import '../../../../core/widgets/form/combobox_field_widget.dart'
    show ComboboxFieldWidget;
import '../../../../core/widgets/form/label_value_row.dart';
import '../../../../core/widgets/form/phone_picker_row.dart';
import '../../../../core/widgets/form/title_label_widget.dart';
import '../providers/ho_tro_provider.dart';
import '../widgets/ho_tro_page_filter.dart';

class HoTroPage extends ConsumerStatefulWidget {
  const HoTroPage({super.key});

  @override
  ConsumerState<HoTroPage> createState() => _HoTroPageState();
}

class _HoTroPageState extends ConsumerState<HoTroPage> {
  final ScrollController _scrollController = ScrollController();

  DateTime? _ngayCt1, _ngayCt2;
  String? _noi_congtac, _status;

  // trên class _HoTroPageState
  static const double _headerHeight = 140;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);

    _initDatesToDefault();
    final filter = ref.read(canboFilterStateProvider);
    if (filter != null) _applyFilterFromTuple(filter);
  }

  void _initDatesToDefault() {
    final now = DateTime.now();
    _ngayCt1 = DateTime(now.year, now.month - 6, 1);
    _ngayCt2 = DateTime(now.year, now.month + 2, 0);
  }

  void _applyFilterFromTuple((DateTime, DateTime, String?, String?) filter) {
    final (ngayCt1, ngayCt2, noi_congtac, status) = filter;
    _ngayCt1 = ngayCt1;
    _ngayCt2 = ngayCt2;

    _noi_congtac = noi_congtac;
    _status = status;
  }

  Future<void> _onRefreshPressed() async {
    if (!GlobalButtonDisableHelper.isDisabled) {
      GlobalButtonDisableHelper.disableTemporarily(seconds: 1);
      setState(() {
        _initDatesToDefault();
        _noi_congtac = _status = null;
      });
      ref.read(canboFilterStateProvider.notifier).state = null;

      // ✅ Quan trọng: trigger lại gọi API
      ref.invalidate(canboListProvider);
    }
  }

  Future<void> _onFilterPressed() async {
    if (!GlobalButtonDisableHelper.isDisabled) {
      GlobalButtonDisableHelper.disableTemporarily(seconds: 1);
      final result = await HoTroPageFilter(
        initialFromDate: _ngayCt1 ?? DateTime.now(),
        initialToDate: _ngayCt2 ?? DateTime.now(),
        initialValues: (_noi_congtac, _status),
      ).show(context);

      if (result != null) {
        ref.read(canboFilterStateProvider.notifier).state = result;
        setState(() => _applyFilterFromTuple(result));
        // ✅ Quan trọng: trigger lại gọi API
        ref.invalidate(canboListProvider);
      }
    }
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 100) {
      ref.read(canboListProvider.notifier).fetchCanBoList();
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final canBoList = ref.watch(canboListProvider);

    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // Nền trống đồng
          Positioned.fill(
            child: Opacity(
              opacity: 0.25,
              child: Image.asset(
                'assets/images/trongdongbg.png',
                fit: BoxFit.cover,
              ),
            ),
          ),

          // ---- Header ----
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              height: _headerHeight,
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(20),
                  bottomRight: Radius.circular(20),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 6,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: SafeArea(
                bottom: false,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // dòng tiêu đề + nút
                      Row(
                        children: [
                          // nút Back
                          IconButton(
                            icon: const Icon(
                              Icons.arrow_back_ios_new_rounded,
                              color: Colors.blue,
                            ),
                            onPressed: () => Navigator.of(context).pop(),
                          ),
                          const Expanded(
                            child: Text(
                              'Gọi điện hỗ trợ',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                                color: Colors.blue,
                              ),
                            ),
                          ),
                          IconButton(
                            icon: const Icon(
                              Ionicons.refresh,
                              color: Colors.blue,
                            ),
                            onPressed: _onRefreshPressed,
                          ),
                          IconButton(
                            icon: const Icon(
                              Ionicons.search_outline,
                              color: Colors.blue,
                            ),
                            onPressed: _onFilterPressed,
                          ),
                        ],
                      ),

                      // 🔥 Hàng nút gọi nhanh 113/114/115
                      SizedBox(
                        height: 44,
                        child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          physics: const BouncingScrollPhysics(),
                          child: Row(
                            children: [
                              const SizedBox(width: 2),
                              _EmergencyCallChip(
                                label: 'Công an',
                                number: '113',
                                bg: const Color(0xFFE3F2FD),
                                fg: const Color(0xFF1565C0),
                                onTap: () => handleTelCall('113'),
                              ),
                              const SizedBox(width: 8),
                              _EmergencyCallChip(
                                label: 'Cứu hoả',
                                number: '114',
                                bg: const Color(0xFFFFEBEE),
                                fg: const Color(0xFFC62828),
                                onTap: () => handleTelCall('114'),
                              ),
                              const SizedBox(width: 8),
                              _EmergencyCallChip(
                                label: 'Cấp cứu',
                                number: '115',
                                bg: const Color(0xFFE8F5E9),
                                fg: const Color(0xFF2E7D32),
                                onTap: () => handleTelCall('115'),
                              ),
                              const SizedBox(width: 2),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // 🔥 Filter bar ghim ngay dưới tiêu đề
          Positioned(
            top: _headerHeight, // 👈 ngay dưới tiêu đề
            left: 0,
            right: 0,
            child: buildFilterBar(),
          ),

          // Danh sách cán bộ
          Positioned.fill(
            top: _headerHeight + 50,
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              itemCount: canBoList.length,
              itemBuilder: (context, index) {
                final item = canBoList[index];
                return Container(
                  margin: const EdgeInsets.only(bottom: 2),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.8),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade200),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.03),
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TitleLabelWidget(
                        title:
                            '${item['ma_canbo'] ?? ''} - ${item['ten_canbo'] ?? ''}',
                      ),
                      const Divider(),
                      LabelValueRow(
                        label: '',
                        labelWidget: RichText(
                          textAlign: TextAlign.left,
                          text: TextSpan(
                            style: const TextStyle(fontSize: 13),
                            children: [
                              const TextSpan(
                                text: 'Công tác tại: ',
                                style: TextStyle(
                                  color: Colors.grey, // 👈 Chữ xám
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              TextSpan(
                                text: item['noi_congtac'] ?? '',
                                style: const TextStyle(
                                  color: Colors.black87,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        value: '',
                        valueWidget: Align(
                          alignment: Alignment.centerRight,
                          child: Row(
                            mainAxisSize: MainAxisSize
                                .min, // ✅ không chiếm full width -> đỡ tràn
                            children: [
                              const Text(
                                'Trạng thái: ',
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(width: 6),
                              Flexible(
                                // ✅ cho phép badge co lại trong ô bên phải
                                child: _StatusBadgeCompact(
                                  status: item['status'].toString(),
                                ),
                              ),
                            ],
                          ),
                        ),

                        maxHeight: 32,
                      ),
                      PhonePickerRow(
                        label: '',
                        labelWidget: RichText(
                          textAlign: TextAlign.left,
                          text: TextSpan(
                            style: const TextStyle(fontSize: 13),
                            children: [
                              const TextSpan(
                                text: 'Số gọi hỗ trợ',
                                style: TextStyle(
                                  color: Colors.grey, // 👈 Chữ xám
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                        phones: [
                          item['dien_thoai'] ?? '',
                          item['dien_thoai1'] ?? '',
                          item['dien_thoai2'] ?? '',
                        ],
                        onCall: (phone) => handlePhoneCall(phone),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Future<void> handlePhoneCall(String phone) async {
    if (phone.isEmpty) return;
    await requestMicrophonePermission();
    _openCallWebView(phone);
  }

  void _openCallWebView(String phone) {
    final userId = 17;
    final appId = 'CongDanApp';
    final url = '${Env.urlCall}?user_id=$userId&hash=$phone&app_id=$appId';

    final encodedUrl = Uri.encodeComponent(url); // 👈 Encode tránh lỗi ký tự

    context.push('/webviewcall?url=$encodedUrl');
  }

  //! Filter bar
  Widget buildFilterBar() {
    return Container(
      height: 56,
      padding: const EdgeInsets.only(left: 16),
      child: Row(
        children: [
          const Icon(Ionicons.filter_outline, color: Colors.blue, size: 20),
          const SizedBox(width: 4),
          const Text(
            'Lọc',
            style: TextStyle(color: Colors.blue, fontWeight: FontWeight.w600),
          ),
          const SizedBox(width: 8),
          Container(width: 1, height: 24, color: Colors.grey.shade400),
          const SizedBox(width: 8),
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                      top: 6,
                    ), // 👈 chỉnh số này cho cân giữa
                    child: SizedBox(
                      width: 160,
                      child: ComboboxFieldWidget(
                        label: '',
                        tableName: 'trangthaicanbo',
                        hint: 'Tất cả',
                        selectedValue: _status,
                        onChanged: (value) {
                          setState(() => _status = value);
                          ref.read(canboFilterStateProvider.notifier).state = (
                            _ngayCt1 ?? DateTime.now(),
                            _ngayCt2 ?? DateTime.now(),
                            _noi_congtac,
                            value,
                          );
                          ref.invalidate(canboListProvider);
                        },
                        isCode: false,
                        dense: true,
                      ),
                    ),
                  ),

                  const SizedBox(width: 8),

                  // 👉 Thêm các combo khác nếu cần
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusBadgeCompact extends StatelessWidget {
  const _StatusBadgeCompact({required this.status});
  final String status;

  @override
  Widget build(BuildContext context) {
    // map status -> text & color
    String text;
    Color color;
    switch (status) {
      case '1':
        text = 'Đang trực';
        color = Colors.green;
        break;
      case '2':
        text = 'Ngoài giờ làm việc';
        color = Colors.red;
        break;
      default:
        text = 'Không xác định';
        color = Colors.grey;
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        // Giới hạn tối đa theo không gian thực tế của cột phải
        final maxW = constraints.maxWidth; // cột phải
        final cap = maxW * 0.999; // badge tối đa 60% ô phải (tuỳ chỉnh)

        return ConstrainedBox(
          constraints: BoxConstraints(maxWidth: cap),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis, // ✅ cắt gọn
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        );
      },
    );
  }
}

class _EmergencyCallChip extends StatelessWidget {
  const _EmergencyCallChip({
    required this.label,
    required this.number,
    required this.onTap,
    required this.bg,
    required this.fg,
  });

  final String label;
  final String number;
  final VoidCallback onTap;
  final Color bg;
  final Color fg;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: bg,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Ionicons.call, size: 16, color: fg),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(color: fg, fontWeight: FontWeight.w600),
              ),
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: fg.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  number,
                  style: TextStyle(color: fg, fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
