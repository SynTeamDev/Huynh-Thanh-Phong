import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/shared/base_filter.dart';
import '../../../../core/widgets/form/combobox_field_widget.dart';
import '../../../../core/widgets/form/input_field_widget.dart';

class HoTroPageFilter
    extends BaseFilter<(DateTime, DateTime, String?, String?)> {
  final (String?, String?)? initialValues;

  const HoTroPageFilter({
    super.key,
    required super.initialFromDate,
    required super.initialToDate,
    this.initialValues,
    // ẩn ngày tháng
    super.showDateFields = false,
  });

  @override
  ConsumerState<HoTroPageFilter> createState() =>
      _HoTroPageFilterConsumerState();
}

class _HoTroPageFilterConsumerState
    extends
        BaseFilterState<
          (DateTime, DateTime, String?, String?),
          HoTroPageFilter
        > {
  String? noi_congtac, status;
  late TextEditingController _noi_congtacController;

  @override
  void initState() {
    super.initState();
    _noi_congtacController = TextEditingController();

    final initial = widget.initialValues;
    if (initial != null) {
      noi_congtac = initial.$1;

      status = initial.$2;

      _noi_congtacController.text = noi_congtac ?? '';
    }
  }

  @override
  void dispose() {
    _noi_congtacController.dispose();
    super.dispose();
  }

  @override
  List<Widget> buildFilterFields() {
    return [
      InputFieldWidget(
        label: 'Nơi công tác',
        controller: _noi_congtacController,
        hintText: 'Nhập nơi công tác của cán bộ',
        onChanged: (value) {
          setState(() {
            noi_congtac = value;
          });
        },
      ),

      const SizedBox(height: 5),
      ComboboxFieldWidget(
        label: 'Trạng thái',
        tableName: 'trangthaicanbo',
        selectedValue: status,
        onChanged: (value) {
          setState(() {
            status = value;
          });
        },
        isCode: false,
      ),
    ];
  }

  @override
  (DateTime, DateTime, String?, String?) getFilterResult() {
    return (fromDate, toDate, noi_congtac, status);
  }
}
