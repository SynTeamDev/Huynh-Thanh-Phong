import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/network/api_provider.dart';

//! State lưu giá trị filter
final canboFilterStateProvider =
    StateProvider<
      (
        DateTime, // ngay_ct1
        DateTime, // ngay_ct2
        String?, // noi_congtac
        String?, // status
      )?
    >((ref) => null);
//! State lấy danh sách cán bộ
final canboListProvider =
    StateNotifierProvider<CanBoListNotifier, List<Map<String, dynamic>>>(
      (ref) => CanBoListNotifier(ref),
    );

//! Api DSCANBO lazy loading
class CanBoListNotifier extends StateNotifier<List<Map<String, dynamic>>> {
  CanBoListNotifier(this.ref) : super([]) {
    fetchCanBoList();
  }

  final Ref ref;
  int _pageIndex = 0;
  bool _hasMore = true;
  bool _isLoading = false;

  Future<void> fetchCanBoList() async {
    if (_isLoading || !_hasMore) return;
    _isLoading = true;

    final filter = ref.read(canboFilterStateProvider);
    final (ngay_ct1, ngay_ct2, noi_congtac, status) =
        filter ?? (null, null, null, null);

    final result = await ref
        .read(apiServiceProvider)
        .fetchDSCANBO(
          pageIndex: _pageIndex,
          ngay_ct1: ngay_ct1,
          ngay_ct2: ngay_ct2,
          noi_congtac: noi_congtac,
          status: status,
        );

    if (result.isEmpty) {
      _hasMore = false;
    } else {
      state = [...state, ...result];
      _pageIndex++;
    }

    _isLoading = false;
  }
}
