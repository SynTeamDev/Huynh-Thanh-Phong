class Env {
  //static const baseUrl = 'http://192.168.1.200:5019';
  static const String baseUrl = 'https://ubpx.syn.com.vn';
  static const String weatherUrl = 'https://api.openweathermap.org/data/2.5';
  static const String weatherApiKey = '8fddbcd00caa56dff1f51927a5bd5ba6';
  static const String urlCall = 'https://vt.syn.com.vn:4433/Main/Index.html';

  //static const String directionsKey = 'AIzaSyD-WSMutElprjWFWanFZt0-eRezUWXnq3A';
}
