import 'package:chinhquyen_app/features/auth/presentation/pages/login_page.dart';
import 'package:chinhquyen_app/features/auth/presentation/pages/profile_page.dart';
import 'package:chinhquyen_app/features/ho_tro/presentation/pages/ho_tro_page.dart';
import 'package:chinhquyen_app/features/home-khampha-tracuu-map/presentation/widgets/home-khampha/dv_hanh_chinh_cong/presentation/widgets/dv_hanh_chinh_cong_add.dart';
import 'package:chinhquyen_app/features/home-khampha-tracuu-map/presentation/widgets/home-khampha/quan_ly_cuoc_hop/presentation/widgets/quan_ly_cuoc_hop_add.dart';
import 'package:chinhquyen_app/features/home-khampha-tracuu-map/presentation/pages/map_page.dart';
import 'package:chinhquyen_app/features/blank/presentation/pages/blank_page.dart';
import 'package:chinhquyen_app/features/home-khampha-tracuu-map/presentation/widgets/home-khampha/tim_kiem_dia_diem/presentation/pages/tim_kiem_dia_diem_page.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../core/shared/openapp/app_target.dart';
import '../core/shared/openapp/open_external_app_page.dart';
import '../core/shared/splash_view.dart';
import '../core/widgets/custom_navbar_widget.dart';
import '../core/widgets/custom_webview_widget.dart';
import '../features/chat/presentation/pages/chat_box_group_page.dart';
import '../features/chat/presentation/pages/chat_box_page.dart';
import '../features/chat/presentation/pages/chat_page.dart';
import '../features/chat/presentation/pages/create_group_page.dart';
import '../features/cuoc_song_thong_tin/presentation/pages/cuoc_song_tt_page.dart';
import '../features/cuoc_song_thong_tin/presentation/widgets/guong_sang/all_local_hero.dart';
import '../features/cuoc_song_thong_tin/presentation/widgets/guong_sang/detail_local_heroes.dart';
import '../features/cuoc_song_thong_tin/presentation/widgets/tin_chinh_tri_xh/politi_all_local_hero.dart';
import '../features/cuoc_song_thong_tin/presentation/widgets/tin_chinh_tri_xh/politi_detail_local_heroes.dart';
import '../features/ho_tro/presentation/widgets/call_webview_screen.dart';
import '../features/home-khampha-tracuu-map/presentation/pages/kham_pha_page.dart';
import '../features/home-khampha-tracuu-map/presentation/pages/tra_cuu_page.dart';
import '../features/home-khampha-tracuu-map/presentation/widgets/home-khampha/checkin_hoi_nghi/checkin_hoi_nghi_page.dart';
import '../features/home-khampha-tracuu-map/presentation/widgets/home-khampha/danh_ba_co_quan/presentation/pages/danh_ba_co_quan_page.dart';
import '../features/home-khampha-tracuu-map/presentation/widgets/home-khampha/danh_ba_khan_cap/danh_ba_khan_cap_page.dart';
import '../features/home-khampha-tracuu-map/presentation/widgets/home-khampha/dv_hanh_chinh_cong/presentation/pages/dv_hanh_chinh_cong_page.dart';
import '../features/home-khampha-tracuu-map/presentation/widgets/home-khampha/lich_cuoc_hop/presentation/pages/lich_cuoc_hop_page.dart';
import '../features/home-khampha-tracuu-map/presentation/widgets/home-khampha/phan_anh_gop_y/presentation/pages/phan_anh_gop_y_page.dart';
import '../features/home-khampha-tracuu-map/presentation/widgets/home-khampha/phan_anh_gop_y/presentation/widgets/phan_anh_gop_y_add.dart';
import '../features/home-khampha-tracuu-map/presentation/widgets/home-khampha/quan_ly_cuoc_hop/presentation/pages/quan_ly_cuoc_hop_page.dart';
import '../features/home-khampha-tracuu-map/presentation/widgets/home-khampha/thong_ke_ho_dan_cu/presentation/pages/thong_ke_ho_dan_cu_page.dart';
import '../features/home-khampha-tracuu-map/presentation/widgets/tracuu/cong_dong/cong_dong_page.dart';
import '../features/home-khampha-tracuu-map/presentation/widgets/tracuu/nha_van_hoa/nha_van_hoa_page.dart';
import '../features/home-khampha-tracuu-map/presentation/widgets/tracuu/tram_y_te/tram_y_te_page.dart';
import '../features/home-khampha-tracuu-map/presentation/widgets/tracuu/truong_hoc/truong_hoc_page.dart';
import '../features/home_v1/home_v1_page.dart';

final _shellNavigatorKey = GlobalKey<NavigatorState>();

final GoRouter appRouter = GoRouter(
  navigatorKey: _shellNavigatorKey, // 👈 navigator chính
  initialLocation: '/splash',
  // initialLocation: '/home',
  routes: [
    // 1) Splash đứng ngoài shell để KHÔNG có bottom bar
    GoRoute(
      path: '/splash',
      // pageBuilder: (context, state) =>
      //     const NoTransitionPage(child: SplashView()),
      // hoặc muốn mượt hơn:
      pageBuilder: (context, state) => CustomTransitionPage(
        child: const SplashView(),
        transitionsBuilder: (ctx, anim, _, child) =>
            FadeTransition(opacity: anim, child: child),
      ),
    ),

    // 2) App chính với bottom bar
    ShellRoute(
      builder: (context, state, child) => Scaffold(
        backgroundColor: Colors.white,
        body: child,
        bottomNavigationBar: const CustomNavbarWidget(),
      ),
      routes: [
        GoRoute(
          path: '/cstt',
          builder: (context, state) => const CuocSongTTPage(),
        ),
        GoRoute(path: '/home', builder: (context, state) => const HomeV1Page()),
        GoRoute(path: '/map', builder: (context, state) => const MapPage()),
      ],
    ),

    GoRoute(
      path: '/login',
      parentNavigatorKey: _shellNavigatorKey,
      pageBuilder: (context, state) {
        return MaterialPage(fullscreenDialog: true, child: const LoginPage());
      },
    ),

    GoRoute(
      path: '/profile',
      parentNavigatorKey: _shellNavigatorKey,
      pageBuilder: (context, state) {
        return MaterialPage(fullscreenDialog: true, child: const ProfilePage());
      },
    ),

    GoRoute(
      path: '/blankpage',
      parentNavigatorKey: _shellNavigatorKey,
      pageBuilder: (context, state) {
        return MaterialPage(fullscreenDialog: true, child: const BlankPage());
      },
    ),

    GoRoute(
      path: '/webview',
      parentNavigatorKey: _shellNavigatorKey,
      builder: (context, state) {
        final title = state.uri.queryParameters['title'] ?? '';
        final url = state.uri.queryParameters['url'] ?? '';
        return CustomWebViewWidget(title: title, url: url);
      },
    ),

    GoRoute(
      path: '/screen/:id',
      parentNavigatorKey: _shellNavigatorKey,
      builder: (context, state) {
        final id = state.pathParameters['id']!;
        final title = state.uri.queryParameters['title'] ?? '';

        switch (id) {
          //! Thông tin, danh bạ
          case '00.09.01':
            return DanhBaKhanCapPage(title: title);
          case '00.09.02':
            return DanhBaCoQuanPage(title: title);
          //! Công dân số
          case '00.12.01':
            return PhanAnhGopYPage(title: title);
          case '00.12.05':
            return HoTroPage();
          case '00.12.06':
            return TimKiemDiaDiemPage(title: title);
          // case '00.12.11':
          //   return ChatPage(title: title);
          //! Chính quyền số
          case '00.13.01':
            return QuanLyCuocHopPage(title: title);
          case '00.13.07':
            return CheckinHoiNghiPage(title: title);
          case '00.13.08':
            return DanhBaKhanCapPage(title: title);
          case '00.13.09':
            return ThongKeHoDanCuPage(title: title);
          case '00.13.10':
            return LichCuocHopPage(title: title);
          case '00.13.11':
            return DVHanhChinhCongPage(title: title);
          //! Dịch vụ số
          case '00.10.01':
            return OpenExternalAppPage(app: ExternalApp.ahamove);
          case '00.10.02':
            return OpenExternalAppPage(app: ExternalApp.momo);
          case '00.10.03':
            return OpenExternalAppPage(app: ExternalApp.vnptSmartCA);
          case '00.10.04':
            return OpenExternalAppPage(app: ExternalApp.zaloPay);
          case '00.10.05':
            return OpenExternalAppPage(app: ExternalApp.vnPay);
          case '00.10.06':
            return OpenExternalAppPage(app: ExternalApp.viettelPay);
          case '00.10.07':
            return OpenExternalAppPage(app: ExternalApp.vietinBankiPay);
          case '00.10.08':
            return OpenExternalAppPage(app: ExternalApp.vnptPay);
          //! Viễn thông
          case '00.11.01':
            return OpenExternalAppPage(app: ExternalApp.viettel);
          case '00.11.02':
            return OpenExternalAppPage(app: ExternalApp.mobifone);
          case '00.11.03':
            return OpenExternalAppPage(app: ExternalApp.myVnPT);

          //! dành cho Tra cứu
          case '10.01.01':
            return NhaVanHoaPage(title: title);
          case '10.01.02':
            return TramYTePage(title: title);
          case '10.01.03':
            return TruongHocPage(title: title);
          case '10.01.04':
            return CongDongPage(title: title);

          default:
            return BlankPage(title: title);
        }
      },
    ),

    GoRoute(
      path: '/webviewcall',
      parentNavigatorKey: _shellNavigatorKey,
      builder: (context, state) {
        final url = state.uri.queryParameters['url'] ?? '';
        return CallWebViewScreen(url: url);
      },
    ),

    GoRoute(
      path: '/qlcuochopAdd',
      parentNavigatorKey: _shellNavigatorKey,
      pageBuilder: (context, state) {
        return MaterialPage(
          fullscreenDialog: true,
          child: const QuanLyCuocHopAdd(),
        );
      },
    ),
    GoRoute(
      path: '/phananhgopyAdd',
      parentNavigatorKey: _shellNavigatorKey,
      pageBuilder: (context, state) {
        return MaterialPage(
          fullscreenDialog: true,
          child: const PhanAnhGopYAdd(),
        );
      },
    ),

    GoRoute(
      path: '/dvhanhchinhcongAdd',
      parentNavigatorKey: _shellNavigatorKey,
      pageBuilder: (context, state) {
        return MaterialPage(
          fullscreenDialog: true,
          child: const DVHanhChinhCongAdd(),
        );
      },
    ),

    GoRoute(
      path: '/tracuu',
      parentNavigatorKey: _shellNavigatorKey,
      pageBuilder: (context, state) {
        return MaterialPage(fullscreenDialog: true, child: const TraCuuPage());
      },
    ),
    GoRoute(
      path: '/khampha',
      parentNavigatorKey: _shellNavigatorKey,
      pageBuilder: (context, state) {
        return MaterialPage(fullscreenDialog: true, child: const KhamPhaPage());
      },
    ),

    GoRoute(
      path: '/hotro',
      parentNavigatorKey: _shellNavigatorKey,
      pageBuilder: (context, state) {
        return MaterialPage(fullscreenDialog: true, child: const HoTroPage());
      },
    ),

    GoRoute(
      path: '/chatbox/:receiverId',
      parentNavigatorKey: _shellNavigatorKey,
      builder: (context, state) {
        final receiverIdStr = state.pathParameters['receiverId'] ?? '0';
        final receiverId = int.tryParse(receiverIdStr) ?? 0;

        final title = state.uri.queryParameters['title'] ?? '';
        final receiverUserName =
            state.uri.queryParameters['receiverUserName'] ?? '';

        return ChatBoxPage(
          receiverId: receiverId,
          title: title,
          receiverUserName: receiverUserName,
        );
      },
    ),

    GoRoute(
      path: '/create-group',
      parentNavigatorKey: _shellNavigatorKey,
      pageBuilder: (context, state) {
        return MaterialPage(
          fullscreenDialog: true,
          child: const CreateGroupPage(),
        );
      },
    ),

    GoRoute(
      path: '/chatboxgroup/:GroupId',
      parentNavigatorKey: _shellNavigatorKey,
      builder: (context, state) {
        final GroupIdStr = state.pathParameters['GroupId'] ?? '0';
        final GroupId = int.tryParse(GroupIdStr) ?? 0;

        final title = state.uri.queryParameters['title'] ?? '';

        return ChatBoxGroupPage(groupId: GroupId, title: title);
      },
    ),
    //! tấm gương sáng - tất cả
    GoRoute(
      name: 'allLocalHero',
      path: '/guong-sang/all',
      parentNavigatorKey: _shellNavigatorKey,
      builder: (context, state) => const AllLocalHeroPage(),
    ),
    //! tấm gương sáng
    GoRoute(
      name: 'heroDetail',
      path: '/guong-sang/:id',
      parentNavigatorKey: _shellNavigatorKey,
      builder: (context, state) {
        final id = state.pathParameters['id'] ?? '';
        final title = state.uri.queryParameters['title'] ?? '';
        return DetailLocalHeroes(id: id, title: title);
      },
    ),

    //! tin chính trị - tất cả
    GoRoute(
      name: 'politiallLocalHero',
      path: '/tin-chinh-tri/all',
      parentNavigatorKey: _shellNavigatorKey,
      builder: (context, state) => const PolitiAllLocalHeroPage(),
    ),
    //! tin chính trị
    GoRoute(
      name: 'politiheroDetail',
      path: '/tin-chinh-tri/:id',
      parentNavigatorKey: _shellNavigatorKey,
      builder: (context, state) {
        final id = state.pathParameters['id'] ?? '';
        final title = state.uri.queryParameters['title'] ?? '';
        return PolitiDetailLocalHeroes(id: id, title: title);
      },
    ),
  ],
);
