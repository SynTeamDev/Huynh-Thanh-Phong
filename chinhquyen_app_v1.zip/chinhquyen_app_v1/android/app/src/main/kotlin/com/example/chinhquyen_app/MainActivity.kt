package com.example.chinhquyen_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
