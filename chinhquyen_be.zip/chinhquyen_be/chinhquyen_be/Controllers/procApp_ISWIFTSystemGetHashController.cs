﻿using chinhquyen_be.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace chinhquyen_be.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class procApp_ISWIFTSystemGetHashController : ControllerBase
    {
        private readonly DataContext _context;
        public procApp_ISWIFTSystemGetHashController(DataContext context)
        {
            _context = context;
        }

        [HttpGet("{username}")]
        public async Task<IActionResult> GetHash(string username)
        {
            await using var cmd = _context.Database.GetDbConnection().CreateCommand();
            cmd.CommandText = "procApp_ISWIFTSystemGetHash";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@UserName", username));

            if (cmd.Connection.State != ConnectionState.Open)
            {
                await cmd.Connection.OpenAsync();
            }

            var result = await cmd.ExecuteScalarAsync();

            return Ok(result?.ToString());
        }
    }
}
