﻿using chinhquyen_be.Models;
using Microsoft.AspNetCore.Mvc;

namespace chinhquyen_be.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UploadController : ControllerBase
    {
        private readonly string _folderPath;

        public UploadController(IWebHostEnvironment env)
        {
            _folderPath = Path.Combine(env.WebRootPath ?? "wwwroot", "phananh");
            if (!Directory.Exists(_folderPath))
                Directory.CreateDirectory(_folderPath);
        }

        const long TenMB = 10 * 1024 * 1024;

        [HttpPost("single")]
        [Consumes("multipart/form-data")]
        [RequestSizeLimit(TenMB)]
        [RequestFormLimits(MultipartBodyLengthLimit = TenMB)]
        public async Task<IActionResult> UploadSingle([FromForm] SingleFileUploadRequest req)
        {
            var file = req.file;
            if (file == null || file.Length == 0)
                return BadRequest("File is empty.");

            var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
            var allow = new HashSet<string>{
            ".jpg",".jpeg",".png",".gif",".webp",
            ".mp4",".mov",".avi",".mkv",
            ".pdf",".doc",".docx",".xls",".xlsx",".txt",".zip",".rar"
        };
            if (!allow.Contains(ext)) return BadRequest("Unsupported file type.");

            var safeName = $"{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}_{Guid.NewGuid():N}{ext}";
            var fullPath = Path.Combine(_folderPath, safeName);

            await using (var stream = System.IO.File.Create(fullPath))
                await file.CopyToAsync(stream);

            var baseUrl = $"{Request.Scheme}://{Request.Host}";
            var url = $"{baseUrl}/phananh/{safeName}";
            return Ok(new { url, name = safeName, size = file.Length, ext });
        }

        [HttpPost("multi")]
        [Consumes("multipart/form-data")]
        [RequestSizeLimit(TenMB)]
        [RequestFormLimits(MultipartBodyLengthLimit = TenMB)]
        public async Task<IActionResult> UploadMulti([FromForm] MultiFileUploadRequest req)
        {
            if (req.files == null || req.files.Count == 0)
                return BadRequest("No files.");

            var results = new List<object>();
            var allow = new HashSet<string>{
            ".jpg",".jpeg",".png",".gif",".webp",
            ".mp4",".mov",".avi",".mkv",
            ".pdf",".doc",".docx",".xls",".xlsx",".txt",".zip",".rar"
        };

            foreach (var file in req.files)
            {
                var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
                if (!allow.Contains(ext)) continue;

                var safeName = $"{DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()}_{Guid.NewGuid():N}{ext}";
                var fullPath = Path.Combine(_folderPath, safeName);
                await using var stream = System.IO.File.Create(fullPath);
                await file.CopyToAsync(stream);

                var baseUrl = $"{Request.Scheme}://{Request.Host}";
                var url = $"{baseUrl}/phananh/{safeName}";
                results.Add(new { url, name = safeName, size = file.Length, ext });
            }
            return Ok(results);
        }
    }
}
