﻿using System.Data;
using chinhquyen_be.Data;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace chinhquyen_be.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class procApp_storage_govController : ControllerBase
    {
        private readonly DataContext _context;
        public procApp_storage_govController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get(
             string? ma_ttp = "",
             string? category = "",
             string? type = ""
        )
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();
                var parameters = new DynamicParameters();
                parameters.Add("@ma_ttp", ma_ttp);
                parameters.Add("@category", category);
                parameters.Add("@type", type);

                var result = await connection.QueryAsync(
                    "procApp_storage_gov",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }
    }
}
