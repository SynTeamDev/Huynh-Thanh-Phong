﻿using System.Data;
using chinhquyen_be.Data;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace chinhquyen_be.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class procApp_timkiemdiadiemController : ControllerBase
    {
        private readonly DataContext _context;
        public procApp_timkiemdiadiemController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetDSdiadiem(
          int? pageIndex = 0,
          string? ten_location = "",
          string? ma_lhhd = "",
          DateTime? ngay_ct1 = null,
          DateTime? ngay_ct2 = null
        )
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();

                var parameters = new DynamicParameters();
                parameters.Add("@Type", 1);
                parameters.Add("@f_ten_location", ten_location);
                parameters.Add("@f_ma_lhhd", ma_lhhd);
                parameters.Add("@f_ngay_ct1", ngay_ct1, DbType.Date);
                parameters.Add("@f_ngay_ct2", ngay_ct2, DbType.Date);
                parameters.Add("@pageIndex", pageIndex);
                parameters.Add("@pageSize", 10);

                var result = await connection.QueryAsync(
                    "procApp_timkiemdiadiem",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }
    }
}
