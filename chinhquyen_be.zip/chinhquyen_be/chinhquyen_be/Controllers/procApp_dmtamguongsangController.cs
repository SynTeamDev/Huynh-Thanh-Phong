﻿using System.Data;
using chinhquyen_be.Data;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace chinhquyen_be.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class procApp_dmtamguongsangController : ControllerBase
    {
        private readonly DataContext _context;
        public procApp_dmtamguongsangController(DataContext context)
        {
            _context = context;
        }

        [HttpGet("tam_guong_sang")]
        public async Task<IActionResult> Get(
          int type,
          int? pageIndex = 0
        )
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();
                var parameters = new DynamicParameters();
                parameters.Add("@Type", type);
                parameters.Add("@pageIndex", pageIndex);
                parameters.Add("@pageSize", 10);

                var result = await connection.QueryAsync(
                    "procApp_dmtamguongsang",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }
    }
}
