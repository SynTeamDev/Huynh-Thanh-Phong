﻿using System.Data;
using chinhquyen_be.Data;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace chinhquyen_be.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class procApp_danhbacoquanController : ControllerBase
    {
        private readonly DataContext _context;
        public procApp_danhbacoquanController(DataContext context)
        {
            _context = context;
        }

        [HttpGet("danhbacoquan")]
        public async Task<IActionResult> Get(
          int? pageIndex = 0,
          string? ma_loai = "",
          string? ma_ttp = "",
          string? ma_phuongxa = "",
          DateTime? ngay_ct1 = null,
          DateTime? ngay_ct2 = null
        )
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();
                var parameters = new DynamicParameters();
                parameters.Add("@Type", 1);
                parameters.Add("@f_ma_loai", ma_loai);
                parameters.Add("@f_ma_ttp", ma_ttp);
                parameters.Add("@f_ma_phuongxa", ma_phuongxa);
                parameters.Add("@f_ngay_ct1", ngay_ct1, DbType.Date);
                parameters.Add("@f_ngay_ct2", ngay_ct2, DbType.Date);
                parameters.Add("@pageIndex", pageIndex);

                var result = await connection.QueryAsync(
                    "procApp_danhbacoquan",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }
    }
}
