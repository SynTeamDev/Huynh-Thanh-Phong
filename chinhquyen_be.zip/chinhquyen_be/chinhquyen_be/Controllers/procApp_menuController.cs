﻿using chinhquyen_be.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

using System.Data;

namespace chinhquyen_be.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class procApp_menuController : ControllerBase
    {
        private readonly DataContext _context;

        public procApp_menuController(DataContext context)
        {
            _context = context;
        }

        [HttpGet("{type}")]
        public async Task<IActionResult> GetMenu(int type)
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();

                await using var command = connection.CreateCommand();
                command.CommandText = "procApp_menu";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@Type", type));

                var reader = await command.ExecuteReaderAsync();

                var result = new List<Dictionary<string, object>>();

                while (await reader.ReadAsync())
                {
                    var row = new Dictionary<string, object>();

                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        row[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }

                    result.Add(row);
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Lỗi server: {ex.Message}");
            }
        }
    }
}
