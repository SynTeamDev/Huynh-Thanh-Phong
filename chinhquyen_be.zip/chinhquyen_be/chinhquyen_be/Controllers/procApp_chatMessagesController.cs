﻿using Dapper;
using System.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using chinhquyen_be.Data;
using chinhquyen_be.Models;

namespace chinhquyen_be.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class procApp_chatMessagesController : ControllerBase
    {
        private readonly DataContext _context;
        public procApp_chatMessagesController(DataContext context)
        {
            _context = context;
        }

        [HttpGet("doanchat")]
        public async Task<IActionResult> GetDoanchat(
            int? pageIndex = 0
        )
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();
                var parameters = new DynamicParameters();
                parameters.Add("@Type", 1);
                parameters.Add("@pageIndex", pageIndex);
                parameters.Add("@pageSize", 25);

                var result = await connection.QueryAsync(
                    "procApp_chatMessages",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }

        [HttpGet("nhomchat")]
        public async Task<IActionResult> GetNhomchat(
            int? pageIndex = 0,
            int? UserId = 0
        )
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();
                var parameters = new DynamicParameters();
                parameters.Add("@Type", 2);
                parameters.Add("@UserId", UserId);
                parameters.Add("@pageIndex", pageIndex);
                parameters.Add("@pageSize", 25);

                var result = await connection.QueryAsync(
                    "procApp_chatMessages",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }

        [HttpPost("creategroup")]
        public async Task<IActionResult> CreateGroup([FromBody] CreateGroupDto dto)
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();

                // Tạo DataTable để truyền vào UserIdListType
                var userIdTable = new DataTable();
                userIdTable.Columns.Add("UserId", typeof(int));
                foreach (var id in dto.UserIds)
                {
                    userIdTable.Rows.Add(id);
                }

                var parameters = new DynamicParameters();
                parameters.Add("@GroupName", dto.GroupName);
                parameters.Add("@CreatedBy", dto.CreatedBy);
                parameters.Add("@UserIds", userIdTable.AsTableValuedParameter("UserIdListType"));

                var result = await connection.QueryFirstOrDefaultAsync<int>(
                    "procApp_createGroup",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(new { GroupId = result });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error: {ex.Message}");
            }
        }


        [HttpGet("chat-1:1-content")]
        public async Task<IActionResult> GetChat11(
          int? pageIndex = 0,
          string? Sender = "",
          string? Receiver = ""
        )
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();
                var parameters = new DynamicParameters();
                parameters.Add("@Type", 3);
                parameters.Add("@Sender", Sender);
                parameters.Add("@Receiver", Receiver);
                parameters.Add("@pageIndex", pageIndex);
                parameters.Add("@pageSize", 25);

                var result = await connection.QueryAsync(
                    "procApp_chatMessages",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }

        [HttpGet("chat-group-content")]
        public async Task<IActionResult> GetGroupChatContent(
          int? pageIndex = 0,
          string? GroupId = ""
        )
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();
                var parameters = new DynamicParameters();
                parameters.Add("@Type", 4);
                parameters.Add("@GroupId", GroupId);
                parameters.Add("@pageIndex", pageIndex);
                parameters.Add("@pageSize", 25);

                var result = await connection.QueryAsync(
                    "procApp_chatMessages",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }


        [HttpGet("last-message-content")]
        public async Task<IActionResult> LastMessageContent(
           string? Sender = "",
           string? Receiver = ""
        )
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();
                var parameters = new DynamicParameters();
                parameters.Add("@Type", 5);
                parameters.Add("@Sender", Sender);
                parameters.Add("@Receiver", Receiver);

                var result = await connection.QueryAsync(
                    "procApp_chatMessages",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }

        [HttpGet("last-message-group")]
        public async Task<IActionResult> LastMessageGroup(
          string? GroupId = ""
        )
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();
                var parameters = new DynamicParameters();
                parameters.Add("@Type", 6);
                parameters.Add("@GroupId", GroupId);
         
                var result = await connection.QueryAsync(
                    "procApp_chatMessages",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }
    }
}
