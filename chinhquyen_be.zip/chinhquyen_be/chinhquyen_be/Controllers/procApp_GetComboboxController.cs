﻿using Dapper;
using System.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using chinhquyen_be.Data;

namespace chinhquyen_be.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class procApp_GetComboboxController : ControllerBase
    {
        private readonly DataContext _context;
        public procApp_GetComboboxController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetCombobox(string table, string keyword = "")
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();

                var parameters = new DynamicParameters();
                parameters.Add("@Table", table);
                parameters.Add("@Keyword", keyword);
                parameters.Add("@pageIndex", 0);
                parameters.Add("@pageSize", 50);

                var result = await connection.QueryAsync(
                    "procApp_GetCombobox",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }
    }
}
