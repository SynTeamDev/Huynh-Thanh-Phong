﻿using chinhquyen_be.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace chinhquyen_be.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class procApp_userinfoController : ControllerBase
    {
        private readonly DataContext _context;

        public procApp_userinfoController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetUserInfo([FromQuery] string username)
        {
            var data = await _context.userInfo
                .FromSqlRaw("EXEC procApp_userinfo @UserName = {0}", username)
                .ToListAsync();

            return Ok(data);
        }
    }
}
