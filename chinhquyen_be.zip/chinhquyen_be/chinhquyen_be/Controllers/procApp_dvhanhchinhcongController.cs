﻿using System.Data;
using chinhquyen_be.Data;
using chinhquyen_be.Models;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace chinhquyen_be.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class procApp_dvhanhchinhcongController : ControllerBase
    {
        private readonly DataContext _context;
        public procApp_dvhanhchinhcongController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetPhieu(
          int? pageIndex = 0,
          string? ma_hccong = "",
          DateTime? ngay_ct1 = null,
          DateTime? ngay_ct2 = null
        )
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();

                var p = new DynamicParameters();
                p.Add("Type", 1, DbType.Int32);
                p.Add("@f_ma_hccong", ma_hccong);
                p.Add("f_ngay_ct1", ngay_ct1, DbType.Date);
                p.Add("f_ngay_ct2", ngay_ct2, DbType.Date);
                p.Add("pageIndex", pageIndex ?? 0, DbType.Int32);

                var result = await connection.QueryAsync(
                    "dbo.procApp_dvhanhchinhcong",          // 👉 chỉ rõ schema
                    p,
                    commandType: CommandType.StoredProcedure);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }

        [HttpPost("insert")]
        public async Task<IActionResult> InsertPhieu([FromBody] dvhanhchinhcongRequest request)
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();

                var parameters = new DynamicParameters();
                parameters.Add("@Type", 2); // insert


                parameters.Add("@i_ma_hccong", request.i_ma_hccong);
                parameters.Add("@i_ngay_ct", request.i_ngay_ct);
                parameters.Add("@i_status", request.i_status);
                parameters.Add("@i_user_id_current", request.i_user_id_current);

                var result = await connection.QueryFirstOrDefaultAsync(
                    "procApp_dvhanhchinhcong",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Insert failed. Details: {ex.Message}");
            }
        }

    }
}
