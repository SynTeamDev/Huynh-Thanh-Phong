﻿using System.Data;
using chinhquyen_be.Data;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace chinhquyen_be.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class procApp_dmcanboController : ControllerBase
    {
        private readonly DataContext _context;
        public procApp_dmcanboController(DataContext context)
        {
            _context = context;
        }

        [HttpGet("canbo")]
        public async Task<IActionResult> GetCanBo(
          int? pageIndex = 0,
          string? noi_congtac = "",
          string? status = "",
          DateTime? ngay_ct1 = null,
          DateTime? ngay_ct2 = null
        )
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();
                var parameters = new DynamicParameters();
                parameters.Add("@Type", 1);
                parameters.Add("@f_noi_congtac", noi_congtac);
                parameters.Add("@f_status", status);
                parameters.Add("@f_ngay_ct1", ngay_ct1, DbType.Date);
                parameters.Add("@f_ngay_ct2", ngay_ct2, DbType.Date);
                parameters.Add("@pageIndex", pageIndex);
                parameters.Add("@pageSize", 10);

                var result = await connection.QueryAsync(
                    "procApp_dmcanbo",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }
    }
}
