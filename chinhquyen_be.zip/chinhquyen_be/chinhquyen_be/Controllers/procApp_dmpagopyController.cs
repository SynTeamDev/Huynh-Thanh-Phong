﻿using System.Data;
using chinhquyen_be.Data;
using chinhquyen_be.Models;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace chinhquyen_be.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class procApp_dmpagopyController : ControllerBase
    {
        private readonly DataContext _context;
        private readonly IConfiguration _config;
        public procApp_dmpagopyController(DataContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        [HttpGet]
        public async Task<IActionResult> GetPhieu(
           int? pageIndex = 0
        )
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();

                var parameters = new DynamicParameters();
                parameters.Add("@Type", 1);
                parameters.Add("@pageIndex", pageIndex);
                parameters.Add("@pageSize", 10);

                var result = await connection.QueryAsync(
                    "procApp_dmpagopy",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }

        [HttpPost("insert")]
        public async Task<IActionResult> InsertPhieu([FromBody] dmpagopyRequest request)
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();

                var parameters = new DynamicParameters();
                parameters.Add("@Type", 2); // insert

                parameters.Add("@i_tieu_de", request.i_tieu_de);
                parameters.Add("@i_noi_dung", request.i_noi_dung);
                parameters.Add("@i_dia_diem", request.i_dia_diem);
                parameters.Add("@i_dinh_kem", request.i_dinh_kem);

                var result = await connection.QueryFirstOrDefaultAsync(
                    "procApp_dmpagopy",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Insert failed. Details: {ex.Message}");
            }
        }


        // POST: /api/procApp_dmpagopy/upload
        [HttpPost("upload")]
        [Consumes("multipart/form-data")]
        [RequestSizeLimit(10_485_760)]                          // ~10 MiB
        [RequestFormLimits(MultipartBodyLengthLimit = 10_485_760)]
        public async Task<IActionResult> Upload([FromForm] UploadDmttinRequest form)
        {
            var file = form.file;
            var userId = form.userId;

            if (file == null || file.Length == 0)
                return BadRequest("No file provided.");

            // 1) meta
            var clientName = file.FileName;
            var ext = Path.GetExtension(clientName).TrimStart('.').ToLowerInvariant();
            var sizeKb = Math.Round(file.Length / 1024.0, 3);

            await using var conn = _context.Database.GetDbConnection();
            if (conn.State == ConnectionState.Closed) await conn.OpenAsync();

            // 2) gọi proc Type=3
            var p = new DynamicParameters();
            p.Add("@Type", 3);
            p.Add("@i_client_name", clientName);
            p.Add("@i_ext", ext);
            p.Add("@i_size", sizeKb);
            p.Add("@i_user_id_current", userId);

            var row = await conn.QueryFirstAsync<dynamic>(
                "procApp_dmpagopy",
                p,
                commandType: CommandType.StoredProcedure);

            string id = row.id;
            string serverPath = row.server_path; // "202508\\{id}.isf"
            string ym = row.ym;                  // "202508"

            // 3) ghi file .isf
            var root = _config["FileRoot"]; // D:\SYN\webQuanTri\Syn_Demo25_UBPX\App_Data\Files
            if (string.IsNullOrWhiteSpace(root))
                return StatusCode(500, "Missing FileRoot in configuration.");

            Directory.CreateDirectory(Path.Combine(root, ym));
            var absPath = Path.Combine(root, serverPath.Replace('/', '\\'));

            using (var fs = System.IO.File.Create(absPath))
            using (var sw = new StreamWriter(fs, System.Text.Encoding.UTF8))
            {
                await sw.WriteAsync(
                    $"name={clientName}\next={ext}\nsizeKb={sizeKb}\nid={id}\ncreatedUtc={DateTime.UtcNow:o}");
            }

            return Ok(new
            {
                id,
                server_path = serverPath,
                client_name = clientName,
                ext,
                size_kb = sizeKb
            });
        }

    }
}
