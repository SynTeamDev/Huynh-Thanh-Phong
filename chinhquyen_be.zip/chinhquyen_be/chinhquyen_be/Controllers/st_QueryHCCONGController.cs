﻿using System.Data;
using chinhquyen_be.Data;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace chinhquyen_be.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class st_QueryHCCONGController : ControllerBase
    {
        private readonly DataContext _context;
        public st_QueryHCCONGController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetPhieu(
          string? ma_hccong = ""
        )
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();

                var p = new DynamicParameters();
                p.Add("@ma_hccong", ma_hccong);
                var result = await connection.QueryAsync(
                    "dbo.st_QueryHCCONG", // 👉 chỉ rõ schema
                    p,
                    commandType: CommandType.StoredProcedure);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }
    }
}
