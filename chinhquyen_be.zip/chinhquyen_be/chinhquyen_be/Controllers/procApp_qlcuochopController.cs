﻿using System.Data;
using chinhquyen_be.Data;
using chinhquyen_be.Models;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace chinhquyen_be.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class procApp_qlcuochopController : ControllerBase
    {
        private readonly DataContext _context;
        public procApp_qlcuochopController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetPhieu(
          int? pageIndex = 0,
          string? ma_lcuochop = "",
          string? dia_chi = "",
          string? status = "",
          DateTime? ngay_ct1 = null,
          DateTime? ngay_ct2 = null
        )
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();

                var p = new DynamicParameters();
                p.Add("Type", 1, DbType.Int32);
                p.Add("f_ma_lcuochop", ma_lcuochop);
                p.Add("f_dia_chi", dia_chi);
                p.Add("f_status", status);
                p.Add("f_ngay_ct1", ngay_ct1, DbType.Date);
                p.Add("f_ngay_ct2", ngay_ct2, DbType.Date);
                p.Add("pageIndex", pageIndex ?? 0, DbType.Int32);
                p.Add("pageSize", 10, DbType.Int32);

                var result = await connection.QueryAsync(
                    "dbo.procApp_qlcuochop",          // 👉 chỉ rõ schema
                    p,
                    commandType: CommandType.StoredProcedure);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }

        [HttpPost("insert")]
        public async Task<IActionResult> InsertPhieu([FromBody] qlcuochopRequest request)
        {
            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();

                var parameters = new DynamicParameters();
                parameters.Add("@Type", 2); // insert

                parameters.Add("@i_ten_cuochop", request.i_ten_cuochop);
                parameters.Add("@i_ten_cuochop2", request.i_ten_cuochop2);
                parameters.Add("@i_noi_dung", request.i_noi_dung);
                parameters.Add("@i_ma_lcuochop", request.i_ma_lcuochop);
                parameters.Add("@i_ngay_hop", request.i_ngay_hop);
                parameters.Add("@i_gio_bd", request.i_gio_bd);
                parameters.Add("@i_gio_kt", request.i_gio_kt);
                parameters.Add("@i_dia_chi", request.i_dia_chi);
                parameters.Add("@i_ds_chutri", request.i_ds_chutri);
                parameters.Add("@i_ds_nguoithamgia", request.i_ds_nguoithamgia);
                parameters.Add("@i_user_id_current", request.i_user_id_current);

                var result = await connection.QueryFirstOrDefaultAsync(
                    "procApp_qlcuochop",
                    parameters,
                    commandType: CommandType.StoredProcedure
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Insert failed. Details: {ex.Message}");
            }
        }


        [HttpGet("lichcuochop")]
        public async Task<IActionResult> GetLichCuocHop(
            int? pageIndex = 0,
            string? username_current = "",
            int? year = null,
            int? month = null,
            DateTime? date = null
        )
        {


            try
            {
                await using var connection = _context.Database.GetDbConnection();
                if (connection.State == ConnectionState.Closed)
                    await connection.OpenAsync();

                var parameters = new DynamicParameters();
                parameters.Add("@Type", 3);
                parameters.Add("@username_current", username_current);
                parameters.Add("@pageIndex", pageIndex);
                parameters.Add("@year", year);
                parameters.Add("@month", month);
                parameters.Add("@date", date, DbType.Date);

                using var multi = await connection.QueryMultipleAsync(
                "procApp_qlcuochop", parameters, commandType: CommandType.StoredProcedure);

                // RS1: đọc dynamic rồi convert sang Dictionary<string, object>
                var itemRows = await multi.ReadAsync(); // IEnumerable<dynamic> (DapperRow)
                var items = itemRows
                    .Select(r => (IDictionary<string, object>)r)
                    .Select(d => d.ToDictionary(kv => kv.Key, kv => kv.Value))
                    .ToList();

                // RS2: danh sách ngày trong tháng (int)
                var days = (await multi.ReadAsync<int>()).ToList();

                return Ok(new { items, days });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred while communicating with the server. Details: {ex.Message}");
            }
        }



    }
}
