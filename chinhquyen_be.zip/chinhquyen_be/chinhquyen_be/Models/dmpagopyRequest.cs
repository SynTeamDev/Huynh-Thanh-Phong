﻿namespace chinhquyen_be.Models
{
    public class dmpagopyRequest
    {
        public string? i_tieu_de { get; set; }
        public string? i_noi_dung { get; set; }
        public string? i_dia_diem { get; set; }
        public string? i_dinh_kem { get; set; }
    }
}
