﻿namespace chinhquyen_be.Models
{
    public class dvhanhchinhcongRequest
    {
        public string? i_ma_hccong { get; set; }
        public DateTime? i_ngay_ct { get; set; }
        public int? i_status { get; set; }
        public int? i_user_id_current { get; set; }
    }
}
