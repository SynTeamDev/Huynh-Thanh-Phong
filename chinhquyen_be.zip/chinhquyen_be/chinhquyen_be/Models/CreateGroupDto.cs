﻿namespace chinhquyen_be.Models
{
    public class CreateGroupDto
    {
        public string GroupName { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public List<int> UserIds { get; set; } = new();
    }
}
