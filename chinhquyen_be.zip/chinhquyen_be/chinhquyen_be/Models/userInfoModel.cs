﻿namespace chinhquyen_be.Models
{
    public class userInfoModel
    {
        public int? user_id { get; set; }
        public string? username { get; set; }
        public string? nickname { get; set; }
        public string? e_mail { get; set; }
        public string? phone { get; set; }
        public int? admin { get; set; }
        public string? ma_pb { get; set; }
        public string? ma_bp { get; set; }
    }
}
