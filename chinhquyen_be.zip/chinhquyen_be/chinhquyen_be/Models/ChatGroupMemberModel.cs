﻿using System.ComponentModel.DataAnnotations.Schema;

namespace chinhquyen_be.Models
{
    [Table("ChatGroupMember")] // 👈 đúng tên bảng SQL
    public class ChatGroupMemberModel
    {
        public int Id { get; set; }
        public int GroupId { get; set; }
        public string UserId { get; set; } = null!;
        public DateTime JoinedAt { get; set; }
        public ChatGroupModel Group { get; set; } = null!;
    }
}
