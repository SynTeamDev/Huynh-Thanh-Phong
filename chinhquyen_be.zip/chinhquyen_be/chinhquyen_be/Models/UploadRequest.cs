﻿namespace chinhquyen_be.Models
{
    public class SingleFileUploadRequest
    {
        // tên property phải trùng với key form-data mà client gửi (vd: "file")
        public IFormFile file { get; set; } = default!;
    }

    public class MultiFileUploadRequest
    {
        // tên property trùng "files"
        public List<IFormFile> files { get; set; } = new();
    }
}
