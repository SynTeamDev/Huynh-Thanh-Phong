﻿using System.ComponentModel.DataAnnotations;

namespace chinhquyen_be.Models
{
    public class UploadDmttinRequest
    {
        [Required]
        public IFormFile file { get; set; } = default!;  // key = "file"

        [Required]
        public int userId { get; set; }                  // key = "userId"
    }
}
