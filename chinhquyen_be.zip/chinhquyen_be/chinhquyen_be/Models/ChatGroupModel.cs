﻿using System.ComponentModel.DataAnnotations.Schema;

namespace chinhquyen_be.Models
{
    [Table("ChatGroup")] // 👈 đúng tên bảng SQL
    public class ChatGroupModel
    {
        public int GroupId { get; set; }
        public string GroupName { get; set; } = null!;
        public string CreatedBy { get; set; } = null!;
        public DateTime CreatedAt { get; set; }
        public ICollection<ChatGroupMemberModel> Members { get; set; } = new List<ChatGroupMemberModel>();
    }
}
