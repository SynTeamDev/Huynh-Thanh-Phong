﻿using System.ComponentModel.DataAnnotations.Schema;

namespace chinhquyen_be.Models
{
    [Table("chatMessages")] // 👈 đúng tên bảng SQL
    public class chatMessageModel
    {
        public int Id { get; set; }
        public string Sender { get; set; } = null!;
        public string? Receiver { get; set; }
        public string Message { get; set; } = null!;
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        public int? GroupId { get; set; } // 👈 chat nhóm thì có giá trị
    }


}
