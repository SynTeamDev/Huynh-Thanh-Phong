﻿namespace chinhquyen_be.Models
{
    public class qlcuochopRequest
    {
        public string? i_ten_cuochop { get; set; }
        public string? i_ten_cuochop2 { get; set; }
        public string? i_noi_dung { get; set; }
        public string? i_ma_lcuochop { get; set; }
        public DateTime? i_ngay_hop { get; set; }
        public string? i_gio_bd { get; set; }
        public string? i_gio_kt { get; set; }
        public string? i_dia_chi { get; set; }
        public string? i_ds_chutri { get; set; }
        public string? i_ds_nguoithamgia { get; set; }
        public int? i_user_id_current { get; set; }

    }
}
