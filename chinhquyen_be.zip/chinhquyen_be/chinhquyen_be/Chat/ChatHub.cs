﻿using chinhquyen_be.Data;
using chinhquyen_be.Models;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;

namespace chinhquyen_be.Chat
{
    public class ChatHub : Hub
    {
        private readonly DataContext _context;

        public ChatHub(DataContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Gửi tin nhắn cá nhân
        /// </summary>
        public async Task SendMessage(string sender, string receiver, string message)
        {
            try
            {
                var chat = new chatMessageModel
                {
                    Sender = sender,
                    Receiver = receiver,
                    Message = message,
                    Timestamp = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById(OperatingSystem.IsWindows() ? "SE Asia Standard Time" : "Asia/Ho_Chi_Minh"))
                };

                _context.chatMessages.Add(chat);
                await _context.SaveChangesAsync();

                var connected = Clients.User(receiver) != null;
                Console.WriteLine($" - Gui tin den user {receiver} - dang ket noi? {connected}");

                await Clients.User(receiver).SendAsync("ReceiveMessage", sender, message);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error SendMessage: {ex.Message}");
                throw; // Cho client biết lỗi vẫn xảy ra
            }
        }

        /// <summary>
        /// Gửi tin nhắn vào nhóm
        /// </summary>
        public async Task SendGroupMessage(string sender, int groupId, string message)
        {
            try
            {
                var chat = new chatMessageModel
                {
                    Sender = sender,
                    GroupId = groupId,
                    Message = message,
                    Timestamp = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById(OperatingSystem.IsWindows() ? "SE Asia Standard Time" : "Asia/Ho_Chi_Minh"))
                };

                _context.chatMessages.Add(chat);
                await _context.SaveChangesAsync();

                string groupName = $"group_{groupId}";

                // GỌI STORED PROCEDURE để lấy thông tin user
                var users = await _context.userInfo
                    .FromSqlRaw("EXEC procApp_userinfo @UserName = {0}", sender) // hoặc truyền theo user_id nếu cần
                    .ToListAsync();

                var user = users.FirstOrDefault(); // vì stored procedure vẫn trả về List

                string senderName = user?.username ?? sender;

                await Clients.Group(groupName).SendAsync("ReceiveGroupMessage", sender, groupId, message, senderName);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error SendGroupMessage: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Khi client connect, tự join các nhóm
        /// </summary>
        public override async Task OnConnectedAsync()
        {
            var httpContext = Context.GetHttpContext();
            var userId = httpContext?.Request.Query["userId"].ToString();

            if (!string.IsNullOrEmpty(userId))
            {
                var groupIds = await _context.ChatGroupMembers
                    .Where(m => m.UserId == userId)
                    .Select(m => m.GroupId)
                    .ToListAsync();

                foreach (var groupId in groupIds)
                {
                    await Groups.AddToGroupAsync(Context.ConnectionId, $"group_{groupId}");
                    Console.WriteLine($"✅ User {userId} joined group_{groupId}");
                }
            }

            await base.OnConnectedAsync();
        }


        /// <summary>
        /// Rời khỏi nhóm (tuỳ chọn gọi thủ công)
        /// </summary>
        public async Task LeaveGroup(string userId, int groupId)
        {
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, $"group_{groupId}");
            Console.WriteLine($"👋 User {userId} left group_{groupId}");
        }

        /// <summary>
        /// Vào nhóm (tuỳ chọn gọi thủ công)
        /// </summary>
        public async Task JoinGroup(string userId, int groupId)
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, $"group_{groupId}");
            Console.WriteLine($"👋 User {userId} joined group_{groupId}");
        }

        /// <summary>
        /// Báo trạng thái đang gõ cho đối phương
        /// </summary>
        public async Task Typing(string fromUserId, string toUserId, bool isTyping)
        {
            // Gửi trực tiếp cho user nhận
            await Clients.User(toUserId).SendAsync("OnTyping", fromUserId, isTyping);
        }

   

    }
}
