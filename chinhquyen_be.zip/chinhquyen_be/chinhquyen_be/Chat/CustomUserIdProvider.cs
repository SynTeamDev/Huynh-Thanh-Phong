﻿using Microsoft.AspNetCore.SignalR;

namespace chinhquyen_be.Chat
{
    public class CustomUserIdProvider : IUserIdProvider
    {
        public string? GetUserId(HubConnectionContext connection)
        {
            // Lấy userId từ query string khi client connect
            return connection.GetHttpContext()?.Request.Query["userId"];
        }
    }
}
