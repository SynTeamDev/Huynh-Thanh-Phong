﻿using chinhquyen_be.Models;
using Microsoft.EntityFrameworkCore;

namespace chinhquyen_be.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options) { }


        public DbSet<chatMessageModel> chatMessages { get; set; } = null!;
        public DbSet<ChatGroupModel> ChatGroups { get; set; } = null!;
        public DbSet<ChatGroupMemberModel> ChatGroupMembers { get; set; } = null!;

        // userInfoModel
        public DbSet<userInfoModel> userInfo { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<userInfoModel>().HasNoKey(); // Vì dùng từ stored procedure không có khóa chính
            modelBuilder.Entity<ChatGroupModel>().HasKey(g => g.GroupId);
            modelBuilder.Entity<ChatGroupMemberModel>().HasKey(m => m.Id);
        }
    }
}
